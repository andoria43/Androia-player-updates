'use strict';
// Android phone interface (does nothing on Windows): a library screen with the clips, the video full screen
// with controls over it that hide by themselves, swipe gestures (volume, brightness, seek), a lock,
// the audio tracks in a sheet that slides up from the bottom, and the settings as Android-style lists.
// It reuses the player engine of app.js (same tracks, export, subtitles, updates, session).
(function () {
  if (!ANDROID) return;
  document.body.classList.add('m');
  const sv = (d) => `<svg viewBox="0 0 24 24">${d}</svg>`;
  const I = {
    back: '<path d="M9 5l7 7-7 7"/>',
    search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>',
    sort: '<path d="M7 4v16M3 16l4 4 4-4M14 6h7M14 12h5M14 18h3"/>',
    gear: '<path d="M10.3 4.3c.4-1.8 2.9-1.8 3.4 0a1.7 1.7 0 0 0 2.6 1.1c1.5-.9 3.3.8 2.4 2.4a1.7 1.7 0 0 0 1 2.5c1.8.4 1.8 2.9 0 3.4a1.7 1.7 0 0 0-1 2.6c.9 1.5-.8 3.3-2.4 2.4a1.7 1.7 0 0 0-2.6 1c-.4 1.8-2.9 1.8-3.4 0a1.7 1.7 0 0 0-2.6-1c-1.5.9-3.3-.8-2.4-2.4a1.7 1.7 0 0 0-1-2.6c-1.8-.4-1.8-2.9 0-3.4a1.7 1.7 0 0 0 1-2.5c-.9-1.6.8-3.3 2.4-2.4 1 .6 2.3.1 2.6-1.1z"/><circle cx="12" cy="12" r="3"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 10v6M9 13h6"/>',
    audio: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
    subs: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 10.5a2 2 0 1 0 0 3M17 10.5a2 2 0 1 0 0 3"/>',
    more: '<circle cx="12" cy="5" r="1.4" class="fill"/><circle cx="12" cy="12" r="1.4" class="fill"/><circle cx="12" cy="19" r="1.4" class="fill"/>',
    prev: '<path d="M6 6v12"/><path d="M18 6v12l-9-6z" class="fill"/>',
    next: '<path d="M18 6v12"/><path d="M6 6v12l9-6z" class="fill"/>',
    play: '<path d="M8 5v14l11-7z" class="fill"/>',
    pause: '<rect x="6" y="5" width="4" height="14" rx="1" class="fill"/><rect x="14" y="5" width="4" height="14" rx="1" class="fill"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    repeat: '<path d="M4 12V9a3 3 0 0 1 3-3h12l-3-3M20 12v3a3 3 0 0 1-3 3H5l3 3"/>',
    aspect: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 11V9h3M17 13v2h-3"/>',
    shot: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    rotate: '<rect x="7" y="3" width="10" height="18" rx="2"/><path d="M2 14a9 9 0 0 0 6 7M22 10a9 9 0 0 0-6-7"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
    vol: '<path d="M4 9h4l5-4v14l-5-4H4z" class="fill"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
    spk: '<path d="M4 9h4l5-4v14l-5-4H4z" class="fill"/><path d="M16 9a4 4 0 0 1 0 6"/>',
    list: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    biglist: '<rect x="3" y="4" width="7" height="6" rx="1"/><rect x="3" y="14" width="7" height="6" rx="1"/><path d="M13 7h8M13 17h8"/>',
    grid3: '<rect x="3" y="3" width="5" height="5" rx="1"/><rect x="9.5" y="3" width="5" height="5" rx="1"/><rect x="16" y="3" width="5" height="5" rx="1"/><rect x="3" y="10" width="5" height="5" rx="1"/><rect x="9.5" y="10" width="5" height="5" rx="1"/><rect x="16" y="10" width="5" height="5" rx="1"/><rect x="3" y="17" width="5" height="4" rx="1"/><rect x="9.5" y="17" width="5" height="4" rx="1"/><rect x="16" y="17" width="5" height="4" rx="1"/>',
    grid2: '<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/>',
    fold: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" class="fill"/>',
    film: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 9.5v5l4.5-2.5z" class="fill"/>',
  };
  const btn = (id, ic, title, cls = '') => `<button class="ib ${cls}" id="${id}" title="${title}">${sv(I[ic])}</button>`;

  // ---------- the screens ----------
  document.body.insertAdjacentHTML('beforeend', `
  <div id="mLib" class="mlib">
    <div class="m-top">${btn('mLibBack', 'back', 'رجوع', 'm-back hidden')}<span class="m-title" id="mTitle">أندوريا بلاير</span>${btn('mSearchB', 'search', 'بحث')}<button class="ib" id="mViewB" title="طريقة العرض"></button>${btn('mSortB', 'sort', 'الترتيب')}${btn('mSetB', 'gear', 'الإعدادات')}</div>
    <input id="mSearch" class="m-search hidden" type="search" placeholder="بحث">
    <div id="mTabs" class="m-tabs hidden"><button data-tab="folders">المجلدات</button><button data-tab="all">كل الفيديوهات</button></div>
    <div id="mInfo" class="m-info"></div>
    <div id="mItems" class="m-items"></div>
    <button id="mNow" class="m-now hidden" title="متابعة آخر فيديو">${sv(I.play)}<span class="nm hidden" id="mNowName"></span></button>
    <button id="mFab" class="m-fab" title="فتح">${sv(I.folder)}</button>
  </div>
  <div id="mSheetBg" class="m-sheetbg hidden"><div id="mSheet" class="m-sheet"></div></div>`);
  $('stage').insertAdjacentHTML('beforeend', `
  <div id="mDim" class="m-dim"></div>
  <div id="mOv" class="mov">
    <div class="m-top m-ovtop">${btn('mBack', 'back', 'رجوع', 'm-back')}<div id="mName" class="m-name" dir="ltr"></div>
      <button class="ib" id="mAud" title="الأصوات">${sv(I.audio)}<span id="mAudN" class="cnt hidden" dir="ltr"></span></button>${btn('mSub', 'subs', 'الترجمة')}${btn('mMore', 'more', 'المزيد')}</div>
    <div class="m-mid">${btn('mPrev', 'prev', 'السابق')}<button class="ib m-play" id="mPlay" title="تشغيل / إيقاف مؤقت">${sv(I.play)}</button>${btn('mNext', 'next', 'التالي')}</div>
    <div class="m-bot"><div id="mSeekSlot"></div>
      <div class="m-row">${btn('mLock', 'lock', 'قفل الشاشة')}<button class="ib" id="mRep" title="التكرار">${sv(I.repeat)}<span id="mRepOne" class="cnt hidden" dir="ltr">1</span></button>${btn('mAsp', 'aspect', 'نسبة العرض')}${btn('mShot', 'shot', 'لقطة')}${btn('mRot', 'rotate', 'تدوير الشاشة')}</div></div>
  </div>
  <div id="mLockL" class="m-lockl hidden"><button class="ib" id="mUnlock" title="فتح القفل">${sv(I.lock)}</button></div>
  <div id="mGest" class="m-gest hidden"><span id="mGIc"></span><div class="m-gbar"><b id="mGFill"></b></div><span id="mGV" dir="ltr"></span></div>`);
  $('mSeekSlot').appendChild(document.querySelector('.seekrow')); // the same seek bar and times, now inside the overlay
  // the Windows playlist panel is replaced by the library screen
  S.set.showList = false; document.body.classList.add('no-list');
  toggleList = () => showLib(); // eslint-disable-line no-global-assign

  // ---------- library ----------
  const TH = {}; // path -> { img, dur }
  try { Object.assign(TH, JSON.parse(localStorage.getItem('mThumbs2') || '{}')); } catch (e) {}
  const thFail = new Set(), thQ = [];
  let thBusy = false, thSaveT = null;
  const persist = () => { clearTimeout(thSaveT); thSaveT = setTimeout(() => { try { const k = Object.keys(TH); k.slice(0, Math.max(0, k.length - 300)).forEach((x) => delete TH[x]); localStorage.setItem('mThumbs2', JSON.stringify(TH)); } catch (e) {} }, 800); };
  function needThumb(c) { if (TH[c.path] || thFail.has(c.path) || thQ.includes(c.path)) return; thQ.push(c.path); runThumb(); }
  function runThumb() {
    if (thBusy || !thQ.length) return;
    thBusy = true;
    const p = thQ.shift(), v = document.createElement('video');
    v.muted = true; v.preload = 'auto'; if (window.AP_MEDIA_CROSS) v.crossOrigin = 'anonymous';
    let over = false;
    const fin = (data) => {
      if (over) return; over = true; clearTimeout(to);
      if (data) { TH[p] = data; persist(); paintThumb(p); } else thFail.add(p);
      v.removeAttribute('src'); v.load(); thBusy = false; setTimeout(runThumb, 30);
    };
    const to = setTimeout(() => fin(null), 9000);
    v.addEventListener('loadedmetadata', () => { v.currentTime = Math.min(1.5, (v.duration || 3) / 3); });
    v.addEventListener('seeked', () => {
      try { // picture cut from the middle of the frame, never stretched
        const cv = document.createElement('canvas'), W = 320, H = 204, vw = v.videoWidth || W, vh = v.videoHeight || H, k = Math.max(W / vw, H / vh);
        cv.width = W; cv.height = H; cv.getContext('2d').drawImage(v, (W - vw * k) / 2, (H - vh * k) / 2, vw * k, vh * k);
        fin({ img: cv.toDataURL('image/jpeg', 0.75), dur: v.duration || 0 }); }
      catch (e) { fin({ img: '', dur: v.duration || 0 }); }
    });
    v.addEventListener('error', () => fin(null));
    v.src = ap.fileUrl(p);
  }
  const TRK = {}; // path -> number of audio tracks, known once the clip was opened
  // all the videos on the phone, grouped by folder (needs the app version that can read them)
  const canScan = (() => { try { return !!(window.Native && Native.caps && String(Native.caps()).includes('scan')); } catch (e) { return false; } })();
  let SCAN = null, scanErr = '', scanning = false;
  const lv = { tab: 'folders', fid: null, name: '' }; // where the library is
  let foldTop = 0;
  async function rescan(ask) {
    if (!canScan || scanning) return;
    scanning = true;
    const r = await ap.scanVideos(!!ask);
    scanning = false;
    if (Array.isArray(r)) { const sig = (x) => x.length + '|' + (x[0] ? x[0].path + x[0].mtime : ''); const ch = !SCAN || sig(SCAN) !== sig(r); SCAN = r; scanErr = ''; if (ch) renderLib(); }
    else { scanErr = (r && r.error) || 'denied'; renderLib(); }
  }
  const LAYOUTS = [['list', 'قائمة'], ['biglist', 'قائمة كبيرة'], ['grid3', 'شبكة صغيرة'], ['grid2', 'شبكة كبيرة']];
  const layout = () => (LAYOUTS.some(([k]) => k === cfg('mLayout')) ? cfg('mLayout') : 'list');
  const paintViewB = () => { $('mViewB').innerHTML = sv(I[layout()]); };
  const SORTS = [['new', 'الأحدث أولاً'], ['old', 'الأقدم أولاً'], ['name', 'حسب الاسم'], ['size', 'الأكبر حجماً'], ['dur', 'الأطول مدة']];
  function sortItems(arr) {
    const s = cfg('sort');
    const k = { old: (a, b) => a.mtime - b.mtime, name: (a, b) => a.name.localeCompare(b.name, 'ar', { numeric: true }), size: (a, b) => (b.size || 0) - (a.size || 0), dur: (a, b) => (b.dur || 0) - (a.dur || 0) }[s] || ((a, b) => b.mtime - a.mtime);
    return arr.sort(k);
  }
  function folders() {
    const m = new Map();
    (SCAN || []).forEach((v) => {
      let f = m.get(v.fid);
      if (!f) { f = { fid: v.fid, name: v.folder || 'الذاكرة الرئيسية', n: 0, size: 0, dur: 0, mtime: 0, top: v }; m.set(v.fid, f); }
      f.n++; f.size += v.size || 0; f.dur += v.dur || 0;
      if (v.mtime > f.mtime) { f.mtime = v.mtime; f.top = v; }
    });
    return sortItems([...m.values()]);
  }
  const curPath = () => (S.list[S.cur] ? S.list[S.cur].path : '');
  function thumbHtml(p, dur) {
    if (!cfg('mThumbs')) return `${sv(I.film)}${cfg('mShowDur') && dur ? `<span class="du" dir="ltr">${fmt(dur / 1000)}</span>` : ''}`;
    const t = TH[p], d = cfg('mShowDur') ? (dur ? dur / 1000 : t && t.dur) : 0;
    const img = t && t.img ? `<img src="${t.img}" alt="">` : canScan && SCAN && !nthFail.has(p) ? `<img src="${ap.fileUrl('thumb:' + p)}?v=2" alt="" data-fb="${esc(p)}">` : sv(I.film);
    return `${img}${d ? `<span class="du" dir="ltr">${fmt(d)}</span>` : ''}`;
  }
  const nthFail = new Set(); // videos the system could not make a picture for: made here from the video itself
  function paintThumb(p) { $('mItems').querySelectorAll('.m-th').forEach((el) => { if (el.dataset.p === p) el.innerHTML = el.dataset.fold ? thumbHtml(p).replace(/<span class="du"[^]*$/, '') + `<span class="fd">${sv(I.fold)}</span>` : thumbHtml(p, +el.dataset.dur || 0); }); }
  function wireImg(th, c) { const im = th.querySelector('img[data-fb]'); if (im) im.addEventListener('error', () => { nthFail.add(c.path); im.remove(); needThumb(c); }, { once: true }); }
  function videoCard(c, onTap) {
    const el = document.createElement('div');
    el.className = 'm-it' + (c.path === curPath() ? ' on' : '');
    const k = TRK[c.path];
    el.innerHTML = `<div class="m-th">${thumbHtml(c.path, c.dur)}</div><div class="tx"><div class="nm" dir="auto"></div><div class="dt"><span class="chip">${stamp(c.mtime)}</span>${k != null ? `<span class="chip"><span class="tk" dir="ltr">${k}</span>${sv(I.spk)}</span>` : ''}</div></div><button class="ib m-dots" title="المزيد">${sv(I.more)}</button>`;
    const th = el.querySelector('.m-th'); th.dataset.p = c.path; th.dataset.dur = c.dur || 0;
    el.querySelector('.nm').textContent = c.name;
    wireImg(th, c);
    if ((!canScan || !SCAN) && cfg('mThumbs')) needThumb(c);
    el.addEventListener('click', (e) => { if (!e.target.closest('.m-dots')) onTap(); });
    const menu = (e) => { e.preventDefault(); e.stopPropagation(); showMenu(e, [
      { t: 'تشغيل', fn: onTap },
      { t: 'معلومات الملف…', fn: () => itemInfo(c) },
      ...(canScan && SCAN ? [] : [{ t: 'إزالة من القائمة', fn: () => { const i = S.list.findIndex((x) => x.path === c.path); if (i >= 0) removeAt(i); } }]),
    ]); };
    el.querySelector('.m-dots').addEventListener('click', menu);
    el.addEventListener('contextmenu', menu);
    return el;
  }
  async function itemInfo(c) {
    const size = c.size || (await ap.fileSize(c.path)) || 0, d = c.dur ? c.dur / 1000 : (TH[c.path] && TH[c.path].dur) || 0;
    const r = (l, v) => `<div class="prow"><div class="l">${l}</div><div class="v" dir="ltr" data-notr>${esc(String(v))}</div></div>`;
    sheet(`${head('معلومات الملف')}<div class="pbody m-info-b">
      <div class="prow"><div class="l">الاسم</div><div class="v" dir="auto" data-notr>${esc(c.name)}</div></div>
      ${c.folder ? `<div class="prow"><div class="l">المجلد</div><div class="v" dir="auto" data-notr>${esc(c.folder)}</div></div>` : ''}
      ${d ? r('المدة', fmt(d)) : ''}${size ? r('الحجم', (size / 1048576).toFixed(1) + ' MB') : ''}
      ${c.mtime ? `<div class="prow"><div class="l">التاريخ</div><div class="v">${stamp(c.mtime)}</div></div>` : ''}
      ${TRK[c.path] != null ? r('مسارات الصوت', TRK[c.path]) : ''}</div>`);
  }
  function emptyBox(html) {
    $('mItems').innerHTML = `<div class="m-empty">${sv(I.film)}${html}<button class="pbtn accent" id="mE1">فتح ملف</button><button class="pbtn" id="mE2">فتح مجلد</button></div>`;
    $('mE1').addEventListener('click', pickFiles); $('mE2').addEventListener('click', pickFolder);
  }
  let libSig = '';
  function renderLib() {
    const box = $('mItems'), q = $('mSearch').value.trim().toLowerCase(), L = layout();
    box.className = 'm-items l-' + L;
    paintViewB();
    const inFolder = canScan && SCAN && lv.fid != null;
    $('mLibBack').classList.toggle('hidden', !inFolder);
    $('mTitle').textContent = inFolder ? lv.name : 'أندوريا بلاير';
    $('mTabs').classList.toggle('hidden', !(canScan && SCAN) || inFolder);
    $('mTabs').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.tab === lv.tab));
    const sig = [L, cfg('sort'), cfg('mThumbs'), cfg('mShowDur'), q, lv.tab, lv.fid, scanErr, SCAN ? SCAN.length : -1, S.list.map((x) => x.path).join('|'), JSON.stringify(TRK)].join('#');
    if (sig === libSig) { box.querySelectorAll('.m-it').forEach((el) => { const t = el.querySelector('.m-th'); if (t && t.dataset.p) el.classList.toggle('on', t.dataset.p === curPath()); }); return; }
    libSig = sig;
    const top = box.scrollTop;
    box.innerHTML = '';
    if (canScan && !SCAN) {
      $('mInfo').textContent = '';
      if (!scanErr) { box.innerHTML = '<div class="m-empty"><span class="spin"></span><div>جاري قراءة الفيديوهات…</div></div>'; return; }
      emptyBox(`<div>اسمح للتطبيق بقراءة فيديوهات الهاتف حتى تظهر هنا كل المجلدات</div><button class="pbtn accent" id="mAllow">السماح بالوصول</button>`);
      $('mAllow').addEventListener('click', () => { if (scanErr === 'blocked') ap.appSettings(); else rescan(true); });
      return;
    }
    if (canScan) {
      if (lv.tab === 'folders' && lv.fid == null) {
        const fs = folders().filter((f) => !q || f.name.toLowerCase().includes(q));
        $('mInfo').innerHTML = `<span>المجلدات</span> <span dir="ltr">(${fs.length})</span>`;
        if (!fs.length) { emptyBox('<div>لا توجد فيديوهات في الهاتف</div>'); return; }
        const curFid = (SCAN.find((v) => v.path === curPath()) || {}).fid;
        fs.forEach((f) => {
          const el = document.createElement('div');
          el.className = 'm-it m-fold' + (curFid != null && curFid === f.fid ? ' on' : '');
          el.innerHTML = `<div class="m-th">${thumbHtml(f.top.path).replace(/<span class="du"[^]*$/, '')}<span class="fd">${sv(I.fold)}</span></div><div class="tx"><div class="nm" dir="auto" data-notr></div><div class="dt"><span dir="ltr">${f.n}</span> <span>فيديو</span></div></div>`;
          el.querySelector('.nm').textContent = f.name;
          const th = el.querySelector('.m-th'); th.dataset.p = f.top.path; th.dataset.fold = '1'; wireImg(th, f.top);
          el.addEventListener('click', () => { foldTop = box.scrollTop; lv.fid = f.fid; lv.name = f.name; $('mSearch').value = ''; renderLib(); box.scrollTop = 0; });
          box.appendChild(el);
        });
        box.scrollTop = top;
        return;
      }
      const vids = sortItems(SCAN.filter((v) => lv.fid == null || v.fid === lv.fid)).filter((v) => !q || v.name.toLowerCase().includes(q));
      $('mInfo').innerHTML = `<span>المقاطع</span> <span dir="ltr">(${vids.length})</span>`;
      if (!vids.length) { emptyBox('<div>لا توجد مقاطع بعد</div>'); return; }
      vids.forEach((c, i) => box.appendChild(videoCard(c, () => {
        if (c.path === curPath() && video.src) { showPlayer(); return; }
        S.list = vids.map((v) => Object.assign({}, v)); S.cur = -1; // next / previous stay inside this folder, in this order
        playIndex(i);
      })));
      box.scrollTop = top;
      return;
    }
    // older app version: the clips that were opened by hand
    const n = S.list.length, dir = cfg('lastDir') ? ap.basename(cfg('lastDir')) : '';
    $('mInfo').innerHTML = n ? `<span>المقاطع</span> <span dir="ltr">(${n})</span>${dir ? ` · <span data-notr dir="auto">${esc(dir)}</span>` : ''}` : '';
    if (!n) { emptyBox('<div>لا توجد مقاطع بعد</div>'); return; }
    S.list.forEach((c, i) => {
      if (q && !c.name.toLowerCase().includes(q)) return;
      box.appendChild(videoCard(c, () => { if (i === S.cur && video.src) showPlayer(); else playIndex(i); }));
    });
    box.scrollTop = top;
  }
  function leaveFolder() { if (!(canScan && SCAN && lv.fid != null)) return false; lv.fid = null; $('mSearch').value = ''; libSig = ''; renderLib(); $('mItems').scrollTop = foldTop; return true; }
  $('mTabs').querySelectorAll('button').forEach((b) => b.addEventListener('click', () => { if (lv.tab === b.dataset.tab) return; lv.tab = b.dataset.tab; lv.fid = null; renderLib(); $('mItems').scrollTop = 0; }));
  $('mViewB').addEventListener('click', () => { // every tap: list, big list, small grid, big grid
    const i = LAYOUTS.findIndex(([k]) => k === layout()), [k, t] = LAYOUTS[(i + 1) % LAYOUTS.length];
    const box = $('mItems'), f = box.scrollHeight > box.clientHeight ? box.scrollTop / (box.scrollHeight - box.clientHeight) : 0;
    save({ mLayout: k }); renderLib(); box.scrollTop = f * (box.scrollHeight - box.clientHeight);
    osd(t);
  });
  if (canScan) { rescan(true); ap.onWinEvent((e) => { if (e === 'restore') rescan(false); }); }
  const _renderList = renderList;
  renderList = function (keep) { _renderList(keep); renderLib(); }; // eslint-disable-line no-global-assign

  let libTop = 0;
  function showLib() {
    if (document.body.classList.contains('m-lib')) return;
    if (!video.paused) video.pause();
    if (document.body.classList.contains('full')) ap.exitFullscreen();
    closeAudio(); subOpen = false; renderSubPop();
    setBright(-1); // the phone's own brightness in the library
    document.body.classList.add('m-lib');
    applyOrient();
    const it = S.list[S.cur];
    $('mNow').classList.toggle('hidden', !it || !video.src);
    if (it) $('mNowName').textContent = it.name;
    $('mItems').scrollTop = libTop;
  }
  function showPlayer() {
    if (!document.body.classList.contains('m-lib')) return;
    libTop = $('mItems').scrollTop;
    document.body.classList.remove('m-lib');
    if (cfg('mKeepBright') && cfg('mBrightV') > 0) setBright(cfg('mBrightV'));
    applyOrient();
    showUi();
  }
  $('mLibBack').addEventListener('click', leaveFolder);
  $('mNow').addEventListener('click', () => { showPlayer(); video.play().catch(() => {}); });
  $('mSetB').addEventListener('click', () => openPrefs());
  $('mSearchB').addEventListener('click', () => { const s = $('mSearch'); s.classList.toggle('hidden'); if (!s.classList.contains('hidden')) s.focus(); else { s.value = ''; renderLib(); } });
  $('mSearch').addEventListener('input', renderLib);
  $('mSortB').addEventListener('click', (e) => showMenu(e, SORTS.map(([v, t]) => ({ t, chk: cfg('sort') === v, fn: () => {
    save({ sort: v });
    if (!canScan) { const p = curPath(); sortList(S.list); S.cur = p ? S.list.findIndex((x) => x.path === p) : -1; renderList(); }
    else renderLib();
    $('mItems').scrollTop = 0; // the list starts again from its top
  } }))));
  $('mFab').addEventListener('click', (e) => showMenu(e, [
    { t: 'فتح ملف…', fn: pickFiles },
    { t: 'فتح مجلد…', fn: pickFolder },
    { t: 'إضافة ملفات', fn: async () => { const f = await ap.pickFile(cfg('lastDir')); if (f && f.length) addFiles(f); } },
  ]));

  // ---------- player ----------
  const _playIndex = playIndex;
  playIndex = function (i, opt) { const it = S.list[i]; if (it) $('mName').textContent = it.name; showPlayer(); return _playIndex(i, opt); }; // eslint-disable-line no-global-assign
  const _buildTracks = buildTracks;
  buildTracks = function (info) { // eslint-disable-line no-global-assign
    _buildTracks(info);
    const n = S.tracks.length, it = S.list[S.cur];
    $('mAudN').textContent = n; $('mAudN').classList.toggle('hidden', n < 2);
    if (it && TRK[it.path] !== n) { TRK[it.path] = n; renderLib(); }
    if (audOpen) renderAudio();
  };
  const paintPlay = () => { $('mPlay').innerHTML = sv(video.paused ? I.play : I.pause); };
  video.addEventListener('play', () => { paintPlay(); showUi(); });
  video.addEventListener('pause', () => { paintPlay(); showUi(true); });
  const paintRep = () => { const r = cfg('repeat'); $('mRep').classList.toggle('on', r !== 'off'); $('mRepOne').classList.toggle('hidden', r !== 'one'); };
  const _paintModes = paintModes;
  paintModes = function () { _paintModes(); paintRep(); }; // eslint-disable-line no-global-assign
  paintRep();

  // controls over the video: shown on a tap, hidden after 3.5 s while playing
  let hideT = null, locked = false;
  function showUi(stay) {
    if (locked) return;
    document.body.classList.add('m-show');
    clearTimeout(hideT);
    if (!stay && !video.paused) hideT = setTimeout(hideUi, (+cfg('mHide') || 3.5) * 1000);
  }
  function hideUi() { if (audOpen || subOpen || !$('menu').classList.contains('hidden')) { showUi(); return; } document.body.classList.remove('m-show'); }
  const keep = (fn) => (e) => { e.stopPropagation(); fn(e); showUi(); };
  $('mBack').addEventListener('click', keep(showLib));
  $('mPlay').addEventListener('click', keep(() => togglePlay()));
  $('mPrev').addEventListener('click', keep(() => $('bPrev').click())); // same behaviour as the Windows buttons
  $('mNext').addEventListener('click', keep(() => $('bNext').click()));
  $('mAud').addEventListener('click', keep(() => { subOpen = false; renderSubPop(); openAudio(); }));
  $('mSub').addEventListener('click', keep(() => { closeAudio(); subOpen = !subOpen; renderSubPop(); }));
  $('mMore').addEventListener('click', (e) => { e.stopPropagation(); $('stage').dispatchEvent(new MouseEvent('contextmenu', { clientX: e.clientX, clientY: e.clientY, bubbles: true })); showUi(); });
  $('mRep').addEventListener('click', keep(cycleRepeat));
  const ASP = [['contain', 'نسبة أصلية'], ['cover', 'ملء مع قص الحواف'], ['fill', 'تمديد لملء الشاشة'], ['16:9', '16:9'], ['4:3', '4:3']];
  $('mAsp').addEventListener('click', keep(() => { const i = ASP.findIndex(([v]) => v === cfg('aspect')); const [v, t] = ASP[(i + 1) % ASP.length]; vset({ aspect: v }, /\d/.test(t) ? ltr(t) : t); }));
  $('mShot').addEventListener('click', keep(() => shot()));
  $('mRot').addEventListener('click', keep(() => full()));
  $('mLock').addEventListener('click', (e) => { e.stopPropagation(); locked = true; document.body.classList.remove('m-show'); closeAudio(); subOpen = false; renderSubPop(); flashLock(); osd('تم قفل الشاشة'); });
  let lockT = null;
  function flashLock() { $('mLockL').classList.remove('hidden'); $('mUnlock').classList.add('show'); clearTimeout(lockT); lockT = setTimeout(() => $('mUnlock').classList.remove('show'), 2500); }
  $('mLockL').addEventListener('click', (e) => { e.stopPropagation(); flashLock(); });
  $('mUnlock').addEventListener('click', (e) => { e.stopPropagation(); if (!$('mUnlock').classList.contains('show')) { flashLock(); return; } locked = false; $('mLockL').classList.add('hidden'); osd('تم فتح القفل'); showUi(); });
  ['contextmenu', 'touchstart', 'touchmove'].forEach((ev) => $('mLockL').addEventListener(ev, (e) => { e.stopPropagation(); if (ev === 'contextmenu') e.preventDefault(); }, { passive: false }));

  // seek bar: dragging with the finger
  let sDrag = false;
  $('seek').addEventListener('touchstart', (e) => { if (!video.duration) return; sDrag = true; seekTo(frac(e.touches[0])); e.preventDefault(); e.stopPropagation(); showUi(true); }, { passive: false });
  $('seek').addEventListener('touchmove', (e) => { if (!sDrag) return; seekTo(frac(e.touches[0])); e.preventDefault(); }, { passive: false });
  $('seek').addEventListener('touchend', () => { sDrag = false; showUi(); });

  // brightness: the screen's own brightness when the app supports it, otherwise a dark layer over the video
  const nativeBright = (() => { try { return !!(window.Native && Native.caps && String(Native.caps()).includes('brightness')); } catch (e) { return false; } })();
  let bright = -1;
  function setBright(b) {
    bright = b;
    if (nativeBright) { try { Native.call('br' + Date.now(), 'brightness', JSON.stringify([b])); } catch (e) {} $('mDim').style.opacity = 0; }
    else $('mDim').style.opacity = b < 0 ? 0 : String((1 - b) * 0.85);
  }

  // gestures on the video: tap = controls, double tap at the sides = ±10 s, swipe up/down = volume (right side) or
  // brightness (left side), in both languages, swipe sideways = seek
  const ov = $('mOv');
  let g = null, lastTap = 0, tapT = null;
  const gest = (ic, f, txt) => { $('mGIc').innerHTML = sv(I[ic]); $('mGFill').style.height = Math.round(Math.max(0, Math.min(1, f)) * 100) + '%'; $('mGV').textContent = txt; $('mGest').classList.remove('hidden'); };
  ov.addEventListener('touchstart', (e) => {
    if (e.target.closest('button, .seekrow')) { g = null; return; }
    if (e.touches.length === 2) { // two fingers: zoom the picture
      if (!cfg('mPinch')) { g = null; return; }
      const [a, b] = e.touches; g = { mode: 'pinch', d0: Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY), z0: cfg('zoom') }; clearTimeout(tapT); return;
    }
    if (e.touches.length > 2) { g = null; return; }
    const t = e.touches[0];
    g = { x: t.clientX, y: t.clientY, mode: null, vol: cfg('master'), br: bright < 0 ? 0.5 : bright, pos: video.currentTime, to: video.currentTime };
  }, { passive: true });
  ov.addEventListener('touchmove', (e) => {
    if (!g) return;
    if (g.mode === 'pinch') {
      e.preventDefault();
      if (e.touches.length < 2) return;
      const [a, b] = e.touches, d = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
      const z = Math.round(Math.max(25, Math.min(400, g.z0 * d / g.d0)) / 5) * 5;
      if (z !== cfg('zoom')) { S.set.zoom = z; applyVideoLook(); osd('التكبير ' + ltr(z + '%'), 900); }
      return;
    }
    const t = e.touches[0], dx = t.clientX - g.x, dy = t.clientY - g.y, r = ov.getBoundingClientRect();
    if (!g.mode) {
      if (Math.hypot(dx, dy) < 16) return;
      g.mode = Math.abs(dx) > Math.abs(dy) ? (video.duration && cfg('mGSeek') ? 'seek' : 'none') : (g.x - r.left > r.width / 2 ? (cfg('mGVol') ? 'vol' : 'none') : (cfg('mGBright') ? 'bright' : 'none'));
    }
    e.preventDefault();
    if (g.mode === 'vol') { const mx = cfg('maxVol'); setVol(g.vol - (dy / (r.height * 0.6)) * 100); gest('vol', cfg('master') / mx, cfg('master') + '%'); }
    else if (g.mode === 'bright') { const b = Math.max(0.02, Math.min(1, g.br - dy / (r.height * 0.6))); setBright(b); gest('sun', b, Math.round(b * 100) + '%'); }
    else if (g.mode === 'seek') {
      const d = (RTL() ? -dx : dx) / r.width * Math.min(180, Math.max(30, video.duration));
      g.to = Math.max(0, Math.min(video.duration, g.pos + d));
      const s = Math.round(g.to - g.pos);
      osd(ltr(fmt(g.to)) + '  ' + ltr((s >= 0 ? '+' : '') + s + 's'), 1200);
    }
  }, { passive: false });
  ov.addEventListener('touchend', (e) => {
    if (!g) return;
    if (g.mode === 'pinch') { if (!e.touches.length) { save({ zoom: cfg('zoom') }); g = null; } return; }
    const m = g.mode, x = g.x; g.mode = m || 'tap';
    if (m === 'bright' && cfg('mKeepBright')) save({ mBrightV: bright });
    $('mGest').classList.add('hidden');
    if (m === 'seek') { video.currentTime = g.to; paintSeek(); }
    if (m && m !== 'tap') { g = null; return; }
    g = null;
    e.preventDefault();
    const r = ov.getBoundingClientRect(), f = (x - r.left) / r.width, now = Date.now();
    const toggleUi = () => { if (document.body.classList.contains('m-show')) { clearTimeout(hideT); document.body.classList.remove('m-show'); } else showUi(); };
    const dbl = cfg('mDbl');
    if (dbl === 'none') { toggleUi(); return; }
    if (now - lastTap < 300) {
      clearTimeout(tapT); lastTap = 0;
      const st = +cfg('mDblStep') || 10, fwd = RTL() ? f < 0.35 : f > 0.65, bwd = RTL() ? f > 0.65 : f < 0.35;
      if (dbl === 'seek' && fwd) rel(st); else if (dbl === 'seek' && bwd) rel(-st); else togglePlay();
      return;
    }
    lastTap = now;
    tapT = setTimeout(toggleUi, 280);
  }, { passive: false });
  ov.addEventListener('contextmenu', (e) => { if (g && g.mode) { e.preventDefault(); e.stopPropagation(); } }); // no menu after a swipe

  // ---------- audio tracks sheet ----------
  let audOpen = false;
  function renderAudio() {
    const n = S.tracks.length, sh = $('mSheet');
    sh.innerHTML = `<div class="m-grip"></div><div class="m-shead"><span><span>الأصوات</span> · <span dir="ltr">${n}</span> <span>${n === 1 ? 'مسار' : 'مسارات'}</span></span><button class="pbtn" id="mAudReset">إرجاع الكل</button></div>`;
    if (!n) { const d = document.createElement('div'); d.className = 'mix-none'; d.textContent = S.list[S.cur] ? 'هذا المقطع بدون صوت' : 'افتح مقطعاً أولاً'; sh.appendChild(d); }
    S.tracks.forEach((t) => sh.appendChild(trackRow(t)));
    $('mAudReset').addEventListener('click', () => { S.tracks.forEach((t) => { t.vol = 100; t.muted = false; t.gain.gain.setTargetAtTime(1, S.ctx.currentTime, 0.015); }); save({ trackVols: {} }); renderAudio(); });
  }
  function openAudio() { audOpen = true; renderAudio(); $('mSheetBg').classList.remove('hidden'); requestAnimationFrame(() => $('mSheetBg').classList.add('open')); }
  function closeAudio() { if (!audOpen) return; audOpen = false; $('mSheetBg').classList.remove('open'); $('mSheetBg').classList.add('hidden'); showUi(); }
  $('mSheetBg').addEventListener('click', (e) => { if (e.target === $('mSheetBg')) closeAudio(); });
  const _toggleTrack = toggleTrack;
  toggleTrack = function (i) { _toggleTrack(i); if (audOpen) renderAudio(); }; // eslint-disable-line no-global-assign

  // ---------- settings as Android lists: first the sections, then the chosen section with a back arrow ----------
  let navTop = 0, curSec = '';
  const secTop = {}; // where you were inside each section
  const _openPrefs = openPrefs;
  openPrefs = function (tab) { // eslint-disable-line no-global-assign
    _openPrefs(tab);
    const pr = document.querySelector('#sheet .prefs'), hd = document.querySelector('#sheet .sh-head');
    if (!pr || !hd) return;
    const ttl = hd.querySelector('span');
    hd.insertAdjacentHTML('afterbegin', btn('mPBack', 'back', 'رجوع', 'm-back'));
    const enter = (b) => {
      navTop = pr.querySelector('.pnav').scrollTop; pr.classList.add('insec'); hd.classList.add('insec'); ttl.textContent = b.textContent.trim();
      curSec = b.dataset.tab; requestAnimationFrame(() => { const pb = $('pBody'); if (pb) pb.scrollTop = secTop[curSec] || 0; });
    };
    pr.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => enter(b)));
    $('mPBack').addEventListener('click', leavePrefSec);
    if (tab) { const b = pr.querySelector(`[data-tab="${tab}"]`); if (b) enter(b); }
  };
  function leavePrefSec() {
    const pr = document.querySelector('#sheet .prefs.insec'); if (!pr) return false;
    const pb = $('pBody'); if (pb && curSec) secTop[curSec] = pb.scrollTop;
    pr.classList.remove('insec'); document.querySelector('#sheet .sh-head').classList.remove('insec');
    document.querySelector('#sheet .sh-head span').textContent = 'الإعدادات';
    pr.querySelector('.pnav').scrollTop = navTop; // back to the same place in the list
    return true;
  }

  // ---------- phone settings (ideas from MX Player) ----------
  const CAPS = (() => { try { return String(Native.caps()); } catch (e) { return ''; } })();
  const has = (k) => CAPS.split(',').includes(k);
  Object.assign(DEF, { mEnd: 'list', mOrient: 'auto', mKeepOn: true, mNoisy: true, mGVol: true, mGBright: true, mGSeek: true, mDbl: 'seek', mDblStep: '10', mHide: '3.5', mPinch: true, mKeepBright: false, mBrightV: -1, mThumbs: true, mShowDur: true, mLayout: 'list' });
  PC_ONLY.push('النقر المزدوج على الفيديو', 'إظهار قائمة التشغيل', 'تثبيت لوحة الأصوات تحت الفيديو', 'تشغيل المقطع التالي تلقائياً');
  NAV.splice(2, 0, ['phone', 'مشغل الهاتف', '<rect x="7" y="3" width="10" height="18" rx="2"/><path d="M11 18h2"/>'], ['library', 'المكتبة', '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>']);
  // themes: each one changes colours and shapes of everything (themes.css)
  const THEMES = [
    ['andoria', 'أندوريا الأزرق', { bg: '#05070A', card: '#171B24', line: '#2A3142', acc: '#2F6FED', txt: '#DDE2EC', r: '6px' }],
    ['amoled', 'أسود وذهبي', { bg: '#000', card: '#0D0D0D', line: '#3A3220', acc: '#E8B64C', txt: '#F3EEE4', r: '3px' }],
    ['glass', 'زجاج بنفسجي', { bg: 'linear-gradient(165deg,#1E1140,#0E1433 55%,#08202F)', card: '#ffffff14', line: '#ffffff30', acc: 'linear-gradient(135deg,#7B68EE,#3FC8E8)', txt: '#F1EEFF', r: '10px' }],
    ['light', 'أبيض احترافي', { bg: '#F3F5F9', card: '#FFFFFF', line: '#D5DBE6', acc: '#1A73E8', txt: '#18202E', r: '8px' }],
    ['esports', 'أحمر جيمنج', { bg: '#0D0F14', card: '#161920', line: '#2C303B', acc: '#FF4655', txt: '#ECE8E1', r: '0' }],
    ['mint', 'أخضر نعناعي', { bg: '#071513', card: '#0E2420', line: '#1D3D37', acc: '#2EE6A8', txt: '#E1F4EE', r: '10px' }],
  ];
  const curTheme = () => document.body.dataset.theme || 'andoria';
  function applyTheme(t) { document.body.dataset.theme = THEMES.some(([k]) => k === t) ? t : 'andoria'; try { localStorage.setItem('mTheme', document.body.dataset.theme); } catch (e) {} }
  applyTheme((() => { try { return localStorage.getItem('mTheme'); } catch (e) { return null; } })() || 'andoria');
  const themeRow = (c, w1, w2) => `<div class="r"><div class="th" style="background:${c.line};border-radius:${c.r}"></div><div style="flex:1"><div class="ln" style="background:${c.txt};width:${w1}%;opacity:.85"></div><div class="ln" style="background:${c.txt};width:${w2}%;opacity:.4;margin-top:4px"></div></div></div>`;
  document.addEventListener('click', (e) => { const b = e.target.closest('[data-theme-k]'); if (!b) return; applyTheme(b.dataset.themeK); save({ mTheme: curTheme() }); prefRefresh(); });
  NAV.splice(0, 0, ['theme', 'المظهر', '<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.3" class="fill"/><circle cx="12" cy="7.5" r="1.3" class="fill"/><circle cx="16" cy="10" r="1.3" class="fill"/><path d="M12 21a3 3 0 0 1 0-6h2a3 3 0 0 0 3-3"/>']);
  const _prefPage = prefPage;
  prefPage = function (tab) { // eslint-disable-line no-global-assign
    if (tab === 'phone') return `<h3>مشغل الهاتف</h3>
      ${row('بعد انتهاء الفيديو', selx('mEnd', [['list', 'الرجوع إلى القائمة'], ['next', 'تشغيل الفيديو التالي'], ['stop', 'البقاء في نهاية الفيديو']]), 'زر التكرار له الأولوية إذا كان مفعّلاً')}
      ${has('orient') ? row('اتجاه الشاشة أثناء التشغيل', selx('mOrient', [['auto', 'حسب دوران الهاتف'], ['video', 'حسب شكل الفيديو'], ['land', 'أفقي دائماً'], ['port', 'عمودي دائماً']])) : ''}
      ${has('keepOn') ? row('إبقاء الشاشة مضاءة أثناء التشغيل', sw('mKeepOn')) : ''}
      ${has('noisy') ? row('إيقاف مؤقت عند فصل السماعات', sw('mNoisy'), 'السلكية أو البلوتوث') : ''}
      ${row('إخفاء الأزرار بعد', selx('mHide', [['2', 'ثانيتين'], ['3.5', ltr('3.5') + ' ثوانٍ'], ['5', ltr('5') + ' ثوانٍ'], ['8', ltr('8') + ' ثوانٍ']]))}
      ${row('تذكّر موضع التوقف لكل فيديو', sw('rememberPos'))}
      <h3>اللمس</h3>
      ${row('السحب في اليمين يغيّر الصوت', sw('mGVol'))}
      ${row('السحب في اليسار يغيّر الإضاءة', sw('mGBright'))}
      ${row('تذكّر الإضاءة بين الفيديوهات', sw('mKeepBright'), 'عند الإيقاف: ترجع إضاءة الهاتف عند الخروج من الفيديو')}
      ${row('السحب أفقياً للتقديم والرجوع', sw('mGSeek'))}
      ${row('اللمس المزدوج', selx('mDbl', [['seek', 'تقديم ورجوع في الأطراف'], ['play', 'تشغيل / إيقاف مؤقت'], ['none', 'لا شيء']]), 'في وسط الشاشة: تشغيل / إيقاف مؤقت')}
      ${row('مقدار التقديم باللمس المزدوج', selx('mDblStep', [['5', ltr('5') + ' ثوانٍ'], ['10', ltr('10') + ' ثوانٍ'], ['15', ltr('15') + ' ثانية'], ['30', ltr('30') + ' ثانية']]))}
      ${row('التكبير بإصبعين', sw('mPinch'))}`;
    if (tab === 'theme') return `<h3>المظهر</h3><div class="m-themes">${THEMES.map(([k, t, c]) => `<button type="button" class="m-tcard${curTheme() === k ? ' on' : ''}" data-theme-k="${k}"><div class="m-tprev" style="background:${c.bg};border:1px solid ${c.line}">${themeRow(c, 82, 46)}${themeRow(c, 70, 38)}<div class="bt" style="background:${c.acc};border-radius:${c.r}"></div></div><div class="tn">${t}</div></button>`).join('')}</div>`;
    if (tab === 'library') return `<h3>المكتبة</h3>
      ${row('طريقة العرض', selx('mLayout', LAYOUTS))}
      ${row('الترتيب', selx('sort', SORTS))}
      ${row('الصور المصغّرة', sw('mThumbs'))}
      ${row('إظهار مدة كل فيديو', sw('mShowDur'))}`;
    return _prefPage(tab);
  };
  const _afterPref = afterPref;
  afterPref = function (k) { // eslint-disable-line no-global-assign
    _afterPref(k);
    if (k === 'sort' || /^m(Layout|Thumbs|ShowDur)$/.test(k)) { libSig = ''; renderLib(); }
    if (k === 'mOrient') applyOrient();
    if (k === 'mKeepOn') applyKeep();
    if (k === 'mKeepBright' && !cfg('mKeepBright')) save({ mBrightV: -1 });
  };
  function applyOrient() {
    if (!has('orient') || document.body.classList.contains('full')) return;
    let o = document.body.classList.contains('m-lib') ? 'auto' : cfg('mOrient');
    if (o === 'video') o = video.videoWidth && video.videoHeight ? (video.videoWidth >= video.videoHeight ? 'land' : 'port') : 'auto';
    ap.orient(o);
  }
  const applyKeep = () => { if (has('keepOn')) ap.keepOn(!!cfg('mKeepOn') && !video.paused && !video.ended); };
  video.addEventListener('loadedmetadata', applyOrient);
  ['play', 'pause', 'ended'].forEach((ev) => video.addEventListener(ev, applyKeep));
  ap.onFullState((on) => { if (!on) setTimeout(applyOrient, 50); });
  if (ap.onNoisy) ap.onNoisy(() => { if (cfg('mNoisy') && !video.paused) { video.pause(); osd('توقف مؤقت: فُصلت السماعات'); } });
  // end of a video: back to the list, play the next one, or stay at the end
  window.onClipEnded = () => {
    if (cfg('repeat') === 'all') return false;
    const e = cfg('mEnd');
    if (e === 'next') { const n = nextIndex(true); if (n != null) { playIndex(n); return true; } }
    if (e === 'list' || e === 'next') { showLib(); return true; }
    showUi(true); return true;
  };
  // a tap outside an open menu or the subtitles window only closes it (it does not press what is under it)
  let swallow = false;
  document.addEventListener('touchstart', (e) => {
    if (!$('modal').classList.contains('hidden') && !e.target.closest('#menu, #menu2')) { if (!$('menu').classList.contains('hidden')) { hideMenu(); swallow = true; e.stopPropagation(); } return; }
    const inMenu = e.target.closest('#menu, #menu2');
    if (!$('menu').classList.contains('hidden') && !inMenu) { hideMenu(); swallow = true; e.stopPropagation(); return; }
    if (subOpen && !e.target.closest('#subPop, #mSub')) { subOpen = false; renderSubPop(); swallow = true; e.stopPropagation(); showUi(); }
  }, { capture: true, passive: true });
  document.addEventListener('touchend', (e) => { if (swallow) { swallow = false; if (e.cancelable) e.preventDefault(); e.stopPropagation(); } }, { capture: true, passive: false });
  document.addEventListener('touchmove', (e) => { if (swallow) e.stopPropagation(); }, { capture: true, passive: true });

  // ---------- choice lists in the app's own look (instead of the phone's grey system list) ----------
  // every <select> anywhere in the app becomes a framed button; tapping it opens a sheet from the bottom with
  // each choice in its own frame. The real <select> stays hidden underneath, so the existing code keeps working.
  document.body.insertAdjacentHTML('beforeend', '<div id="mPickBg" class="m-sheetbg m-pick hidden"><div id="mPick" class="m-sheet"></div></div>');
  let pickSel = null;
  const selLabel = (sel) => { const o = sel.options[sel.selectedIndex]; return o ? o.textContent : ''; };
  function dressSelect(sel) {
    if (sel.dataset.dressed) return;
    sel.dataset.dressed = '1';
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'm-selbtn';
    b.innerHTML = '<span class="t"></span><svg viewBox="0 0 24 24"><path d="M7 10l5 5 5-5"/></svg>';
    if (sel.style.flex) b.style.flex = sel.style.flex;
    sel.insertAdjacentElement('afterend', b);
    const paint = () => { b.querySelector('.t').textContent = selLabel(sel); b.disabled = sel.disabled; };
    paint();
    sel.addEventListener('change', paint);
    new MutationObserver(paint).observe(sel, { childList: true, subtree: true, characterData: true, attributes: true });
    b.addEventListener('click', (e) => { e.stopPropagation(); openPick(sel); });
  }
  function openPick(sel) {
    pickSel = sel;
    const rowEl = sel.closest('.prow'), lab = rowEl ? rowEl.querySelector('.l') : null;
    const title = lab ? (lab.firstChild && lab.firstChild.nodeType === 3 ? lab.firstChild.textContent : lab.textContent).trim() : '';
    const sh = $('mPick');
    sh.innerHTML = `<div class="m-grip"></div>${title ? '<div class="m-shead"><span></span></div>' : ''}<div class="m-opts"></div>`;
    if (title) sh.querySelector('.m-shead span').textContent = title;
    const box = sh.querySelector('.m-opts');
    [...sel.options].forEach((o, i) => {
      const it = document.createElement('button');
      it.type = 'button'; it.className = 'm-opt' + (i === sel.selectedIndex ? ' on' : '');
      it.innerHTML = '<span class="t"></span><span class="ck"></span>';
      it.querySelector('.t').textContent = o.textContent;
      if (o.disabled) it.disabled = true;
      it.addEventListener('click', () => {
        const pane = $('pBody'), top = pane ? pane.scrollTop : 0;
        closePick();
        if (sel.selectedIndex !== i) { sel.selectedIndex = i; sel.dispatchEvent(new Event('change', { bubbles: true })); }
        if (pane && $('pBody') === pane) pane.scrollTop = top; // stay at the same place in the settings
      });
      box.appendChild(it);
    });
    $('mPickBg').classList.remove('hidden');
    requestAnimationFrame(() => { $('mPickBg').classList.add('open'); const on = box.querySelector('.on'); if (on) on.scrollIntoView({ block: 'center' }); });
  }
  function closePick() { if (!pickSel) return false; pickSel = null; $('mPickBg').classList.remove('open'); $('mPickBg').classList.add('hidden'); return true; }
  $('mPickBg').addEventListener('click', (e) => { if (e.target === $('mPickBg')) closePick(); });
  document.querySelectorAll('select').forEach(dressSelect);
  new MutationObserver((ms) => ms.forEach((m) => m.addedNodes.forEach((n) => {
    if (n.nodeType !== 1) return;
    if (n.tagName === 'SELECT') dressSelect(n); else n.querySelectorAll && n.querySelectorAll('select').forEach(dressSelect);
  }))).observe(document.body, { childList: true, subtree: true });

  // ---------- phone back button ----------
  const _back = window.appBack;
  window.appBack = () => {
    if (closePick()) return true;
    if (locked) { flashLock(); return true; }
    if (audOpen) { closeAudio(); return true; }
    if (!$('modal').classList.contains('hidden') && $('menu').classList.contains('hidden') && leavePrefSec()) return true;
    S.set.showList = false; // the Windows playlist panel is never used here
    if (_back()) return true;
    if (!document.body.classList.contains('m-lib')) { showLib(); return true; }
    if (!$('mSearch').classList.contains('hidden')) { $('mSearch').value = ''; $('mSearch').classList.add('hidden'); renderLib(); return true; }
    if (leaveFolder()) return true;
    return false;
  };

  // start on the library; opening a clip (or restoring the session) switches to the player
  document.body.classList.add('m-lib');
  renderLib(); paintPlay();
})();
