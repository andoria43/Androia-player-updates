'use strict';
// Android phone interface (does nothing on Windows): a library screen with the clips, the video full screen
// with controls over it that hide by themselves, swipe gestures (volume, brightness, seek), a lock,
// the audio tracks in a sheet that slides up from the bottom, and the settings as Android-style lists.
// It reuses the player engine of app.js (same tracks, export, subtitles, updates, session).
(function () {
  if (!ANDROID) return;
  document.body.classList.add('m');
  const sv = (d) => `<svg viewBox="0 0 24 24">${d}</svg>`;
  const I = {
    back: '<path d="M9 5l7 7-7 7"/>',
    search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>',
    sort: '<path d="M7 4v16M3 16l4 4 4-4M14 6h7M14 12h5M14 18h3"/>',
    gear: '<path d="M10.3 4.3c.4-1.8 2.9-1.8 3.4 0a1.7 1.7 0 0 0 2.6 1.1c1.5-.9 3.3.8 2.4 2.4a1.7 1.7 0 0 0 1 2.5c1.8.4 1.8 2.9 0 3.4a1.7 1.7 0 0 0-1 2.6c.9 1.5-.8 3.3-2.4 2.4a1.7 1.7 0 0 0-2.6 1c-.4 1.8-2.9 1.8-3.4 0a1.7 1.7 0 0 0-2.6-1c-1.5.9-3.3-.8-2.4-2.4a1.7 1.7 0 0 0-1-2.6c-1.8-.4-1.8-2.9 0-3.4a1.7 1.7 0 0 0 1-2.5c-.9-1.6.8-3.3 2.4-2.4 1 .6 2.3.1 2.6-1.1z"/><circle cx="12" cy="12" r="3"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 10v6M9 13h6"/>',
    audio: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
    subs: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 10.5a2 2 0 1 0 0 3M17 10.5a2 2 0 1 0 0 3"/>',
    more: '<circle cx="12" cy="5" r="1.4" class="fill"/><circle cx="12" cy="12" r="1.4" class="fill"/><circle cx="12" cy="19" r="1.4" class="fill"/>',
    prev: '<path d="M6 6v12"/><path d="M18 6v12l-9-6z" class="fill"/>',
    next: '<path d="M18 6v12"/><path d="M6 6v12l9-6z" class="fill"/>',
    play: '<path d="M8 5v14l11-7z" class="fill"/>',
    pause: '<rect x="6" y="5" width="4" height="14" rx="1" class="fill"/><rect x="14" y="5" width="4" height="14" rx="1" class="fill"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    repeat: '<path d="M4 12V9a3 3 0 0 1 3-3h12l-3-3M20 12v3a3 3 0 0 1-3 3H5l3 3"/>',
    aspect: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 11V9h3M17 13v2h-3"/>',
    shot: '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>',
    rotate: '<rect x="7" y="3" width="10" height="18" rx="2"/><path d="M2 14a9 9 0 0 0 6 7M22 10a9 9 0 0 0-6-7"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
    vol: '<path d="M4 9h4l5-4v14l-5-4H4z" class="fill"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
    spk: '<path d="M4 9h4l5-4v14l-5-4H4z" class="fill"/><path d="M16 9a4 4 0 0 1 0 6"/>',
    film: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 9.5v5l4.5-2.5z" class="fill"/>',
  };
  const btn = (id, ic, title, cls = '') => `<button class="ib ${cls}" id="${id}" title="${title}">${sv(I[ic])}</button>`;

  // ---------- the screens ----------
  document.body.insertAdjacentHTML('beforeend', `
  <div id="mLib" class="mlib">
    <div class="m-top">${btn('mLibBack', 'back', 'رجوع', 'm-back hidden')}<span class="m-title">أندوريا بلاير</span>${btn('mSearchB', 'search', 'بحث')}${btn('mSortB', 'sort', 'الترتيب')}${btn('mSetB', 'gear', 'الإعدادات')}</div>
    <input id="mSearch" class="m-search hidden" type="search" placeholder="بحث">
    <div id="mInfo" class="m-info"></div>
    <div id="mItems" class="m-items"></div>
    <button id="mNow" class="m-now hidden">${sv(I.play)}<span class="nm" id="mNowName" dir="ltr"></span></button>
    <button id="mFab" class="m-fab" title="فتح">${sv(I.folder)}</button>
  </div>
  <div id="mSheetBg" class="m-sheetbg hidden"><div id="mSheet" class="m-sheet"></div></div>`);
  $('stage').insertAdjacentHTML('beforeend', `
  <div id="mDim" class="m-dim"></div>
  <div id="mOv" class="mov">
    <div class="m-top m-ovtop">${btn('mBack', 'back', 'رجوع', 'm-back')}<div id="mName" class="m-name" dir="ltr"></div>
      <button class="ib" id="mAud" title="الأصوات">${sv(I.audio)}<span id="mAudN" class="cnt hidden" dir="ltr"></span></button>${btn('mSub', 'subs', 'الترجمة')}${btn('mMore', 'more', 'المزيد')}</div>
    <div class="m-mid">${btn('mPrev', 'prev', 'السابق')}<button class="ib m-play" id="mPlay" title="تشغيل / إيقاف مؤقت">${sv(I.play)}</button>${btn('mNext', 'next', 'التالي')}</div>
    <div class="m-bot"><div id="mSeekSlot"></div>
      <div class="m-row">${btn('mLock', 'lock', 'قفل الشاشة')}<button class="ib" id="mRep" title="التكرار">${sv(I.repeat)}<span id="mRepOne" class="cnt hidden" dir="ltr">1</span></button>${btn('mAsp', 'aspect', 'نسبة العرض')}${btn('mShot', 'shot', 'لقطة')}${btn('mRot', 'rotate', 'تدوير الشاشة')}</div></div>
  </div>
  <div id="mLockL" class="m-lockl hidden"><button class="ib" id="mUnlock" title="فتح القفل">${sv(I.lock)}</button></div>
  <div id="mGest" class="m-gest hidden"><span id="mGIc"></span><div class="m-gbar"><b id="mGFill"></b></div><span id="mGV" dir="ltr"></span></div>`);
  $('mSeekSlot').appendChild(document.querySelector('.seekrow')); // the same seek bar and times, now inside the overlay
  // the Windows playlist panel is replaced by the library screen
  S.set.showList = false; document.body.classList.add('no-list');
  toggleList = () => showLib(); // eslint-disable-line no-global-assign

  // ---------- library ----------
  const TH = {}; // path -> { img, dur }
  try { Object.assign(TH, JSON.parse(localStorage.getItem('mThumbs') || '{}')); } catch (e) {}
  const thFail = new Set(), thQ = [];
  let thBusy = false, thSaveT = null;
  const persist = () => { clearTimeout(thSaveT); thSaveT = setTimeout(() => { try { const k = Object.keys(TH); k.slice(0, Math.max(0, k.length - 300)).forEach((x) => delete TH[x]); localStorage.setItem('mThumbs', JSON.stringify(TH)); } catch (e) {} }, 800); };
  function needThumb(c) { if (TH[c.path] || thFail.has(c.path) || thQ.includes(c.path)) return; thQ.push(c.path); runThumb(); }
  function runThumb() {
    if (thBusy || !thQ.length) return;
    thBusy = true;
    const p = thQ.shift(), v = document.createElement('video');
    v.muted = true; v.preload = 'auto'; if (window.AP_MEDIA_CROSS) v.crossOrigin = 'anonymous';
    let over = false;
    const fin = (data) => {
      if (over) return; over = true; clearTimeout(to);
      if (data) { TH[p] = data; persist(); paintThumb(p); } else thFail.add(p);
      v.removeAttribute('src'); v.load(); thBusy = false; setTimeout(runThumb, 30);
    };
    const to = setTimeout(() => fin(null), 9000);
    v.addEventListener('loadedmetadata', () => { v.currentTime = Math.min(1.5, (v.duration || 3) / 3); });
    v.addEventListener('seeked', () => {
      try { const cv = document.createElement('canvas'); cv.width = 160; cv.height = 90; cv.getContext('2d').drawImage(v, 0, 0, 160, 90); fin({ img: cv.toDataURL('image/jpeg', 0.6), dur: v.duration || 0 }); }
      catch (e) { fin({ img: '', dur: v.duration || 0 }); }
    });
    v.addEventListener('error', () => fin(null));
    v.src = ap.fileUrl(p);
  }
  const TRK = {}; // path -> number of audio tracks, known once the clip was opened
  function thumbHtml(p) { const t = TH[p]; return `${t && t.img ? `<img src="${t.img}" alt="">` : sv(I.film)}${t && t.dur ? `<span class="du" dir="ltr">${fmt(t.dur)}</span>` : ''}`; }
  function paintThumb(p) { const el = [...$('mItems').querySelectorAll('.m-th')].find((x) => x.dataset.p === p); if (el) el.innerHTML = thumbHtml(p); }
  function renderLib() {
    const box = $('mItems'), top = box.scrollTop, q = $('mSearch').value.trim().toLowerCase();
    const n = S.list.length, dir = cfg('lastDir') ? ap.basename(cfg('lastDir')) : '';
    $('mInfo').innerHTML = n ? `<span>المقاطع</span> <span dir="ltr">(${n})</span>${dir ? ` · <span data-notr dir="auto">${esc(dir)}</span>` : ''}` : '';
    box.innerHTML = '';
    if (!n) {
      box.innerHTML = `<div class="m-empty">${sv(I.film)}<div>لا توجد مقاطع بعد</div><button class="pbtn accent" id="mE1">فتح ملف</button><button class="pbtn" id="mE2">فتح مجلد</button></div>`;
      $('mE1').addEventListener('click', pickFiles); $('mE2').addEventListener('click', pickFolder);
      return;
    }
    S.list.forEach((c, i) => {
      if (q && !c.name.toLowerCase().includes(q)) return;
      const el = document.createElement('div');
      el.className = 'm-it' + (i === S.cur ? ' on' : '');
      const k = TRK[c.path];
      el.innerHTML = `<div class="m-th">${thumbHtml(c.path)}</div><div class="tx"><div class="nm" dir="ltr"></div><div class="dt">${stamp(c.mtime)}${k != null ? ` · <span class="tk" dir="ltr">${k}</span>${sv(I.spk)}` : ''}${c.sub ? ` · <span data-notr>${esc(c.sub)}</span>` : ''}</div></div>`;
      el.querySelector('.m-th').dataset.p = c.path;
      el.querySelector('.nm').textContent = c.name;
      el.addEventListener('click', () => { if (i === S.cur && video.src) showPlayer(); else playIndex(i); });
      el.addEventListener('contextmenu', (e) => { e.preventDefault(); e.stopPropagation(); showMenu(e, [
        { t: 'تشغيل', fn: () => playIndex(i) },
        { t: 'إزالة من القائمة', fn: () => removeAt(i) },
      ]); });
      box.appendChild(el);
      needThumb(c);
    });
    box.scrollTop = top;
  }
  const _renderList = renderList;
  renderList = function (keep) { _renderList(keep); renderLib(); }; // eslint-disable-line no-global-assign

  let libTop = 0;
  function showLib() {
    if (document.body.classList.contains('m-lib')) return;
    if (!video.paused) video.pause();
    if (document.body.classList.contains('full')) ap.exitFullscreen();
    closeAudio(); subOpen = false; renderSubPop();
    setBright(-1);
    document.body.classList.add('m-lib');
    const it = S.list[S.cur];
    $('mNow').classList.toggle('hidden', !it || !video.src);
    if (it) $('mNowName').textContent = it.name;
    $('mItems').scrollTop = libTop;
  }
  function showPlayer() {
    if (!document.body.classList.contains('m-lib')) return;
    libTop = $('mItems').scrollTop;
    document.body.classList.remove('m-lib');
    showUi();
  }
  $('mLibBack').addEventListener('click', showPlayer);
  $('mNow').addEventListener('click', () => { showPlayer(); video.play().catch(() => {}); });
  $('mSetB').addEventListener('click', () => openPrefs());
  $('mSearchB').addEventListener('click', () => { const s = $('mSearch'); s.classList.toggle('hidden'); if (!s.classList.contains('hidden')) s.focus(); else { s.value = ''; renderLib(); } });
  $('mSearch').addEventListener('input', renderLib);
  $('mSortB').addEventListener('click', (e) => showMenu(e, [['new', 'الأحدث أولاً'], ['old', 'الأقدم أولاً'], ['name', 'حسب الاسم']].map(([v, t]) => ({ t, chk: cfg('sort') === v, fn: () => {
    save({ sort: v });
    const p = S.list[S.cur] && S.list[S.cur].path;
    sortList(S.list); S.cur = p ? S.list.findIndex((x) => x.path === p) : -1;
    renderList(); $('mItems').scrollTop = 0; // the list starts again from its top
  } }))));
  $('mFab').addEventListener('click', (e) => showMenu(e, [
    { t: 'فتح ملف…', fn: pickFiles },
    { t: 'فتح مجلد…', fn: pickFolder },
    { t: 'إضافة ملفات', fn: async () => { const f = await ap.pickFile(cfg('lastDir')); if (f && f.length) addFiles(f); } },
  ]));

  // ---------- player ----------
  const _playIndex = playIndex;
  playIndex = function (i, opt) { const it = S.list[i]; if (it) $('mName').textContent = it.name; showPlayer(); return _playIndex(i, opt); }; // eslint-disable-line no-global-assign
  const _buildTracks = buildTracks;
  buildTracks = function (info) { // eslint-disable-line no-global-assign
    _buildTracks(info);
    const n = S.tracks.length, it = S.list[S.cur];
    $('mAudN').textContent = n; $('mAudN').classList.toggle('hidden', n < 2);
    if (it && TRK[it.path] !== n) { TRK[it.path] = n; renderLib(); }
    if (audOpen) renderAudio();
  };
  const paintPlay = () => { $('mPlay').innerHTML = sv(video.paused ? I.play : I.pause); };
  video.addEventListener('play', () => { paintPlay(); showUi(); });
  video.addEventListener('pause', () => { paintPlay(); showUi(true); });
  const paintRep = () => { const r = cfg('repeat'); $('mRep').classList.toggle('on', r !== 'off'); $('mRepOne').classList.toggle('hidden', r !== 'one'); };
  const _paintModes = paintModes;
  paintModes = function () { _paintModes(); paintRep(); }; // eslint-disable-line no-global-assign
  paintRep();

  // controls over the video: shown on a tap, hidden after 3.5 s while playing
  let hideT = null, locked = false;
  function showUi(stay) {
    if (locked) return;
    document.body.classList.add('m-show');
    clearTimeout(hideT);
    if (!stay && !video.paused) hideT = setTimeout(hideUi, 3500);
  }
  function hideUi() { if (audOpen || subOpen || !$('menu').classList.contains('hidden')) { showUi(); return; } document.body.classList.remove('m-show'); }
  const keep = (fn) => (e) => { e.stopPropagation(); fn(e); showUi(); };
  $('mBack').addEventListener('click', keep(showLib));
  $('mPlay').addEventListener('click', keep(() => togglePlay()));
  $('mPrev').addEventListener('click', keep(() => $('bPrev').click())); // same behaviour as the Windows buttons
  $('mNext').addEventListener('click', keep(() => $('bNext').click()));
  $('mAud').addEventListener('click', keep(() => { subOpen = false; renderSubPop(); openAudio(); }));
  $('mSub').addEventListener('click', keep(() => { closeAudio(); subOpen = !subOpen; renderSubPop(); }));
  $('mMore').addEventListener('click', (e) => { e.stopPropagation(); $('stage').dispatchEvent(new MouseEvent('contextmenu', { clientX: e.clientX, clientY: e.clientY, bubbles: true })); showUi(); });
  $('mRep').addEventListener('click', keep(cycleRepeat));
  const ASP = [['contain', 'نسبة أصلية'], ['cover', 'ملء مع قص الحواف'], ['fill', 'تمديد لملء الشاشة'], ['16:9', '16:9'], ['4:3', '4:3']];
  $('mAsp').addEventListener('click', keep(() => { const i = ASP.findIndex(([v]) => v === cfg('aspect')); const [v, t] = ASP[(i + 1) % ASP.length]; vset({ aspect: v }, /\d/.test(t) ? ltr(t) : t); }));
  $('mShot').addEventListener('click', keep(() => shot()));
  $('mRot').addEventListener('click', keep(() => full()));
  $('mLock').addEventListener('click', (e) => { e.stopPropagation(); locked = true; document.body.classList.remove('m-show'); closeAudio(); subOpen = false; renderSubPop(); flashLock(); osd('تم قفل الشاشة'); });
  let lockT = null;
  function flashLock() { $('mLockL').classList.remove('hidden'); $('mUnlock').classList.add('show'); clearTimeout(lockT); lockT = setTimeout(() => $('mUnlock').classList.remove('show'), 2500); }
  $('mLockL').addEventListener('click', (e) => { e.stopPropagation(); flashLock(); });
  $('mUnlock').addEventListener('click', (e) => { e.stopPropagation(); if (!$('mUnlock').classList.contains('show')) { flashLock(); return; } locked = false; $('mLockL').classList.add('hidden'); osd('تم فتح القفل'); showUi(); });
  ['contextmenu', 'touchstart', 'touchmove'].forEach((ev) => $('mLockL').addEventListener(ev, (e) => { e.stopPropagation(); if (ev === 'contextmenu') e.preventDefault(); }, { passive: false }));

  // seek bar: dragging with the finger
  let sDrag = false;
  $('seek').addEventListener('touchstart', (e) => { if (!video.duration) return; sDrag = true; seekTo(frac(e.touches[0])); e.preventDefault(); e.stopPropagation(); showUi(true); }, { passive: false });
  $('seek').addEventListener('touchmove', (e) => { if (!sDrag) return; seekTo(frac(e.touches[0])); e.preventDefault(); }, { passive: false });
  $('seek').addEventListener('touchend', () => { sDrag = false; showUi(); });

  // brightness: the screen's own brightness when the app supports it, otherwise a dark layer over the video
  const nativeBright = (() => { try { return !!(window.Native && Native.caps && String(Native.caps()).includes('brightness')); } catch (e) { return false; } })();
  let bright = -1;
  function setBright(b) {
    bright = b;
    if (nativeBright) { try { Native.call('br' + Date.now(), 'brightness', JSON.stringify([b])); } catch (e) {} $('mDim').style.opacity = 0; }
    else $('mDim').style.opacity = b < 0 ? 0 : String((1 - b) * 0.85);
  }

  // gestures on the video: tap = controls, double tap at the sides = ±10 s, swipe up/down = volume (left) or
  // brightness (right), swipe sideways = seek
  const ov = $('mOv');
  let g = null, lastTap = 0, tapT = null;
  const gest = (ic, f, txt) => { $('mGIc').innerHTML = sv(I[ic]); $('mGFill').style.height = Math.round(Math.max(0, Math.min(1, f)) * 100) + '%'; $('mGV').textContent = txt; $('mGest').classList.remove('hidden'); };
  ov.addEventListener('touchstart', (e) => {
    if (e.target.closest('button, .seekrow') || e.touches.length > 1) { g = null; return; }
    const t = e.touches[0];
    g = { x: t.clientX, y: t.clientY, mode: null, vol: cfg('master'), br: bright < 0 ? 0.5 : bright, pos: video.currentTime, to: video.currentTime };
  }, { passive: true });
  ov.addEventListener('touchmove', (e) => {
    if (!g) return;
    const t = e.touches[0], dx = t.clientX - g.x, dy = t.clientY - g.y, r = ov.getBoundingClientRect();
    if (!g.mode) {
      if (Math.hypot(dx, dy) < 16) return;
      g.mode = Math.abs(dx) > Math.abs(dy) ? (video.duration ? 'seek' : 'none') : (g.x - r.left > r.width / 2 ? 'bright' : 'vol');
    }
    e.preventDefault();
    if (g.mode === 'vol') { const mx = cfg('maxVol'); setVol(g.vol - (dy / (r.height * 0.6)) * 100); gest('vol', cfg('master') / mx, cfg('master') + '%'); }
    else if (g.mode === 'bright') { const b = Math.max(0.02, Math.min(1, g.br - dy / (r.height * 0.6))); setBright(b); gest('sun', b, Math.round(b * 100) + '%'); }
    else if (g.mode === 'seek') {
      const d = (RTL() ? -dx : dx) / r.width * Math.min(180, Math.max(30, video.duration));
      g.to = Math.max(0, Math.min(video.duration, g.pos + d));
      const s = Math.round(g.to - g.pos);
      osd(ltr(fmt(g.to)) + '  ' + ltr((s >= 0 ? '+' : '') + s + 's'), 1200);
    }
  }, { passive: false });
  ov.addEventListener('touchend', (e) => {
    if (!g) return;
    const m = g.mode, x = g.x; g.mode = m || 'tap';
    $('mGest').classList.add('hidden');
    if (m === 'seek') { video.currentTime = g.to; paintSeek(); }
    if (m && m !== 'tap') { g = null; return; }
    g = null;
    e.preventDefault();
    const r = ov.getBoundingClientRect(), f = (x - r.left) / r.width, now = Date.now();
    if (now - lastTap < 300) {
      clearTimeout(tapT); lastTap = 0;
      const fwd = RTL() ? f < 0.35 : f > 0.65, bwd = RTL() ? f > 0.65 : f < 0.35;
      if (fwd) rel(10); else if (bwd) rel(-10); else togglePlay();
      return;
    }
    lastTap = now;
    tapT = setTimeout(() => { if (document.body.classList.contains('m-show')) { clearTimeout(hideT); document.body.classList.remove('m-show'); } else showUi(); }, 280);
  }, { passive: false });
  ov.addEventListener('contextmenu', (e) => { if (g && g.mode) { e.preventDefault(); e.stopPropagation(); } }); // no menu after a swipe

  // ---------- audio tracks sheet ----------
  let audOpen = false;
  function renderAudio() {
    const n = S.tracks.length, sh = $('mSheet');
    sh.innerHTML = `<div class="m-grip"></div><div class="m-shead"><span><span>الأصوات</span> · <span dir="ltr">${n}</span> <span>${n === 1 ? 'مسار' : 'مسارات'}</span></span><button class="pbtn" id="mAudReset">إرجاع الكل</button></div>`;
    if (!n) { const d = document.createElement('div'); d.className = 'mix-none'; d.textContent = S.list[S.cur] ? 'هذا المقطع بدون صوت' : 'افتح مقطعاً أولاً'; sh.appendChild(d); }
    S.tracks.forEach((t) => sh.appendChild(trackRow(t)));
    $('mAudReset').addEventListener('click', () => { S.tracks.forEach((t) => { t.vol = 100; t.muted = false; t.gain.gain.setTargetAtTime(1, S.ctx.currentTime, 0.015); }); save({ trackVols: {} }); renderAudio(); });
  }
  function openAudio() { audOpen = true; renderAudio(); $('mSheetBg').classList.remove('hidden'); requestAnimationFrame(() => $('mSheetBg').classList.add('open')); }
  function closeAudio() { if (!audOpen) return; audOpen = false; $('mSheetBg').classList.remove('open'); $('mSheetBg').classList.add('hidden'); showUi(); }
  $('mSheetBg').addEventListener('click', (e) => { if (e.target === $('mSheetBg')) closeAudio(); });
  const _toggleTrack = toggleTrack;
  toggleTrack = function (i) { _toggleTrack(i); if (audOpen) renderAudio(); }; // eslint-disable-line no-global-assign

  // ---------- settings as Android lists: first the sections, then the chosen section with a back arrow ----------
  let navTop = 0;
  const _openPrefs = openPrefs;
  openPrefs = function (tab) { // eslint-disable-line no-global-assign
    _openPrefs(tab);
    const pr = document.querySelector('#sheet .prefs'), hd = document.querySelector('#sheet .sh-head');
    if (!pr || !hd) return;
    const ttl = hd.querySelector('span');
    hd.insertAdjacentHTML('afterbegin', btn('mPBack', 'back', 'رجوع', 'm-back'));
    const enter = (b) => { navTop = pr.querySelector('.pnav').scrollTop; pr.classList.add('insec'); hd.classList.add('insec'); ttl.textContent = b.textContent.trim(); };
    pr.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => enter(b)));
    $('mPBack').addEventListener('click', leavePrefSec);
    if (tab) { const b = pr.querySelector(`[data-tab="${tab}"]`); if (b) enter(b); }
  };
  function leavePrefSec() {
    const pr = document.querySelector('#sheet .prefs.insec'); if (!pr) return false;
    pr.classList.remove('insec'); document.querySelector('#sheet .sh-head').classList.remove('insec');
    document.querySelector('#sheet .sh-head span').textContent = 'الإعدادات';
    pr.querySelector('.pnav').scrollTop = navTop; // back to the same place in the list
    return true;
  }

  // ---------- phone back button ----------
  const _back = window.appBack;
  window.appBack = () => {
    if (locked) { flashLock(); return true; }
    if (audOpen) { closeAudio(); return true; }
    if (!$('modal').classList.contains('hidden') && $('menu').classList.contains('hidden') && leavePrefSec()) return true;
    S.set.showList = false; // the Windows playlist panel is never used here
    if (_back()) return true;
    if (!document.body.classList.contains('m-lib')) { showLib(); return true; }
    if (!$('mSearch').classList.contains('hidden')) { $('mSearch').value = ''; $('mSearch').classList.add('hidden'); renderLib(); return true; }
    return false;
  };

  // start on the library; opening a clip (or restoring the session) switches to the player
  document.body.classList.add('m-lib');
  renderLib(); paintPlay();
})();
