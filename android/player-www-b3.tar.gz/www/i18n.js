'use strict';
// English interface. Arabic stays the source text; when the language is English every text node,
// tooltip and placeholder is translated as it appears (dynamic rows and messages included).
(function () {
  const lang = new URLSearchParams(location.search).get('lang') === 'en' ? 'en' : 'ar';
  window.UI_LANG = lang;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'en' ? 'ltr' : 'rtl';
  if (lang !== 'en') { window.TR = (s) => s; return; }

  const D = {
    // window, empty screen, playlist
    'أندوريا بلاير': 'Andoria Player', 'تصغير': 'Minimize', 'تكبير': 'Maximize', 'إغلاق': 'Close',
    'اسحب فيديو أو مجلداً إلى هنا': 'Drop a video or a folder here', 'فتح ملف': 'Open file', 'فتح مجلد': 'Open folder',
    'جاري تجهيز الأصوات…': 'Preparing audio tracks…', 'قائمة التشغيل': 'Playlist', 'إضافة ملفات': 'Add files',
    'تفريغ القائمة': 'Clear playlist', 'إغلاق (F6)': 'Close (F6)', 'بحث': 'Search', 'القائمة فارغة': 'The playlist is empty',
    'افتح ملفاً أو مجلداً': 'Open a file or a folder', 'إظهار في المجلد': 'Show in folder', 'إزالة من القائمة': 'Remove from playlist',
    'لا توجد فيديوهات في هذا المجلد': 'No videos in this folder',
    // phone interface (mobile.js)
    'المقاطع': 'Clips', 'لا توجد مقاطع بعد': 'No clips yet', 'فتح': 'Open', 'الأصوات': 'Audio tracks', 'السابق': 'Previous', 'التالي': 'Next',
    'تشغيل / إيقاف مؤقت': 'Play / Pause', 'قفل الشاشة': 'Lock screen', 'فتح القفل': 'Unlock', 'نسبة العرض': 'Aspect ratio', 'تدوير الشاشة': 'Rotate screen',
    'تم قفل الشاشة': 'Screen locked', 'تم فتح القفل': 'Unlocked', 'مسار': 'track', 'مسارات': 'tracks',
    // control bar tooltips
    'تشغيل / إيقاف مؤقت (مسافة)': 'Play / Pause (Space)', 'إيقاف': 'Stop', 'السابق (PgUp)': 'Previous (PgUp)', 'التالي (PgDn)': 'Next (PgDn)',
    'فتح ملف (Ctrl+O)': 'Open file (Ctrl+O)', 'إضافة علامة (P) · كل العلامات (H)': 'Add bookmark (P) · All bookmarks (H)',
    'السرعة ([ و ])': 'Speed ([ and ])', 'تكرار جزء A-B (L)': 'A-B repeat (L)', 'الأصوات (M)': 'Audio tracks (M)',
    'الترجمة (Alt+H)': 'Subtitles (Alt+H)', 'تصدير (Ctrl+E)': 'Export (Ctrl+E)', 'لقطة (S)': 'Screenshot (S)',
    'قائمة التشغيل (F6)': 'Playlist (F6)', 'الإعدادات (F5)': 'Settings (F5)', 'ملء الشاشة (Enter)': 'Fullscreen (Enter)', 'كتم الكل': 'Mute all',
    // OSD and states
    'إيقاف مؤقت': 'Pause', 'تم الإيقاف المؤقت': 'Paused', 'كتم كل الأصوات': 'Mute all sounds', 'الصوت يعمل': 'Sound on', 'إلغاء تكرار الجزء': 'A-B repeat off',
    'تم حفظ اللقطة': 'Screenshot saved', 'بدون صوت': 'No audio', 'مكتوم': 'muted', 'يعمل': 'on',
    'تعذر تشغيل صورة هذا الفيديو (صيغة غير مدعومة)': 'This video format cannot be displayed',
    'افتح مقطعاً فيه صوت أولاً': 'Open a clip with audio first', 'كل المسارات مكتومة': 'All tracks are muted',
    'لا يمكن الحفظ فوق الملف الأصلي': 'Cannot overwrite the original file', 'أُلغي التصدير': 'Export cancelled',
    'توجد علامة هنا من قبل': 'A bookmark already exists here', 'تم تحميل الترجمة وتشغيلها': 'Subtitle downloaded and loaded',
    'الترجمة متوقفة': 'Subtitles off', 'تعذرت قراءة ملف الترجمة': 'Could not read the subtitle file', 'الترجمة مخفية': 'Subtitles hidden',
    'الترجمة ظاهرة': 'Subtitles shown', 'افتح فيديو أولاً': 'Open a video first', 'تم إرجاع الاختصارات الافتراضية': 'Default shortcuts restored',
    'تم تصدير الإعدادات': 'Settings exported', 'حدّد البداية A والنهاية B أولاً': 'Set the start A and end B first',
    // mixer
    'لا توجد مسارات صوت': 'No audio tracks', 'إلغاء التثبيت': 'Unpin', 'إرجاع الكل': 'Reset all', 'تثبيت تحت الفيديو': 'Pin under the video',
    'هذا المقطع بدون صوت': 'This clip has no audio', 'افتح مقطعاً أولاً': 'Open a clip first',
    // context menu
    'تشغيل': 'Play', 'فتح ملف…': 'Open file…', 'فتح مجلد…': 'Open folder…', 'الترجمة…': 'Subtitles…',
    'البحث عن ترجمة على الإنترنت…': 'Search subtitles online…', 'إضافة علامة': 'Add bookmark', 'قائمة العلامات…': 'Bookmarks…',
    'تكرار جزء A-B': 'A-B repeat', 'لقطة': 'Screenshot', 'تصدير…': 'Export…', 'ملء الشاشة': 'Fullscreen', 'الإعدادات…': 'Settings…',
    // export
    'تصدير المقطع': 'Export clip', 'يُحفظ ملف جديد بالأصوات كما ضبطتها الآن، والفيديو الأصلي لا يتغير.': 'A new file is saved with the sound as you set it now. The original video is not changed.',
    'المدة': 'Duration', 'المقطع كاملاً': 'Whole clip', 'الجزء المحدد A-B فقط': 'Only the A-B part', 'حدّده بزر A-B أولاً': 'Set it with the A-B button first',
    'الصيغة': 'Format', 'فيديو MP4': 'MP4 video', 'الصورة بنفس الجودة': 'Same picture quality', 'صوت فقط MP3': 'Audio only MP3',
    'تصدير': 'Export', 'إلغاء': 'Cancel', 'جاري التصدير': 'Exporting', 'جاري الحفظ…': 'Saving…', 'إلغاء التصدير': 'Cancel export',
    'تم التصدير': 'Exported', 'فتح المجلد': 'Open folder', 'حسناً': 'OK', 'فشل التصدير': 'Export failed', 'لن يكون في الملف:': 'Not in the file:',
    // settings navigation and pages
    'الإعدادات': 'Settings', 'عام': 'General', 'التشغيل': 'Playback', 'الصوت': 'Audio', 'الفيديو': 'Video', 'الترجمة': 'Subtitles',
    'التصدير': 'Export', 'اللقطات': 'Screenshots', 'الاختصارات': 'Shortcuts', 'التحديثات': 'Updates', 'تغيير': 'Change', 'افتراضي': 'Default',
    'اللغة': 'Language', 'العربية': 'العربية', 'فتح ملف واحد يضع الفيديو وحده في القائمة': 'Opening one file puts only that video in the playlist',
    'عند الإيقاف: يضع كل فيديوهات مجلده': 'When off: adds every video of its folder', 'فتح مجلد يضع كل فيديوهات المجلد': 'Opening a folder adds all its videos',
    'دائماً': 'Always', 'تذكّر موضع التوقف لكل فيديو': 'Remember the position of each video', 'نافذة واحدة فقط للبرنامج': 'Single program window',
    'فتح فيديو جديد من ويندوز يذهب إلى نفس النافذة (بعد إعادة التشغيل)': 'Videos opened from Windows go to the same window (after restart)',
    'المظهر': 'Theme', 'داكن': 'Dark', 'إيقاف التشغيل عند تصغير النافذة': 'Pause when the window is minimized',
    'يكمل وحده عند الرجوع للنافذة': 'Resumes when you come back', 'إيقاف التشغيل عند الانتقال لنافذة أخرى': 'Pause when switching to another window',
    'يكمل وحده عند الرجوع للمشغل': 'Resumes when you return to the player', 'التقديم والرجوع بالأسهم': 'Arrow keys seek by',
    '5 ثوان': '5 seconds', '10 ثوان': '10 seconds', '30 ثانية': '30 seconds', 'Shift مع السهم = 30 ثانية': 'Shift + arrow = 30 seconds',
    'تشغيل المقطع التالي تلقائياً': 'Play the next clip automatically', 'صورة مصغّرة للمشهد فوق شريط التقديم': 'Scene preview over the seek bar',
    'السرعة الحالية': 'Current speed', 'غيّرها بـ [ و ] أو من زر السرعة': 'Change it with [ and ] or the speed button',
    'مستوى البداية لكل مسار': 'Starting level of each track', 'تذكّر مستوى كل مسار بين المقاطع': 'Remember each track level between clips',
    'تثبيت لوحة الأصوات تحت الفيديو': 'Pin the audio panel under the video', 'مسارات المقطع الحالي': 'Tracks in this clip',
    'البرنامج يتعرف وحده على عدد المسارات': 'The player detects the number of tracks by itself', 'موازن الصوت': 'Equalizer',
    'الإعداد الجاهز': 'Preset', 'مخصّص': 'Custom', 'بدون (مسطّح)': 'Flat', 'تقوية الخطوات (ألعاب)': 'Footsteps (games)', 'تقوية الجهير': 'Bass boost',
    'وضوح الكلام': 'Voice clarity', 'تقوية الحدّة': 'Treble boost', 'ليلي (أصوات هادئة)': 'Night (quiet)', 'تأخير الصوت عن الصورة': 'Audio delay',
    'صفر': 'Zero', 'موجب = الصوت يتأخر عن الصورة': 'Positive = audio comes later', 'نسبة العرض': 'Aspect ratio', 'الأصلية': 'Original',
    'ملء مع قص الحواف': 'Fill and crop', 'تمديد لملء الشاشة': 'Stretch to fill', 'السطوع': 'Brightness', 'التباين': 'Contrast',
    'الترتيب': 'Sort', 'الأحدث في الأعلى': 'Newest first', 'الأقدم في الأعلى': 'Oldest first', 'حسب الاسم': 'By name', 'إظهار قائمة التشغيل': 'Show the playlist',
    'تحميل الترجمة الموجودة بجانب الفيديو أو داخله تلقائياً': 'Load subtitles next to or inside the video automatically',
    'اللغة المفضلة': 'Preferred language', 'حجم الخط': 'Font size', 'لون النص': 'Text colour', 'الموضع': 'Position', 'أسفل الشاشة': 'Bottom',
    'أعلى الشاشة': 'Top', 'خلفية داكنة خلف النص': 'Dark background behind text', 'مواقع تحميل الترجمة': 'Subtitle websites',
    'البرنامج فيه مفاتيح مدمجة ويعمل بدونها. إذا أضفت مفتاحك الخاص، يُستعمل أولاً، وإذا انتهى حده ينتقل البرنامج وحده إلى المفتاح المدمج، ثم إلى الموقع الآخر.': 'The player has built-in keys and works without these fields. Your own key is used first; when its limit is reached the player switches to the built-in key, then to the other website.',
    'أدخل مفتاحاً واحداً على الأقل لتفعيل البحث.': 'Enter at least one key to enable search.', 'مفتاح OpenSubtitles': 'OpenSubtitles key',
    'المفتاح المدمج مستعمل': 'Built-in key in use', 'اسم المستخدم في OpenSubtitles (اختياري)': 'OpenSubtitles username (optional)',
    'يرفع حد التحميل اليومي': 'Raises the daily download limit', 'كلمة المرور (اختياري)': 'Password (optional)', 'مفتاح SubDL': 'SubDL key',
    'اختياري · من opensubtitles.com ← API consumers': 'Optional · opensubtitles.com → API consumers', 'اختياري · من subdl.com ← الحساب ← API': 'Optional · subdl.com → Account → API',
    'الصيغة الافتراضية': 'Default format', 'جودة الصوت': 'Audio quality', 'مجلد الحفظ': 'Save folder', 'نفس مجلد الفيديو': 'Same folder as the video',
    'مجلد اللقطات': 'Screenshots folder', 'مجلد «لقطات» بجانب الفيديو': 'A "Screenshots" folder next to the video',
    'اضغط «تغيير» ثم الزر الجديد. Esc للإلغاء. الأرقام 1 إلى 9 ثابتة لكتم المسارات.': 'Press "Change", then the new key. Esc cancels. Keys 1 to 9 always mute tracks.',
    'اضغط الزر الجديد…': 'Press the new key…', 'إرجاع الاختصارات الافتراضية': 'Restore default shortcuts', 'الإصدار': 'Version', 'رقم البناء': 'Build',
    'المطوّر': 'Developer', 'موسى سماحة · Andoria': 'Moussa Semaha · Andoria', 'تحقق من وجود تحديث': 'Check for updates',
    'التحديث ينزّل الجزء المتغيّر فقط': 'Updates download only the changed part', 'تصدير الإعدادات': 'Export settings', 'استيراد الإعدادات': 'Import settings',
    'إعادة الضبط': 'Reset', 'اضغط مرة أخرى للتأكيد': 'Click again to confirm',
    // updates
    'جاري تحميل التحديث وتثبيته…': 'Downloading and installing the update…', 'فشل التحديث': 'Update failed', 'أعد التشغيل لتطبيقه.': 'Restart to apply it.',
    'إعادة التشغيل الآن': 'Restart now', 'لاحقاً': 'Later', 'تحديث الآن': 'Update now', 'لأن محرّك البرنامج تغيّر': 'because the player engine changed',
    'تحميل المثبّت': 'Download installer', 'جاري التحقق…': 'Checking…', 'التحديث مثبّت، أعد التشغيل لتطبيقه': 'Update installed, restart to apply it',
    'إعادة التشغيل': 'Restart', 'عندك آخر إصدار ✓': 'You have the latest version ✓', 'تعذر الاتصال بخادم التحديثات': 'Could not reach the update server',
    'لا يوجد اتصال بالإنترنت': 'No internet connection', 'فشل تحميل التحديث': 'Update download failed', 'ملف التحديث تالف، أعد المحاولة': 'The update file is damaged, try again',
    'ملف التحديث ناقص': 'The update file is incomplete',
    // subtitles
    'مدمجة': 'embedded', 'مدمجة (صورة، غير مدعومة)': 'embedded (image, not supported)', 'ملف خارجي': 'external file',
    'لا توجد ترجمة لهذا المقطع': 'No subtitles for this clip', 'إيقاف الترجمة': 'Subtitles off', 'تأخير الترجمة': 'Subtitle delay',
    '+ إضافة ملف ترجمة…': '+ Add subtitle file…', '🔎 البحث عن ترجمة على الإنترنت…': '🔎 Search subtitles online…', 'البحث عن ترجمة على الإنترنت': 'Search subtitles online',
    'اسم الفيلم أو المسلسل أو الأنمي': 'Movie, series or anime name', 'الموسم': 'Season', 'الحلقة': 'Episode', 'جاري البحث…': 'Searching…',
    'فتح الإعدادات ← الترجمة': 'Open Settings → Subtitles', 'لا توجد نتائج. جرّب اسماً آخر أو لغة أخرى.': 'No results. Try another name or language.',
    'جاري التحميل…': 'Downloading…', 'فشل تحميل الترجمة': 'Subtitle download failed',
    'لا يوجد مفتاح لمواقع الترجمة. أدخل مفتاحاً في الإعدادات ← الترجمة': 'No subtitle website key. Enter one in Settings → Subtitles',
    'تعذر الاتصال بمواقع الترجمة أو انتهى حد التحميل اليومي. حاول لاحقاً.': 'Could not reach the subtitle websites, or the daily limit is reached. Try later.',
    'انتهى حد التحميل اليومي لكل المفاتيح. جرّب SubDL أو حاول غداً.': 'The daily limit is reached for every key. Try SubDL or try tomorrow.',
    'إضافة ملف ترجمة': 'Add subtitle file',
    // bookmarks
    'العلامات في هذا المقطع': 'Bookmarks in this clip', 'حذف': 'Delete', 'لا توجد علامات. اضغط P أثناء التشغيل لإضافة علامة.': 'No bookmarks. Press P while playing to add one.',
    'إضافة علامة الآن': 'Add bookmark now', 'حذف الكل': 'Delete all',
    // shortcut action names
    'تشغيل / إيقاف مؤقت': 'Play / Pause', 'تقديم': 'Forward', 'رجوع': 'Back', 'تقديم 30 ثانية': 'Forward 30 seconds', 'رجوع 30 ثانية': 'Back 30 seconds',
    'رفع الصوت العام': 'Volume up', 'خفض الصوت العام': 'Volume down', 'لوحة الأصوات': 'Audio panel', 'إغلاق الفيديو': 'Close video',
    'الإطار التالي': 'Next frame', 'الإطار السابق': 'Previous frame', 'أسرع': 'Faster', 'أبطأ': 'Slower', 'السرعة العادية': 'Normal speed',
    'قائمة العلامات': 'Bookmarks list', 'إظهار / إخفاء الترجمة': 'Show / hide subtitles', 'قائمة الترجمة': 'Subtitles menu', 'تقديم الترجمة': 'Subtitles sooner',
    'تأخير الصوت': 'Audio later', 'تقديم الصوت': 'Audio sooner', 'المقطع التالي': 'Next clip', 'المقطع السابق': 'Previous clip',

    // playback modes, video/audio tools, mouse, info (batch 3)
    'صور متتالية': 'Burst screenshots', 'الذهاب إلى وقت…': 'Go to time…', 'الذهاب إلى وقت': 'Go to time', 'الفيديو ◂': 'Video ◂', 'الصوت ◂': 'Audio ◂', 'التكرار ◂': 'Repeat ◂',
    'معلومات الملف…': 'File info…', 'معلومات الملف': 'File info', 'دائماً في المقدمة': 'Always on top', 'إلغاء دائماً في المقدمة': 'Always on top off',
    'التكرار (R)': 'Repeat (R)', 'تشغيل عشوائي (Shift+R)': 'Shuffle (Shift+R)', 'دائماً في المقدمة (Ctrl+T)': 'Always on top (Ctrl+T)',
    'تكرار المقطع (R)': 'Repeat this clip (R)', 'تكرار كل القائمة (R)': 'Repeat the whole playlist (R)', 'بدون تكرار (R)': 'No repeat (R)',
    'تكرار المقطع': 'Repeat this clip', 'تكرار كل القائمة': 'Repeat the whole playlist', 'بدون تكرار': 'No repeat', 'تشغيل عشوائي': 'Shuffle', 'تشغيل بالترتيب': 'Play in order',
    'اضغط للتبديل بين المدة والوقت المتبقي': 'Click to switch between duration and remaining time', 'حفظ قائمة التشغيل': 'Save playlist', 'فتح قائمة تشغيل (m3u)': 'Open playlist (m3u)',
    'تم حفظ قائمة التشغيل': 'Playlist saved', 'المزيد': 'More', 'الشاشة': 'Screen', 'صوت فقط M4A': 'Audio only M4A', 'تحميل التحديث': 'Downloading update', 'عند فتح البرنامج بعد إغلاق عادي': 'When the program opens after a normal close', 'يفتح فارغاً': 'Start empty', 'استعادة آخر جلسة': 'Restore the last session', 'بعد التحديث أو توقف البرنامج المفاجئ تُستعاد الجلسة دائماً: القائمة والفيديو واللحظة': 'After an update or a crash the session is always restored: playlist, video and position', 'تمت استعادة الجلسة بعد توقف البرنامج': 'Session restored after the program stopped unexpectedly', 'تضمين المجلدات الفرعية عند فتح مجلد': 'Include subfolders when opening a folder', 'مفيد إذا كان SteelSeries يحفظ كل لعبة في مجلد خاص': 'Useful when SteelSeries saves each game in its own folder', 'الترتيب': 'Sort', 'تكبير القائمة / إرجاعها': 'Widen / restore the playlist', 'اسحب لتغيير عرض القائمة · نقرتان للحجم الأصلي': 'Drag to resize the playlist · double-click to reset', 'الأحدث أولاً': 'Newest first', 'الأقدم أولاً': 'Oldest first', 'حفظ قائمة التشغيل…': 'Save playlist…', 'فتح قائمة تشغيل (m3u)…': 'Open playlist (m3u)…', 'تدوير 90°': 'Rotate 90°', 'قلب أفقي': 'Flip horizontally', 'قلب عمودي': 'Flip vertically', 'تكبير الصورة': 'Zoom in', 'تصغير الصورة': 'Zoom out',
    'نسبة أصلية': 'Original ratio', 'إرجاع الصورة للأصل': 'Reset picture', 'توحيد مستوى الصوت': 'Volume normalizer', 'ستيريو عادي': 'Normal stereo',
    'تبديل اليسار واليمين': 'Swap left and right', 'دمج في قناة واحدة (مونو)': 'Downmix to mono', 'توحيد مستوى الصوت: يعمل': 'Volume normalizer: on', 'توحيد مستوى الصوت: متوقف': 'Volume normalizer: off',
    'إطفاء الحاسوب': 'Shut down the computer', 'انتهت قائمة التشغيل. سيُطفأ الحاسوب بعد': 'The playlist has ended. The computer shuts down in', 'إطفاء الآن': 'Shut down now',
    'إلغاء الإطفاء': 'Cancel shutdown', 'أُلغي إطفاء الحاسوب': 'Shutdown cancelled', 'انتقال': 'Go', 'مثال:': 'Example:', 'أو': 'or', '· المدة': '· duration',
    'الملف': 'File', 'الحجم': 'Size', 'الحاوية': 'Container', 'معدل البت': 'Bitrate', 'قلب الصورة أفقياً': 'Flip picture horizontally', 'قلب الصورة عمودياً': 'Flip picture vertically',
    'حجم الصورة الأصلي': 'Original picture size', 'تدوير الصورة 90°': 'Rotate picture 90°', 'المدة / الوقت المتبقي': 'Duration / remaining time',
    'التكرار (بدون / المقطع / الكل)': 'Repeat (off / clip / all)', 'التكرار': 'Repeat', 'بعد انتهاء قائمة التشغيل': 'When the playlist ends', 'لا شيء': 'Do nothing',
    'إغلاق البرنامج': 'Close the program', 'إطفاء الحاسوب (مع عدّ تنازلي)': 'Shut down the computer (with countdown)', 'فتح آخر فيديو عند تشغيل البرنامج': 'Open the last video when the program starts',
    'الحفاظ على طبقة الصوت عند تغيير السرعة': 'Keep audio pitch when changing speed', 'عند الإيقاف: الصوت يصبح أحدّ أو أغلظ مع السرعة': 'When off: the sound gets higher or deeper with speed',
    'خطوة الصوت العام': 'Volume step', 'الحد الأقصى للصوت العام': 'Maximum volume', 'بدء التشغيل بملء الشاشة': 'Start playback in fullscreen', 'التدوير': 'Rotation',
    'قلب أفقي (مرآة)': 'Flip horizontally (mirror)', 'التكبير': 'Zoom', 'التشبّع': 'Saturation', 'اللون': 'Hue', 'لون الخلفية حول الفيديو': 'Background colour around the video',
    'يرفع الأصوات المنخفضة ويخفض العالية (مثل الانفجارات)': 'Raises quiet sounds and lowers loud ones (like explosions)', 'القنوات': 'Channels', 'الفأرة والشاشة': 'Mouse and screen',
    'عجلة الفأرة فوق الفيديو': 'Mouse wheel over the video', 'التقديم والرجوع': 'Seek', 'النقر المزدوج على الفيديو': 'Double-click on the video', 'الزر الأوسط للفأرة': 'Middle mouse button',
    'رسائل على الشاشة (الصوت، السرعة…)': 'On-screen messages (volume, speed…)', 'الضغط على المدة يُظهر الوقت المتبقي': 'Show remaining time instead of duration',
    'عدد الصور المتتالية': 'Burst screenshot count', 'المدة بين كل صورة': 'Time between shots', 'التشغيل مع بداية ويندوز': 'Start with Windows',
    'التحقق من التحديثات عند فتح البرنامج': 'Check for updates when the program opens', 'أبداً': 'Never', 'دائماً ': 'Always', 'أثناء التشغيل فقط': 'Only while playing',
    'إيقاف التشغيل عند قفل الشاشة': 'Pause when the screen is locked', 'يكمل وحده عند فتح القفل': 'Resumes when you unlock', 'نوع الخط': 'Font', 'خط عريض': 'Bold',
    'سماكة الحدّ حول الحروف': 'Outline thickness', 'بدون': 'None', 'رفيع': 'Thin', 'متوسط': 'Medium', 'سميك': 'Thick', 'البعد عن حافة الشاشة': 'Distance from the screen edge',
    'إرجاع الصورة للأصل ': 'Reset picture', 'قلب أفقي ': 'Flip horizontal',
    'الخروج من ملء الشاشة': 'Exit fullscreen', 'قائمة الترجمة ': 'Subtitles menu',
  };
  const RX = [
    [/^الترتيب: (.+)$/, (m, t) => `Sort: ${tr(t)}`],
    [/^فشل تحميل التحديث \((.+)\)$/, (m, w) => `Update download failed (${w})`],
    [/^تحميل التحديث (.+)$/, (m, v) => `Downloading update ${v}`],
    [/^موازن: (.+)$/, (m, t) => `EQ: ${t}`],
    [/^مسار الصوت (\d+)$/, (m, n) => `Audio track ${n}`],
    [/^الترجمة (\d+)$/, (m, n) => `Subtitle ${n}`],
    [/^تدوير (.+)$/, (m, v) => `Rotate ${v}`],
    [/^التكبير (.+)$/, (m, v) => `Zoom ${v}`],
    [/^صور متتالية: (.+)$/, (m, v) => `Burst: ${v}`],
    [/^تم حفظ (.+) لقطات$/, (m, v) => `${v} screenshots saved`],
    [/^(\d+) (?:مسار صوت|مسارا صوت|مسارات صوت)$/, (m, n) => `${n} audio track${n === '1' ? '' : 's'}`],
    [/^الأصوات: (\S+) (?:مسار|مسارات)$/, (m, n) => `Audio: ${n} track${/\b1\b/.test(n) ? '' : 's'}`],
    [/^المسار (\S+): (مكتوم|يعمل)$/, (m, n, st) => `Track ${n}: ${st === 'مكتوم' ? 'muted' : 'on'}`],
    [/^مستوى المسار (\d+)$/, (m, n) => `Track ${n} level`],
    [/^كتم المسار (\d+) \((\d+)\)$/, (m, n, k) => `Mute track ${n} (${k})`],
    [/^المسار (\d+)$/, (m, n) => `Track ${n}`],
    [/^(تقديم|رجوع) (\d+) ث$/, (m, w, n) => `${w === 'تقديم' ? 'Forward' : 'Back'} ${n} s`],
    [/^متابعة من (.+)$/, (m, t) => `Resuming from ${t}`],
    [/^السرعة:? (.+)$/, (m, v) => `Speed ${v}`],
    [/^الصوت (.+)$/, (m, v) => `Volume ${v}`],
    [/^بداية الجزء A: (.+)$/, (m, t) => `A-B start: ${t}`],
    [/^تكرار من (.+) إلى (.+)$/, (m, a, b) => `Repeat from ${a} to ${b}`],
    [/^من (.+) إلى (.+)$/, (m, a, b) => `from ${a} to ${b}`],
    [/^تمت إضافة علامة عند (.+)$/, (m, t) => `Bookmark added at ${t}`],
    [/^علامة (.+)$/, (m, t) => `Bookmark ${t}`],
    [/^أُضيفت (.+)$/, (m, t) => `added ${t}`],
    [/^الترجمة: (.+)$/, (m, t) => `Subtitles: ${t}`],
    [/^ترجمة (\d+)$/, (m, n) => `Subtitle ${n}`],
    [/^تأخير الترجمة (.+)$/, (m, v) => `Subtitle delay ${v}`],
    [/^تأخير الصوت (.+)$/, (m, v) => `Audio delay ${v}`],
    [/^(.+) ث$/, (m, v) => `${v} s`],
    [/^(.+) تحميل$/, (m, v) => `${v} downloads`],
    [/^لن يكون في الملف: (.+)$/, (m, v) => `Not in the file: ${v.replace(/المسار/g, 'track').replace(/،/g, ',')}`],
    [/^يوجد تحديث جديد b(.+) · حجمه (.+) فقط$/, (m, b, s) => `New update b${b} · only ${s}`],
    [/^يوجد إصدار كامل جديد b(.+) \((.+)\) لأن محرّك البرنامج تغيّر$/, (m, b, s) => `New full version b${b} (${s}) because the player engine changed`],
    [/^تم تثبيت التحديث b(.+)\. أعد التشغيل لتطبيقه\.$/, (m, b) => `Update b${b} installed. Restart to apply it.`],
    [/^جاري الحفظ… (.+) من (.+)$/, (m, a, b) => `Saving… ${a} of ${b}`],
    [/^لم توجد نتائج في (\S+)، هذه نتائج (\S+)$/, (m, a, b) => `No results on ${a}, these are from ${b}`],
    [/^تم حفظ اللقطة: (.+)$/, (m, p) => `Screenshot saved: ${p}`],
    [/^تعذر فصل مسارات الصوت: (.*)$/s, (m, e) => `Could not split the audio tracks: ${e}`],
    [/^فشل تحميل الترجمة: (.*)$/s, (m, e) => `Subtitle download failed: ${e}`],
    [/^فشل تثبيت التحديث: (.*)$/s, (m, e) => `Update install failed: ${e}`],
  ];
  const strip = (s) => s.replace(/[\u202A-\u202E\u200E\u200F\u2066-\u2069]/g, '');
  function tr(src) {
    if (!src || !/[؀-ۿ]/.test(src)) return src;
    const lead = src.match(/^\s*/)[0], tail = src.match(/\s*$/)[0];
    const t = src.trim(), bare = strip(t);
    if (D[t] !== undefined) return lead + D[t] + tail;
    if (D[bare] !== undefined) return lead + D[bare] + tail;
    for (const [re, fn] of RX) { const m = bare.match(re); if (m) return lead + tr(fn(...m)) + tail; }
    // phrase-by-phrase fallback (longest first)
    let out = t;
    for (const k of KEYS) if (out.includes(k)) out = out.split(k).join(D[k]);
    return lead + out + tail;
  }
  const KEYS = Object.keys(D).filter((k) => k.length > 1).sort((a, b) => b.length - a.length);
  window.TR = tr;

  // never translate subtitle text, file names or paths
  const KEEP = '#subs, #subsTop, #tbFile, .nm, [data-notr]';
  function walk(node) {
    const el = node.nodeType === 3 ? node.parentElement : node;
    if (el && el.closest && el.closest(KEEP)) return;
    if (node.nodeType === 3) { const v = node.nodeValue, n = tr(v); if (n !== v) node.nodeValue = n; return; }
    if (node.nodeType !== 1) return;
    for (const a of ['title', 'placeholder']) if (node.hasAttribute && node.hasAttribute(a)) { const v = node.getAttribute(a), n = tr(v); if (n !== v) node.setAttribute(a, n); }
    if (node.tagName === 'OPTION' || node.tagName === 'SCRIPT' || node.tagName === 'STYLE') { if (node.tagName === 'OPTION') { const v = node.textContent, n = tr(v); if (n !== v) node.textContent = n; } return; }
    for (const c of node.childNodes) walk(c);
  }
  function start() {
    walk(document.body);
    new MutationObserver((list) => {
      for (const m of list) {
        if (m.type === 'characterData') walk(m.target);
        else if (m.type === 'attributes') walk(m.target);
        else m.addedNodes.forEach(walk);
      }
    }).observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['title', 'placeholder'] });
    const tt = document.querySelector('title');
    new MutationObserver(() => { const n = tr(document.title); if (n !== document.title) document.title = n; }).observe(tt, { childList: true, characterData: true, subtree: true });
    document.title = tr(document.title);
  }
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
