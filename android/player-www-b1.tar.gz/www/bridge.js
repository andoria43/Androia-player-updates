'use strict';
// Android only: builds window.ap (the same functions the Windows program gets from preload.js) on top of
// the app's Native.call(id, method, argsJson). On Windows window.Native does not exist and this file does nothing.
(function () {
  if (!window.Native || window.ap) return;
  window.AP_PLATFORM = 'android';
  document.documentElement.classList.add('android');
  const pending = {}, listeners = {};
  let seq = 0;
  window.__apDone = (id, v) => { const p = pending[id]; if (p) { delete pending[id]; p(v); } };
  window.__apEmit = (ev, v) => { (listeners[ev] || []).forEach((f) => { try { f(v); } catch (e) {} }); };
  const call = (m) => (...args) => new Promise((resolve) => {
    const id = 'c' + (++seq);
    pending[id] = resolve;
    Native.call(id, m, JSON.stringify(args.map((x) => (x === undefined ? null : x))));
  });
  const on = (ev) => (fn) => { (listeners[ev] = listeners[ev] || []).push(fn); };
  const ap = {};
  ['startupFile', 'settingsGet', 'settingsSet', 'pickFile', 'pickFolder', 'listFolder', 'isDir', 'fileInfo', 'win', 'prepare',
    'exportSavePath', 'exportRun', 'exportCancel', 'showInFolder', 'saveShot', 'toggleFullscreen', 'exitFullscreen', 'appReady',
    'updateCheck', 'updateInstall', 'updateRestart', 'openUrl', 'readSub', 'pickSub', 'remux', 'subGuess', 'embKeys', 'subSearch',
    'subDownload', 'settingsExport', 'settingsImport', 'settingsReset', 'reload', 'setLang', 'onTop', 'quit', 'autoStart',
    'shutdownPc', 'fileSize', 'm3uSave', 'm3uOpen'].forEach((m) => { ap[m] = call(m); });
  Object.assign(ap, {
    onExportProgress: on('export-progress'), onWinState: on('win-state'), onFullState: on('full-state'),
    onOpenPath: on('open-path'), onWinEvent: on('win-event'), onApkProgress: on('apk-progress'),
    fileUrl: (p) => 'https://appassets.androidplatform.net/media/' + encodeURIComponent(p),
    pathForFile: () => null,
    dirname: (p) => String(p || '').replace(/[\\/][^\\/]*$/, ''),
    basename: (p) => { let s = String(p || ''); try { s = decodeURIComponent(s); } catch (e) {} return s.replace(/^.*[\\/:]/, ''); },
  });
  window.ap = ap;
})();
