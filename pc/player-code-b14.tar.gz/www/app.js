'use strict';
const $ = (id) => document.getElementById(id);
const LRE = '\u2066', PDF = '\u2069'; // left-to-right isolate: numbers, times and degrees keep their order
const ltr = (s) => LRE + s + PDF;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const video = $('video');
if (window.AP_MEDIA_CROSS) video.crossOrigin = 'anonymous'; // Android: media from the local server, Web Audio and screenshots need CORS
const RTL = () => document.documentElement.dir !== 'ltr';
const EN = window.UI_LANG === 'en';
const ANDROID = window.AP_PLATFORM === 'android';
if (ANDROID) document.body.classList.add('android');
const SIDE = () => (RTL() ? 'right' : 'left');
video.muted = true; // the sound comes from the separated tracks (Web Audio)
// no grey picture with a play symbol (the phone's default) before the first frame: an empty poster, and the
// video stays invisible until its first picture is ready
const NO_POSTER = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
video.poster = NO_POSTER;
video.addEventListener('loadeddata', () => video.classList.remove('loading'));
video.addEventListener('playing', () => video.classList.remove('loading'));

const DEF = {
  singleFile: true, rememberPos: true, singleInstance: true, seekStep: 5, autoNext: true,
  defVol: 100, rememberVols: true, aspect: 'contain', bright: 100, contrast: 100,
  sort: 'new', showList: true, listW: 260, subfolders: false, onOpen: 'fresh', mixPinned: false, expFormat: 'mp4', bitrate: '192k', expFolder: '',
  shotFolder: '', shotExt: 'png', master: 100, lastDir: '',
  pauseMin: false, pauseBlur: false, subAuto: true, subLang: 'ar', subSize: 28, subColor: '#ffffff', subPos: 'bottom', subBg: false,
  repeat: 'off', shuffle: false, onTop: false, showRemain: false, rotate: 0, flipH: false, flipV: false, zoom: 100, hue: 0, saturate: 100,
  normalize: false, channels: 'stereo', keepPitch: true, afterList: 'none', resumeLast: false, lastFile: '', wheel: 'volume', dbl: 'full', middle: 'mute',
  osdOn: true, volStep: 5, burstN: 5, burstGap: 1, topMode: 'never', pauseLock: true, autoStart: false, autoUpd: true, startFull: false,
  subFont: 'Segoe UI', subBold: true, subOutline: 2, subMargin: 7, bgColor: '#000000', maxVol: 150,
  osKey: '', osUser: '', osPass: '', subdlKey: '', eqPreset: 'flat', eq: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], audioDelay: 0, thumbs: true,
};
const S = {
  set: {}, list: [], cur: -1, tracks: [], info: null, ab: [null, null], loop: false,
  ctx: null, master: null, loadId: 0, allMuted: false, appInfo: { version: '', build: 0 },
};
const cfg = (k) => (S.set[k] !== undefined ? S.set[k] : DEF[k]);
function save(patch) { Object.assign(S.set, patch); ap.settingsSet(patch); }

const fmt = (sec) => {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60, p = (n) => String(n).padStart(2, '0');
  return h ? `${h}:${p(m)}:${p(s)}` : `${p(m)}:${p(s)}`;
};
const stamp = (ms) => {
  const d = new Date(ms), p = (n) => String(n).padStart(2, '0');
  if (EN) return ltr(`${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}  ${p(d.getHours())}:${p(d.getMinutes())}`);
  return ltr(`${p(d.getHours())}:${p(d.getMinutes())}  ${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())}`);
};
let osdT = null;
function osd(t, ms) { if (S.set && S.set.osdOn === false && !ms) return; const o = $('osd'); o.textContent = t; o.classList.remove('hidden'); clearTimeout(osdT); osdT = setTimeout(() => o.classList.add('hidden'), ms || 1400); }

// ================= audio engine =================
function ensureCtx() {
  if (!S.ctx) {
    S.ctx = new AudioContext();
    S.master = S.ctx.createGain();
    S.master.channelCount = 2; S.master.channelCountMode = 'explicit'; S.master.channelInterpretation = 'speakers';
    S.split = S.ctx.createChannelSplitter(2); S.merge = S.ctx.createChannelMerger(2);
    S.comp = S.ctx.createDynamicsCompressor(); S.makeup = S.ctx.createGain();
    S.comp.threshold.value = -28; S.comp.knee.value = 24; S.comp.ratio.value = 5; S.comp.attack.value = 0.004; S.comp.release.value = 0.25; S.makeup.gain.value = 1.6;
    S.comp.connect(S.makeup);
    S.master.connect(S.split);
    S.eqNodes = EQ_FREQ.map((f) => { const b = S.ctx.createBiquadFilter(); b.type = 'peaking'; b.frequency.value = f; b.Q.value = 1.1; return b; });
    wireChannels(); wireComp();
    for (let i = 0; i < S.eqNodes.length - 1; i++) S.eqNodes[i].connect(S.eqNodes[i + 1]);
    S.eqNodes[S.eqNodes.length - 1].connect(S.ctx.destination);
    applyEq();
    applyMaster();
  }
  if (S.ctx.state === 'suspended') S.ctx.resume();
}
const EQ_FREQ = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
const EQ_PRESETS = {
  flat: ['بدون (مسطّح)', [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]],
  steps: ['تقوية الخطوات (ألعاب)', [-4, -3, -2, -1, 0, 2, 5, 6, 4, 2]],
  bass: ['تقوية الجهير', [6, 5, 4, 2, 0, 0, 0, 0, 0, 0]],
  voice: ['وضوح الكلام', [-2, -2, -1, 1, 3, 4, 4, 2, 0, -1]],
  treble: ['تقوية الحدّة', [0, 0, 0, 0, 0, 1, 2, 4, 5, 6]],
  night: ['ليلي (أصوات هادئة)', [-5, -4, -2, 0, 1, 2, 2, 1, -1, -3]],
};
function wireChannels() {
  if (!S.split) return;
  try { S.split.disconnect(); } catch {}
  (S.monoG || []).forEach((g) => { try { g.disconnect(); } catch {} });
  const m = cfg('channels');
  if (m === 'swap') { S.split.connect(S.merge, 0, 1); S.split.connect(S.merge, 1, 0); }
  else if (m === 'mono') {
    S.monoG = [0, 1].map((i) => { const g = S.ctx.createGain(); g.gain.value = 0.5; S.split.connect(g, i); g.connect(S.merge, 0, 0); g.connect(S.merge, 0, 1); return g; });
  } else { S.split.connect(S.merge, 0, 0); S.split.connect(S.merge, 1, 1); }
}
function wireComp() {
  if (!S.merge) return;
  try { S.merge.disconnect(); } catch {} try { S.makeup.disconnect(); } catch {}
  if (cfg('normalize')) { S.merge.connect(S.comp); S.makeup.connect(S.eqNodes[0]); } else S.merge.connect(S.eqNodes[0]);
}
function applyEq() { if (!S.eqNodes) return; const v = cfg('eq'); S.eqNodes.forEach((b, i) => b.gain.setTargetAtTime(v[i] || 0, S.ctx.currentTime, 0.02)); }
function applyMaster() {
  if (!S.master) return;
  S.master.gain.setTargetAtTime(S.allMuted ? 0 : cfg('master') / 100, S.ctx.currentTime, 0.015);
}
function disposeTracks() {
  for (const t of S.tracks) { try { t.el.pause(); t.el.removeAttribute('src'); t.el.load(); t.node.disconnect(); t.gain.disconnect(); } catch {} }
  S.tracks = [];
}
const tGain = (t) => (t.muted ? 0 : t.vol / 100);
function applyTrack(t) {
  if (t.gain) t.gain.gain.setTargetAtTime(tGain(t), S.ctx.currentTime, 0.015);
  renderMixer();
}
function syncAll(force) {
  const vt = Math.max(0, video.currentTime - (cfg('audioDelay') || 0) / 1000);
  for (const t of S.tracks) {
    const el = t.el;
    if (isFinite(el.duration) && vt > el.duration) { if (!el.paused) el.pause(); continue; }
    const diff = vt - el.currentTime;
    if (force || Math.abs(diff) > 0.15) { try { el.currentTime = vt; } catch {} el.playbackRate = video.playbackRate; }
    else el.playbackRate = video.playbackRate * (1 + Math.max(-0.05, Math.min(0.05, diff * 0.5)));
    if (video.paused || video.seeking) { if (!el.paused) el.pause(); } else if (el.paused) el.play().catch(() => {});
  }
}
setInterval(() => { if (!video.paused) syncAll(false); }, 250);
video.addEventListener('play', () => { ensureCtx(); syncAll(true); playIcon(); });
video.addEventListener('playing', () => syncAll(true));
video.addEventListener('pause', () => { syncAll(false); playIcon(); });
video.addEventListener('waiting', () => S.tracks.forEach((t) => t.el.pause()));
video.addEventListener('seeked', () => syncAll(true));
video.addEventListener('ratechange', () => syncAll(true));
video.addEventListener('loadedmetadata', () => {
  paintDur();
  const it = S.list[S.cur];
  if (S.pendingSeek != null) { const t = S.pendingSeek; S.pendingSeek = null; if (t > 0 && t < video.duration - 0.5) video.currentTime = t; return; }
  const pos = cfg('rememberPos') && it ? (S.set.positions || {})[it.path] : 0;
  if (pos && pos < video.duration - 3) { video.currentTime = pos; osd('متابعة من ' + ltr(fmt(pos))); }
});
video.addEventListener('ended', () => {
  S.tracks.forEach((t) => t.el.pause()); playIcon(); savePos(true);
  const rp = cfg('repeat');
  if (rp === 'one') { video.currentTime = 0; video.play().catch(() => {}); return; }
  if (window.onClipEnded && window.onClipEnded()) return; // phone: back to the list / stop (its own setting)
  const n = nextIndex(rp === 'all' || cfg('autoNext'));
  if (n != null) { playIndex(n); return; }
  afterList();
});
function nextIndex(cont) {
  if (!S.list.length) return null;
  if (cfg('shuffle')) {
    if (S.list.length === 1) return cfg('repeat') === 'all' ? 0 : null;
    S.played = S.played || new Set(); S.played.add(S.cur);
    let left = S.list.map((_, i) => i).filter((i) => !S.played.has(i));
    if (!left.length) { if (cfg('repeat') !== 'all') return null; S.played = new Set([S.cur]); left = S.list.map((_, i) => i).filter((i) => i !== S.cur); }
    return left[Math.floor(Math.random() * left.length)];
  }
  if (S.cur < S.list.length - 1) return cont ? S.cur + 1 : null;
  return cfg('repeat') === 'all' ? 0 : null;
}
function afterList() {
  const a = cfg('afterList');
  if (a === 'quit') { savePos(false); ap.quit(); }
  else if (a === 'shutdown') {
    let n = 30;
    sheet(`${head('إطفاء الحاسوب')}<div class="sh-body"><div class="dim" style="text-align:center">انتهت قائمة التشغيل. سيُطفأ الحاسوب بعد</div><div class="countdown" dir="ltr" id="cd">${n}</div></div>
      <div class="sh-foot"><button class="pbtn danger" id="cdNow">إطفاء الآن</button><button class="pbtn accent" data-close id="cdNo">إلغاء الإطفاء</button></div>`);
    const t = setInterval(() => { n--; if ($('cd')) $('cd').textContent = n; if (n <= 0) { clearInterval(t); ap.shutdownPc(); } }, 1000);
    $('cdNo').addEventListener('click', () => { clearInterval(t); osd('أُلغي إطفاء الحاسوب'); });
    $('cdNow').addEventListener('click', () => { clearInterval(t); ap.shutdownPc(); });
    $('modal').addEventListener('click', function f(e) { if (e.target.closest('[data-close]')) { clearInterval(t); $('modal').removeEventListener('click', f); } });
  }
}
video.addEventListener('error', async () => {
  if (!video.getAttribute('src')) return;
  const it = S.list[S.cur];
  if (it && !S.remuxed) {
    S.remuxed = true; $('busy').classList.remove('hidden');
    const id = S.loadId, out = await ap.remux(it.path);
    $('busy').classList.add('hidden');
    if (id !== S.loadId) return;
    if (out) { video.src = ap.fileUrl(out); video.play().catch(() => {}); return; }
  }
  const er = video.error;
  osd('تعذر تشغيل صورة هذا الفيديو (صيغة غير مدعومة)' + (er ? ` · ${ltr('E' + er.code + (er.message ? ' ' + er.message.slice(0, 60) : ''))}` : ''), 8000);
});

// remember the playlist, the clip and the moment, so a restart (or an update) brings everything back
function saveSession(extra) {
  const it = S.list[S.cur];
  save({ session: Object.assign({ paths: S.list.map((x) => x.path), cur: it ? it.path : null, t: video.duration ? Math.round(video.currentTime * 10) / 10 : 0, at: Date.now(), lib: ANDROID && document.body.classList.contains('m-lib') }, extra || {}) });
}
function savePos(ended) {
  const it = S.list[S.cur];
  if (!cfg('rememberPos') || !it || !video.duration) return;
  const p = Object.assign({}, S.set.positions || {});
  if (ended || video.currentTime < 3 || video.currentTime > video.duration - 3) delete p[it.path]; else p[it.path] = Math.round(video.currentTime);
  const keys = Object.keys(p); if (keys.length > 300) delete p[keys[0]];
  save({ positions: p });
}
setInterval(() => { if (!video.paused) { savePos(false); saveSession(); } }, 5000);
video.addEventListener('pause', () => { if (S.cur >= 0) saveSession(); });

// ================= seek bar (right-to-left) =================
let dragging = false;
function frac(e) { const r = $('seek').getBoundingClientRect(); return Math.max(0, Math.min(1, (RTL() ? r.right - e.clientX : e.clientX - r.left) / r.width)); }
$('seek').addEventListener('mousedown', (e) => { if (!video.duration) return; dragging = true; seekTo(frac(e)); });
window.addEventListener('mousemove', (e) => {
  if (dragging) seekTo(frac(e));
  const sk = $('seek').getBoundingClientRect();
  if (video.duration && e.clientY >= sk.top - 4 && e.clientY <= sk.bottom + 4 && e.clientX >= sk.left && e.clientX <= sk.right) {
    const f = frac(e), tip = $('seekTip');
    $('tipTime').textContent = fmt(f * video.duration);
    const half = 92 / sk.width * 100, pos = Math.max(half, Math.min(100 - half, f * 100));
    tip.style.right = ''; tip.style.left = ''; tip.style[SIDE()] = pos + '%'; tip.classList.toggle('nothumb', !cfg('thumbs')); tip.classList.remove('hidden');
    if (cfg('thumbs')) wantThumb(f * video.duration);
  } else $('seekTip').classList.add('hidden');
});
window.addEventListener('mouseup', () => { dragging = false; });
function paintDur() { const d = video.duration || 0; $('tDur').textContent = cfg('showRemain') && d ? '-' + fmt(d - video.currentTime) : fmt(d); }
$('tDur').addEventListener('click', () => { save({ showRemain: !cfg('showRemain') }); paintDur(); });
function seekTo(f) { video.currentTime = f * video.duration; paintSeek(); }
function paintSeek() {
  const d = video.duration || 0, f = d ? video.currentTime / d : 0;
  $('seekFill').style.width = (f * 100) + '%';
  $('seekKnob').style[SIDE()] = (f * 100) + '%';
  $('tPos').textContent = fmt(video.currentTime);
  if (cfg('showRemain')) paintDur();
  const ab = $('seekAB');
  paintMarks(d);
  if (d && S.ab[0] != null && S.ab[1] != null) { ab.style.display = 'block'; ab.style[SIDE()] = (S.ab[0] / d * 100) + '%'; ab.style.width = ((S.ab[1] - S.ab[0]) / d * 100) + '%'; } else ab.style.display = 'none';
}
(function tick() {
  if (video.duration) {
    paintSeek();
    if (S.loop && S.ab[0] != null && S.ab[1] != null && video.currentTime >= S.ab[1]) video.currentTime = S.ab[0];
    renderSubsAt(video.currentTime);
  }
  requestAnimationFrame(tick);
})();

// ================= playlist =================
function sortList(arr) {
  const s = cfg('sort');
  if (s === 'old') arr.sort((a, b) => a.mtime - b.mtime);
  else if (s === 'name') arr.sort((a, b) => a.name.localeCompare(b.name, 'ar', { numeric: true }));
  else arr.sort((a, b) => b.mtime - a.mtime); // newest on top
  return arr;
}
function renderList(keepScroll = true) {
  const sig = S.list.map((x) => x.path).join('|') + '#' + S.cur;
  if (sig !== S.lastSig) { S.lastSig = sig; if (S.ready) saveSession(); }
  const box = $('plItems'), top = box.scrollTop, q = $('plSearch').value.trim().toLowerCase();
  box.innerHTML = '';
  $('plCount').textContent = S.list.length ? `(${S.list.length})` : '';
  if (!S.list.length) { box.innerHTML = '<div class="pl-empty">القائمة فارغة<br>افتح ملفاً أو مجلداً</div>'; return; }
  S.list.forEach((c, i) => {
    if (q && !c.name.toLowerCase().includes(q)) return;
    const el = document.createElement('div');
    el.className = 'pl-it' + (i === S.cur ? ' on' : '');
    el.innerHTML = `<span class="no" dir="ltr">${i + 1}</span><div class="tx"><div class="nm"></div><div class="dt">${stamp(c.mtime)}${c.sub ? ` · <span data-notr>${esc(c.sub)}</span>` : ''}</div></div>`;
    el.querySelector('.nm').textContent = c.name;
    el.title = c.path;
    el.addEventListener('dblclick', () => playIndex(i));
    el.addEventListener('click', () => { playIndex(i); if (ANDROID && window.innerWidth < 760 && cfg('showList')) toggleList(); });
    el.addEventListener('contextmenu', (e) => { e.preventDefault(); e.stopPropagation(); showMenu(e, [
      { t: 'تشغيل', fn: () => playIndex(i) },
      { t: 'إظهار في المجلد', fn: () => ap.showInFolder(c.path) },
      { t: 'إزالة من القائمة', fn: () => removeAt(i) },
    ]); });
    box.appendChild(el);
  });
  if (keepScroll) box.scrollTop = top;
  const on = box.querySelector('.pl-it.on'); if (on && !keepScroll) on.scrollIntoView({ block: 'nearest' });
}
function removeAt(i) {
  const wasCur = i === S.cur;
  S.list.splice(i, 1);
  if (i < S.cur) S.cur--;
  else if (wasCur) { S.cur = -1; stopAll(); }
  renderList();
}
async function setFiles(paths, playFirst = true) {
  const infos = (await Promise.all(paths.map((p) => ap.fileInfo(p)))).filter(Boolean);
  S.list = sortList(infos);
  S.cur = -1;
  renderList(false);
  if (playFirst && S.list.length) playIndex(paths.length === 1 ? S.list.findIndex((x) => x.path === paths[0]) : 0);
}
async function addFiles(paths) {
  for (const p of paths) { if (S.list.some((x) => x.path === p)) continue; const i = await ap.fileInfo(p); if (i) S.list.push(i); }
  renderList();
  if (S.cur < 0 && S.list.length) playIndex(0);
}
async function openFolder(dir, playFile) {
  const items = sortList(await ap.listFolder(dir, !!cfg('subfolders')));
  S.list = items; S.cur = -1;
  save({ lastDir: dir });
  renderList(false);
  if (!items.length) { osd('لا توجد فيديوهات في هذا المجلد'); return; }
  const idx = playFile ? items.findIndex((x) => x.path === playFile) : 0;
  playIndex(idx < 0 ? 0 : idx);
}
// open one or more files: only those files (or the whole folder when the setting is off)
async function openFiles(paths) {
  if (!paths || !paths.length) return;
  save({ lastDir: ap.dirname(paths[0]) });
  if (paths.length === 1 && !cfg('singleFile')) return openFolder(ap.dirname(paths[0]), paths[0]);
  setFiles(paths);
}
async function openPath(p) { if (await ap.isDir(p)) openFolder(p); else openFiles([p]); }

// ================= loading a clip =================
async function playIndex(i, opt = {}) {
  const it = S.list[i];
  if (!it) return;
  savePos(false);
  const id = ++S.loadId;
  S.cur = i;
  renderList();
  video.pause();
  disposeTracks();
  S.ab = [null, null]; S.loop = false; paintAB();
  S.remuxed = false; clearSubs();
  $('empty').classList.add('hidden');
  $('busy').classList.remove('hidden');
  $('tbFile').textContent = it.name;
  save({ lastFile: it.path });
  S.played = S.played || new Set(); S.played.add(i);
  document.title = it.name + ' - Andoria Player';
  // the new picture shows at once (never the previous clip); if separating the sound takes long, the clip
  // starts with its own sound and switches to the separate tracks as soon as they are ready
  video.muted = true;
  video.classList.add('loading');
  video.src = ap.fileUrl(it.path);
  thumbVid.src = video.src;
  video.playbackRate = S.speed || 1;
  S.pendingSeek = opt.at != null ? opt.at : null;
  let early = false;
  const earlyT = opt.paused ? null : setTimeout(() => {
    if (id !== S.loadId) return;
    early = true; video.volume = Math.max(0, Math.min(1, cfg('master') / 100)); video.muted = false; video.play().catch(() => {});
  }, 350);
  const info = await ap.prepare(it.path);
  clearTimeout(earlyT);
  if (id !== S.loadId) return;
  $('busy').classList.add('hidden');
  S.info = info;
  if (info.error) osd(info.error, 8000);
  video.muted = true; video.volume = 1;
  buildTracks(info);
  setupSubs(info, it);
  ensureCtx();
  if (early && !video.paused) { syncAll(true); S.tracks.forEach((t) => t.el.play().catch(() => {})); }
  else if (!opt.paused) video.play().catch(() => {}); else playIcon();
}
function stopAll() {
  savePos(false);
  S.loadId++;
  video.pause(); video.removeAttribute('src'); video.load();
  disposeTracks(); renderMixer();
  $('empty').classList.remove('hidden');
  clearSubs(); thumbVid.removeAttribute('src');
  $('tbFile').textContent = ''; $('tPos').textContent = fmt(0); $('tDur').textContent = fmt(0);
  $('seekFill').style.width = '0'; playIcon();
}

function buildTracks(info) {
  const vols = cfg('rememberVols') ? (S.set.trackVols || {}) : {};
  info.audio.forEach((a, i) => {
    if (!info.files[i]) return; // this track could not be separated (codec not supported here)
    const el = new Audio();
    if (window.AP_MEDIA_CROSS) el.crossOrigin = 'anonymous';
    el.src = ap.fileUrl(info.files[i]);
    el.preload = 'auto'; el.preservesPitch = cfg('keepPitch');
    const t = { order: i, index: a.index, el, vol: vols[i] != null ? vols[i] : cfg('defVol'), muted: false };
    ensureCtx();
    t.node = S.ctx.createMediaElementSource(el);
    t.gain = S.ctx.createGain();
    t.gain.gain.value = tGain(t);
    t.node.connect(t.gain).connect(S.master);
    S.tracks.push(t);
  });
  const n = S.tracks.length;
  $('badge').textContent = n ? `${ltr(String(n))} ${n === 1 ? 'مسار صوت' : n === 2 ? 'مسارا صوت' : 'مسارات صوت'}` : 'بدون صوت';
  $('badge').classList.remove('hidden');
  clearTimeout(S.badgeT); S.badgeT = setTimeout(() => $('badge').classList.add('hidden'), 3500);
  $('mixCount').textContent = n; $('mixCount').classList.toggle('hidden', n < 2);
  renderMixer();
}

// ================= mixer (popup or pinned strip) =================
const IC = {
  vol: '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z" class="fill"/><path d="M16 9a4 4 0 0 1 0 6"/></svg>',
  mute: '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z" class="fill"/><path d="M16 9l5 6M21 9l-5 6"/></svg>',
  pin: '<svg viewBox="0 0 24 24"><path d="M9 4h6l-1 6 3 3H7l3-3zM12 13v7"/></svg>',
  x: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
};
function trackRow(t) {
  const row = document.createElement('div');
  row.className = 'trk' + (t.muted ? ' muted' : '');
  row.innerHTML = `<span class="n" dir="ltr">${t.order + 1}</span><input type="range" min="0" max="200" step="1" value="${t.vol}" title="مستوى المسار ${t.order + 1}">
    <span class="v" dir="ltr">${t.muted ? '0' : t.vol}%</span><button class="ib mt" title="كتم المسار ${t.order + 1} (${t.order + 1})">${t.muted ? IC.mute : IC.vol}</button>`;
  const sl = row.querySelector('input');
  sl.addEventListener('input', () => { t.vol = +sl.value; if (t.muted) t.muted = false; t.gain.gain.setTargetAtTime(tGain(t), S.ctx.currentTime, 0.015); row.querySelector('.v').textContent = t.vol + '%'; row.classList.remove('muted'); row.querySelector('.mt').innerHTML = IC.vol; });
  sl.addEventListener('change', () => { if (cfg('rememberVols')) { const v = Object.assign({}, S.set.trackVols || {}); v[t.order] = t.vol; save({ trackVols: v }); } });
  row.querySelector('.mt').addEventListener('click', () => toggleTrack(t.order));
  return row;
}
function toggleTrack(i) {
  const t = S.tracks[i]; if (!t) return;
  t.muted = !t.muted; applyTrack(t);
  osd(`المسار ${ltr(String(i + 1))}: ${t.muted ? 'مكتوم' : 'يعمل'}`);
}
let mixOpen = false;
function renderMixer() {
  const pinned = cfg('mixPinned');
  const pop = $('mixPop'), dock = $('mixDock');
  pop.innerHTML = ''; dock.innerHTML = '';
  pop.classList.toggle('hidden', pinned || !mixOpen);
  dock.classList.toggle('hidden', !pinned);
  $('bMix').classList.toggle('on', pinned || mixOpen);
  if (pinned) {
    if (!S.tracks.length) dock.innerHTML = '<div class="mix-none" style="flex:1">لا توجد مسارات صوت</div>';
    S.tracks.forEach((t) => dock.appendChild(trackRow(t)));
    const b = document.createElement('button'); b.className = 'ib pin on'; b.title = 'إلغاء التثبيت'; b.innerHTML = IC.pin;
    b.addEventListener('click', () => { save({ mixPinned: false }); mixOpen = true; renderMixer(); });
    dock.appendChild(b);
    return;
  }
  if (!mixOpen) return;
  const n = S.tracks.length;
  const head = document.createElement('div');
  head.className = 'mixhead';
  head.innerHTML = `<span>الأصوات: ${ltr(String(n))} ${n === 1 ? 'مسار' : 'مسارات'}</span><span class="r">
    <button class="ib" id="mxReset" title="إرجاع الكل">100%</button><button class="ib" id="mxPin" title="تثبيت تحت الفيديو">${IC.pin}</button><button class="ib" id="mxClose" title="إغلاق">${IC.x}</button></span>`;
  pop.appendChild(head);
  if (!n) { const d = document.createElement('div'); d.className = 'mix-none'; d.textContent = S.list[S.cur] ? 'هذا المقطع بدون صوت' : 'افتح مقطعاً أولاً'; pop.appendChild(d); }
  S.tracks.forEach((t) => pop.appendChild(trackRow(t)));
  $('mxClose').addEventListener('click', () => { mixOpen = false; renderMixer(); });
  $('mxPin').addEventListener('click', () => { save({ mixPinned: true }); renderMixer(); });
  $('mxReset').addEventListener('click', () => { S.tracks.forEach((t) => { t.vol = 100; t.muted = false; t.gain.gain.setTargetAtTime(1, S.ctx.currentTime, 0.015); }); save({ trackVols: {} }); renderMixer(); });
}
$('bMix').addEventListener('click', (e) => { e.stopPropagation(); if (cfg('mixPinned')) return; mixOpen = !mixOpen; if (mixOpen && subOpen) { subOpen = false; renderSubPop(); } renderMixer(); });
$('mixPop').addEventListener('mousedown', (e) => e.stopPropagation());
$('stage').addEventListener('mousedown', () => { if (mixOpen) { mixOpen = false; S.skipClick = true; renderMixer(); } });

// ================= transport =================
function playIcon() {
  $('icPlay').innerHTML = video.paused ? '<path d="M8 5v14l11-7z" class="fill"/>' : '<rect x="6" y="5" width="4" height="14" rx="1" class="fill"/><rect x="14" y="5" width="4" height="14" rx="1" class="fill"/>';
}
function togglePlay() {
  if (S.cur < 0) { if (S.list.length) playIndex(0); else pickFiles(); return; }
  ensureCtx();
  if (video.paused) { video.play().catch(() => {}); } else { video.pause(); osd('تم الإيقاف المؤقت'); }
}
function rel(s) { if (video.duration) { video.currentTime = Math.max(0, Math.min(video.duration, video.currentTime + s)); osd((s > 0 ? 'تقديم ' : 'رجوع ') + Math.abs(s) + ' ث'); } }
function frame(d) { if (!video.duration) return; video.pause(); video.currentTime = Math.max(0, video.currentTime + d / 30); }
const SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4];
S.speed = 1;
function setSpeed(v) { S.speed = v; video.playbackRate = v; $('bSpeed').textContent = `${v}×`; $('bSpeed').classList.toggle('on', v !== 1); osd('السرعة ' + ltr(`${v}×`)); }
function stepSpeed(d) { const i = SPEEDS.indexOf(S.speed); setSpeed(SPEEDS[Math.max(0, Math.min(SPEEDS.length - 1, (i < 0 ? 3 : i) + d))]); }
function setVol(v) { v = Math.max(0, Math.min(cfg('maxVol'), Math.round(v))); $('vol').value = v; $('volV').textContent = v + '%'; S.set.master = v; S.allMuted = false; volIcon(); applyMaster(); }
function volIcon() {
  $('icVol').innerHTML = S.allMuted ? '<path d="M4 9h4l5-4v14l-5-4H4z" class="fill"/><path d="M16 9l5 6M21 9l-5 6"/>' : '<path d="M4 9h4l5-4v14l-5-4H4z" class="fill"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>';
  $('bVol').classList.toggle('on', S.allMuted);
}
function muteAll() { S.allMuted = !S.allMuted; volIcon(); applyMaster(); osd(S.allMuted ? 'كتم كل الأصوات' : 'الصوت يعمل'); }
function abPress() {
  if (!video.duration) return;
  const t = video.currentTime;
  if (S.ab[0] == null) { S.ab = [t, null]; osd('بداية الجزء A: ' + ltr(fmt(t))); }
  else if (S.ab[1] == null) { S.ab[1] = t; if (S.ab[1] < S.ab[0]) S.ab.reverse(); S.loop = true; video.currentTime = S.ab[0]; osd(`تكرار من ${ltr(fmt(S.ab[0]))} إلى ${ltr(fmt(S.ab[1]))}`); }
  else { S.ab = [null, null]; S.loop = false; osd('إلغاء تكرار الجزء'); }
  paintAB();
}
function paintAB() {
  const b = $('bAB');
  b.classList.toggle('on', S.ab[0] != null);
  b.textContent = S.ab[0] == null ? 'A-B' : S.ab[1] == null ? 'A-…' : 'A-B ✓';
  paintSeek();
}
async function shot(quiet) {
  if (!video.videoWidth) return;
  const c = document.createElement('canvas'); c.width = video.videoWidth; c.height = video.videoHeight;
  c.getContext('2d').drawImage(video, 0, 0);
  const ext = cfg('shotExt');
  const out = await ap.saveShot({ video: S.list[S.cur].path, time: video.currentTime, dataUrl: c.toDataURL(ext === 'jpg' ? 'image/jpeg' : 'image/png', 0.95), folder: cfg('shotFolder'), ext });
  if (!quiet) osd('تم حفظ اللقطة'); S.lastShot = out;
}
async function full() { await ap.toggleFullscreen(); }
ap.onFullState((f) => { document.body.classList.toggle('full', f); });
ap.onWinState(() => {});
let uiT = null;
document.addEventListener('mousemove', () => {
  if (!document.body.classList.contains('full')) return;
  document.body.classList.add('ui'); clearTimeout(uiT);
  uiT = setTimeout(() => { if (!$('bar').matches(':hover')) document.body.classList.remove('ui'); }, 2200);
});
const ASPECTS = { '16:9': 16 / 9, '4:3': 4 / 3, '21:9': 21 / 9, '1:1': 1 };
function applyVideoLook() {
  const st = $('stage'), W = st.clientWidth, H = st.clientHeight, a = cfg('aspect');
  const rot = ((cfg('rotate') % 360) + 360) % 360, side = rot === 90 || rot === 270;
  let ew, eh; // element size before rotation; the rotated element must fit W x H
  if (ASPECTS[a]) {
    const r = ASPECTS[a], vr = side ? 1 / r : r; // visual ratio after rotation
    let vw, vh; if (W / H > vr) { vh = H; vw = H * vr; } else { vw = W; vh = W / vr; }
    [ew, eh] = side ? [vh, vw] : [vw, vh];
    video.style.objectFit = 'fill';
  } else {
    [ew, eh] = side ? [H, W] : [W, H];
    video.style.objectFit = a === 'fill' ? 'fill' : a === 'cover' ? 'cover' : 'contain';
  }
  Object.assign(video.style, { width: ew + 'px', height: eh + 'px', left: (W - ew) / 2 + 'px', top: (H - eh) / 2 + 'px' });
  const z = cfg('zoom') / 100;
  video.style.transform = `rotate(${rot}deg) scale(${z * (cfg('flipH') ? -1 : 1)}, ${z * (cfg('flipV') ? -1 : 1)})`;
  $('stage').style.background = cfg('bgColor');
  video.style.filter = `brightness(${cfg('bright')}%) contrast(${cfg('contrast')}%) saturate(${cfg('saturate')}%) hue-rotate(${cfg('hue')}deg)`;
}
window.addEventListener('resize', () => applyVideoLook());
new ResizeObserver(() => applyVideoLook()).observe($('stage'));
function vset(patch, msg) { save(patch); applyVideoLook(); if (msg) osd(msg); }
function rotateBy(d) { const r = (((cfg('rotate') + d) % 360) + 360) % 360; vset({ rotate: r }, 'تدوير ' + ltr(r + '°')); }
function zoomBy(d) { const z = d === 0 ? 100 : Math.max(25, Math.min(400, cfg('zoom') + d)); vset({ zoom: z }, 'التكبير ' + ltr(z + '%')); }
function resetVideo() { vset({ rotate: 0, flipH: false, flipV: false, zoom: 100, hue: 0, saturate: 100, bright: 100, contrast: 100, aspect: 'contain' }, 'إرجاع الصورة للأصل'); }
function paintModes() {
  const rp = cfg('repeat');
  $('bRepeat').classList.toggle('on', rp !== 'off'); $('repOne').classList.toggle('hidden', rp !== 'one');
  $('bRepeat').title = TRS(rp === 'one' ? 'تكرار المقطع (R)' : rp === 'all' ? 'تكرار كل القائمة (R)' : 'بدون تكرار (R)');
  $('bShuffle').classList.toggle('on', !!cfg('shuffle'));
  $('bTop').classList.toggle('on', cfg('topMode') !== 'never');
}
const TRS = (x) => (window.TR ? window.TR(x) : x);
function cycleRepeat() { const n = { off: 'one', one: 'all', all: 'off' }[cfg('repeat')]; save({ repeat: n }); paintModes(); osd(n === 'one' ? 'تكرار المقطع' : n === 'all' ? 'تكرار كل القائمة' : 'بدون تكرار'); }
function toggleShuffle() { save({ shuffle: !cfg('shuffle') }); S.played = new Set([S.cur]); paintModes(); osd(cfg('shuffle') ? 'تشغيل عشوائي' : 'تشغيل بالترتيب'); }
function applyTop() { const m = cfg('topMode'); const on = m === 'always' || (m === 'playing' && !video.paused); ap.onTop(on); $('bTop').classList.toggle('on', m !== 'never'); }
function toggleTop() { const n = cfg('topMode') === 'never' ? 'always' : 'never'; save({ topMode: n }); applyTop(); osd(n === 'always' ? 'دائماً في المقدمة' : 'إلغاء دائماً في المقدمة'); }
video.addEventListener('play', () => { if (cfg('topMode') === 'playing') applyTop(); if (cfg('startFull') && !document.body.classList.contains('full') && !S.fullDone) { S.fullDone = true; full(); } });
video.addEventListener('pause', () => { if (cfg('topMode') === 'playing') applyTop(); });
function jumpDialog() {
  if (!video.duration) return;
  sheet(`${head('الذهاب إلى وقت')}<div class="sh-body"><input id="jt" class="field time-input" dir="ltr" value="${fmt(video.currentTime)}">
    <div class="dim" style="text-align:center">مثال: <span dir="ltr">1:25</span> أو <span dir="ltr">0:01:25</span> · المدة <span dir="ltr">${fmt(video.duration)}</span></div></div>
    <div class="sh-foot"><button class="pbtn accent" id="jGo">انتقال</button><button class="pbtn" data-close>إلغاء</button></div>`);
  const go = () => { const p = $('jt').value.trim().split(':').map(Number); if (p.some(isNaN)) return; const t = p.reduce((a, b) => a * 60 + b, 0); video.currentTime = Math.min(video.duration, Math.max(0, t)); closeSheet(); };
  $('jt').focus(); $('jt').select();
  $('jt').addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') go(); if (e.key === 'Escape') closeSheet(); });
  $('jGo').addEventListener('click', go);
}
async function infoDialog() {
  const it = S.list[S.cur]; if (!it || !S.info) return;
  const i = S.info, v = i.video || {}, size = await ap.fileSize(it.path);
  const mb = (n) => (n / 1048576).toFixed(1) + ' MB';
  const rows = [
    ['الملف', it.name], ['الحجم', mb(size)], ['الحاوية', i.container || '-'], ['المدة', fmt(i.duration)],
    ['الفيديو', v.codec ? `${v.codec}${v.tenbit ? ' 10-bit' : ''} · ${v.width}×${v.height} · ${v.fps} fps` : '-'], ['معدل البت', i.bitrate ? i.bitrate + ' kb/s' : '-'],
    ...i.audio.map((a, k) => [`مسار الصوت ${k + 1}`, `${a.codec} · ${a.channels || ''} · ${a.hz ? a.hz + ' Hz' : ''}${a.lang ? ' · ' + a.lang : ''}`]),
    ...(i.subs || []).map((x, k) => [`الترجمة ${k + 1}`, `${x.codec}${x.lang ? ' · ' + x.lang : ''}`]),
  ];
  sheet(`${head('معلومات الملف')}<div class="sh-body"><div class="info">${rows.map(([a, b]) => `<div>${a}</div><div class="v" data-notr>${esc(b)}</div>`).join('')}</div></div><div class="sh-foot"><button class="pbtn" data-close>إغلاق</button></div>`);
}
async function burst() {
  if (!video.videoWidth) return;
  const n = cfg('burstN'), gap = cfg('burstGap');
  osd(`صور متتالية: ${ltr(String(n))}`);
  for (let k = 0; k < n; k++) {
    if (k) { video.currentTime = Math.min(video.duration, video.currentTime + gap); await new Promise((r) => video.addEventListener('seeked', r, { once: true })); }
    await shot(true);
  }
  osd(`تم حفظ ${ltr(String(n))} لقطات`);
}
function toggleList() { save({ showList: !cfg('showList') }); document.body.classList.toggle('no-list', !cfg('showList')); $('bList').classList.toggle('on', cfg('showList'));
  if (cfg('showList') && S.plToCur) { const f = S.plToCur; S.plToCur = null; requestAnimationFrame(f); } }

// ================= menus =================
function fillMenu(m, items) {
  m.innerHTML = '';
  for (const it of items) {
    if (it === '-') { const s = document.createElement('div'); s.className = 'msep'; m.appendChild(s); continue; }
    const b = document.createElement('button'); b.className = 'mi' + (it.chk != null ? ' chk' : '') + (it.sub ? ' has-sub' : '');
    b.innerHTML = `<span class="ck" style="width:12px">${it.chk ? '✓' : ''}</span><span></span>${it.k ? `<span class="k">${esc(it.k)}</span>` : ''}${it.sub ? `<span class="arr">${RTL() ? '◂' : '▸'}</span>` : ''}`;
    b.children[1].textContent = it.t;
    if (it.sub) {
      b.addEventListener('mouseenter', () => openSub(b, it.sub));
      b.addEventListener('click', (ev) => { ev.stopPropagation(); openSub(b, it.sub); });
    } else {
      b.addEventListener('mouseenter', () => { if (m.id === 'menu') hideSub(); });
      b.addEventListener('click', () => { hideMenu(); it.fn(); });
    }
    m.appendChild(b);
  }
}
function placeMenu(m, x, y) {
  m.classList.remove('hidden');
  const r = m.getBoundingClientRect();
  m.style.left = Math.max(4, Math.min(x, window.innerWidth - r.width - 4)) + 'px';
  m.style.top = Math.max(4, Math.min(y, window.innerHeight - r.height - 4)) + 'px';
}
function showMenu(e, items) {
  hideSub();
  const m = $('menu'); fillMenu(m, items);
  m.classList.remove('hidden');
  const r = m.getBoundingClientRect();
  placeMenu(m, RTL() ? e.clientX - r.width : e.clientX, e.clientY);
}
function openSub(btn, items) {
  let m = $('menu2');
  if (!m) { m = document.createElement('div'); m.id = 'menu2'; m.className = 'menu hidden'; document.body.appendChild(m); }
  $('menu').querySelectorAll('.mi.open').forEach((x) => x.classList.remove('open'));
  btn.classList.add('open');
  fillMenu(m, items);
  m.classList.remove('hidden');
  const br = btn.getBoundingClientRect(), r = m.getBoundingClientRect();
  let x = RTL() ? br.left - r.width + 2 : br.right - 2;
  if (x < 4) x = br.right - 2; if (x + r.width > window.innerWidth - 4) x = br.left - r.width + 2;
  placeMenu(m, x, br.top - 4);
}
function hideSub() { const m = $('menu2'); if (m) m.classList.add('hidden'); if ($('menu')) $('menu').querySelectorAll('.mi.open').forEach((x) => x.classList.remove('open')); }
function hideMenu() { $('menu').classList.add('hidden'); hideSub(); }
document.addEventListener('mousedown', (e) => { if (!$('menu').contains(e.target) && !($('menu2') && $('menu2').contains(e.target))) hideMenu(); });
$('stage').addEventListener('contextmenu', (e) => {
  e.preventDefault();
  const items = [
    { t: video.paused ? 'تشغيل' : 'إيقاف مؤقت', k: 'Space', fn: togglePlay },
    { t: 'فتح ملف…', k: 'F3', fn: pickFiles },
    { t: 'فتح مجلد…', k: 'F2', fn: pickFolder },
    '-',
  ];
  S.tracks.forEach((t, i) => items.push({ t: `المسار ${i + 1}`, chk: !t.muted, k: String(i + 1), fn: () => toggleTrack(i) }));
  if (S.tracks.length) items.push('-');
  items.push(
    { t: 'الترجمة…', k: 'Alt+S', fn: () => { subOpen = true; renderSubPop(); } },
    { t: 'البحث عن ترجمة على الإنترنت…', fn: () => subSearchDialog() },
    { t: 'إضافة علامة', k: 'P', fn: addMark },
    { t: 'قائمة العلامات…', k: 'H', fn: marksDialog },
    '-',
    { t: `السرعة: ${S.speed}×`, k: 'C X Z', fn: () => setSpeed(S.speed === 1 ? 1.5 : 1) },
    { t: 'تكرار جزء A-B', k: '\\', fn: abPress },
    { t: 'لقطة', k: 'S', fn: () => shot() },
    { t: 'صور متتالية', k: 'Shift+S', fn: burst },
    { t: 'الذهاب إلى وقت…', k: 'Ctrl+G', fn: jumpDialog },
    { t: 'الفيديو', sub: [
      { t: 'تدوير ' + ltr('90°'), k: 'Ctrl+K', fn: () => rotateBy(90) }, { t: 'قلب أفقي', chk: cfg('flipH'), k: 'Ctrl+Z', fn: () => vset({ flipH: !cfg('flipH') }) },
      { t: 'قلب عمودي', chk: cfg('flipV'), k: 'Ctrl+V', fn: () => vset({ flipV: !cfg('flipV') }) }, '-',
      { t: 'تكبير الصورة', k: 'Ctrl+=', fn: () => zoomBy(10) }, { t: 'تصغير الصورة', k: 'Ctrl+-', fn: () => zoomBy(-10) }, '-',
      ...[['contain', 'نسبة أصلية'], ['16:9', '16:9'], ['4:3', '4:3'], ['21:9', '21:9'], ['fill', 'تمديد لملء الشاشة'], ['cover', 'ملء مع قص الحواف']].map(([v, t]) => ({ t, chk: cfg('aspect') === v, fn: () => vset({ aspect: v }) })),
      '-', { t: 'إرجاع الصورة للأصل', k: 'Ctrl+⌫', fn: resetVideo }] },
    { t: 'الصوت', sub: [
      { t: 'توحيد مستوى الصوت', chk: cfg('normalize'), k: 'Ctrl+N', fn: () => { save({ normalize: !cfg('normalize') }); wireComp(); } }, '-',
      ...[['stereo', 'ستيريو عادي'], ['swap', 'تبديل اليسار واليمين'], ['mono', 'دمج في قناة واحدة (مونو)']].map(([v, t]) => ({ t, chk: cfg('channels') === v, fn: () => { save({ channels: v }); wireChannels(); } })),
      '-', ...Object.entries(EQ_PRESETS).map(([k, [t]]) => ({ t: 'موازن: ' + t, chk: cfg('eqPreset') === k, fn: () => { save({ eqPreset: k, eq: EQ_PRESETS[k][1].slice() }); applyEq(); } }))] },
    { t: 'التكرار', sub: [['off', 'بدون تكرار'], ['one', 'تكرار المقطع'], ['all', 'تكرار كل القائمة']].map(([v, t]) => ({ t, chk: cfg('repeat') === v, fn: () => { save({ repeat: v }); paintModes(); } })).concat(['-', { t: 'تشغيل عشوائي', chk: cfg('shuffle'), fn: toggleShuffle }]) },
    { t: 'معلومات الملف…', k: 'Ctrl+F1', fn: infoDialog },
    { t: 'دائماً في المقدمة', chk: cfg('topMode') !== 'never', k: 'Ctrl+T', fn: toggleTop },
    { t: 'تصدير…', k: 'Ctrl+E', fn: exportDialog },
    '-',
    { t: 'قائمة التشغيل', chk: cfg('showList'), k: 'F6', fn: toggleList },
    { t: 'ملء الشاشة', k: 'Enter', fn: full },
    { t: 'الإعدادات…', k: 'F5', fn: () => openPrefs() },
  );
  showMenu(e, items);
});

// ================= dialogs =================
function sheet(html, wide) { const s = $('sheet'); s.className = 'sheet' + (wide ? ' wide' : ''); s.innerHTML = html; $('modal').classList.remove('hidden'); }
function closeSheet() { $('modal').classList.add('hidden'); }
const head = (t) => `<div class="sh-head"><span>${t}</span><button class="ib" data-close title="إغلاق">${IC.x}</button></div>`;
$('modal').addEventListener('click', (e) => { if (e.target.closest('[data-close]') && !S.exporting) closeSheet(); });

function exportDialog() {
  if (S.cur < 0 || !S.tracks.length) { osd('افتح مقطعاً فيه صوت أولاً'); return; }
  const hasAB = S.ab[0] != null && S.ab[1] != null;
  const muted = S.tracks.filter((t) => tGain(t) === 0).map((t) => `المسار ${t.order + 1}`);
  let range = hasAB ? 'part' : 'full', kind = cfg('expFormat');
  sheet(`${head('تصدير المقطع')}<div class="sh-body">
    <div class="dim">يُحفظ ملف جديد بالأصوات كما ضبطتها الآن، والفيديو الأصلي لا يتغير.</div>
    ${muted.length ? `<div class="note">لن يكون في الملف: ${muted.join('، ')}</div>` : ''}
    <div class="sec">المدة</div>
    <button class="opt" data-r="full"><span>المقطع كاملاً</span><span class="sub" dir="ltr">${fmt(S.info.duration || video.duration)}</span></button>
    <button class="opt" data-r="part" ${hasAB ? '' : 'disabled'}><span>الجزء المحدد A-B فقط</span><span class="sub">${hasAB ? `من ${ltr(fmt(S.ab[0]))} إلى ${ltr(fmt(S.ab[1]))}` : 'حدّده بزر A-B أولاً'}</span></button>
    <div class="sec">الصيغة</div>
    <button class="opt" data-k="mp4"><span>فيديو MP4</span><span class="sub">الصورة بنفس الجودة</span></button>
    <button class="opt" data-k="mp3"><span>${ANDROID ? 'صوت فقط M4A' : 'صوت فقط MP3'}</span><span class="sub" dir="ltr">${cfg('bitrate')}</span></button>
    </div><div class="sh-foot"><button class="pbtn accent" id="xGo">تصدير</button><button class="pbtn" data-close>إلغاء</button></div>`);
  const paint = () => {
    $('sheet').querySelectorAll('[data-r]').forEach((b) => b.classList.toggle('on', b.dataset.r === range));
    $('sheet').querySelectorAll('[data-k]').forEach((b) => b.classList.toggle('on', b.dataset.k === kind));
  };
  $('sheet').querySelectorAll('[data-r]').forEach((b) => b.addEventListener('click', () => { if (!b.disabled) { range = b.dataset.r; paint(); } }));
  $('sheet').querySelectorAll('[data-k]').forEach((b) => b.addEventListener('click', () => { kind = b.dataset.k; paint(); }));
  paint();
  $('xGo').addEventListener('click', async () => {
    if (kind === 'mp3' && muted.length === S.tracks.length) { osd('كل المسارات مكتومة'); return; }
    closeSheet();
    const src = S.list[S.cur].path;
    const sp = await ap.exportSavePath({ src, audioOnly: kind === 'mp3', folder: cfg('expFolder') });
    if (!sp) return;
    if (sp.error) { osd('لا يمكن الحفظ فوق الملف الأصلي'); return; }
    runExport(src, sp.path, range === 'part' ? S.ab[0] : null, range === 'part' ? S.ab[1] : null, kind === 'mp3');
  });
}
async function runExport(src, dst, start, end, audioOnly) {
  S.expTotal = start != null ? end - start : (S.info.duration || video.duration || 1);
  S.exporting = true;
  sheet(`<div class="sh-head"><span>جاري التصدير</span></div><div class="sh-body"><div id="pTxt">جاري الحفظ…</div><div class="bar2"><div id="pBar"></div></div></div>
    <div class="sh-foot"><button class="pbtn danger" id="pCancel">إلغاء التصدير</button></div>`);
  $('pCancel').addEventListener('click', () => ap.exportCancel());
  const r = await ap.exportRun({ src, dst, tracks: S.tracks.map((t) => ({ index: t.index, gain: tGain(t) })), start, end, audioOnly, bitrate: cfg('bitrate') });
  S.exporting = false;
  if (r.ok) {
    sheet(`${head('تم التصدير')}<div class="sh-body"><div class="opt" style="cursor:default"><span class="path" data-notr style="max-width:100%">${esc(r.path)}</span></div></div>
      <div class="sh-foot"><button class="pbtn accent" id="dOpen">فتح المجلد</button><button class="pbtn" data-close>حسناً</button></div>`);
    $('dOpen').addEventListener('click', () => { ap.showInFolder(r.path); closeSheet(); });
  } else if (r.cancelled) { closeSheet(); osd('أُلغي التصدير'); }
  else sheet(`${head('فشل التصدير')}<div class="sh-body"><div class="note" dir="ltr" style="text-align:left;white-space:pre-wrap;max-height:220px;overflow:auto">${esc(r.error || '')}</div></div><div class="sh-foot"><button class="pbtn" data-close>حسناً</button></div>`);
}
ap.onExportProgress((sec) => {
  const tot = S.expTotal || 1;
  if ($('pBar')) $('pBar').style.width = Math.min(100, (sec / tot) * 100) + '%';
  if ($('pTxt')) $('pTxt').textContent = `جاري الحفظ… ${ltr(fmt(sec))} من ${ltr(fmt(tot))}`;
});

// ================= preferences (like PotPlayer F5) =================
const NAV = [
  ['general', 'عام', '<circle cx="12" cy="12" r="3"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2"/>'],
  ['play', 'التشغيل', '<path d="M8 5v14l11-7z"/>'],
  ['audio', 'الصوت', '<path d="M4 6h10M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/>'],
  ['video', 'الفيديو', '<rect x="3" y="5" width="18" height="14" rx="2"/>'],
  ['mouse', 'الفأرة والشاشة', '<rect x="7" y="3" width="10" height="18" rx="5"/><path d="M12 7v3"/>'],
  ['list', 'قائمة التشغيل', '<path d="M4 6h12M4 12h12M4 18h8"/>'],
  ['subs', 'الترجمة', '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M10 10.5a2 2 0 1 0 0 3M17 10.5a2 2 0 1 0 0 3"/>'],
  ['export', 'التصدير', '<path d="M12 4v12M7 11l5 5 5-5M5 20h14"/>'],
  ['shots', 'اللقطات', '<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>'],
  ['keys', 'الاختصارات', '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10h1M11 10h1M15 10h1M8 14h8"/>'],
  ['upd', 'حول', '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>'],
];
let prefTab = 'general';
const sw = (k) => `<button class="sw${cfg(k) ? ' on' : ''}" data-sw="${k}"></button>`;
const selx = (k, opts) => `<select class="sel" data-sel="${k}">${opts.map(([v, t]) => `<option value="${v}"${String(cfg(k)) === String(v) ? ' selected' : ''}>${t}</option>`).join('')}</select>`;
const PC_ONLY = ['نافذة واحدة فقط للبرنامج', 'دائماً في المقدمة', 'التشغيل مع بداية ويندوز', 'إيقاف التشغيل عند الانتقال لنافذة أخرى', 'إيقاف التشغيل عند قفل الشاشة', 'عجلة الفأرة فوق الفيديو', 'الزر الأوسط للفأرة', 'مجلد الحفظ', 'مجلد اللقطات'];
const row = (l, ctrl, sub) => (ANDROID && PC_ONLY.includes(l)) ? '' : `<div class="prow"><div class="l">${l}${sub ? `<div class="sub">${sub}</div>` : ''}</div>${ctrl}</div>`;
const folderRow = (l, k, def) => row(l, `<span class="path"${cfg(k) ? ' data-notr' : ''} title="${esc(cfg(k) || '')}">${esc(cfg(k) || def)}</span><button class="pbtn" data-dir="${k}">تغيير</button>${cfg(k) ? `<button class="pbtn" data-undir="${k}">افتراضي</button>` : ''}`);
function prefPage(tab) {
  switch (tab) {
    case 'general': return `<h3>عام</h3>
      ${row('اللغة', `<select class="sel" data-lang><option value="ar"${EN ? '' : ' selected'}>العربية</option><option value="en"${EN ? ' selected' : ''}>English</option></select>`)}
      ${row('فتح ملف واحد يضع الفيديو وحده في القائمة', sw('singleFile'), 'عند الإيقاف: يضع كل فيديوهات مجلده')}
      ${row('تضمين المجلدات الفرعية عند فتح مجلد', sw('subfolders'), 'مفيد إذا كان SteelSeries يحفظ كل لعبة في مجلد خاص')}
      ${row('تذكّر موضع التوقف لكل فيديو', sw('rememberPos'))}
      ${row('نافذة واحدة فقط للبرنامج', sw('singleInstance'), 'فتح فيديو جديد من ويندوز يذهب إلى نفس النافذة (بعد إعادة التشغيل)')}
      ${row('المظهر', selx('theme', THEME_LIST))}
      ${row('دائماً في المقدمة', selx('topMode', [['never', 'أبداً'], ['always', 'دائماً'], ['playing', 'أثناء التشغيل فقط']]))}
      ${row('التشغيل مع بداية ويندوز', sw('autoStart'))}
      ${row('التحقق من التحديثات عند فتح البرنامج', sw('autoUpd'))}
      ${row('إيقاف التشغيل عند تصغير النافذة', sw('pauseMin'), 'يكمل وحده عند الرجوع للنافذة')}
      ${row('إيقاف التشغيل عند الانتقال لنافذة أخرى', sw('pauseBlur'), 'يكمل وحده عند الرجوع للمشغل')}
      ${row('إيقاف التشغيل عند قفل الشاشة', sw('pauseLock'), 'يكمل وحده عند فتح القفل')}
      ${btns3()}`;
    case 'play': return `<h3>التشغيل</h3>
      ${row('التقديم والرجوع بالأسهم', selx('seekStep', [[5, '5 ثوان'], [10, '10 ثوان'], [30, '30 ثانية']]), 'Shift مع السهم = 30 ثانية')}
      ${row('تشغيل المقطع التالي تلقائياً', sw('autoNext'))}
      ${row('صورة مصغّرة للمشهد فوق شريط التقديم', sw('thumbs'))}
      ${row('التكرار', selx('repeat', [['off', 'بدون تكرار'], ['one', 'تكرار المقطع'], ['all', 'تكرار كل القائمة']]))}
      ${row('تشغيل عشوائي', sw('shuffle'))}
      ${row('بعد انتهاء قائمة التشغيل', selx('afterList', ANDROID ? [['none', 'لا شيء'], ['quit', 'إغلاق البرنامج']] : [['none', 'لا شيء'], ['quit', 'إغلاق البرنامج'], ['shutdown', 'إطفاء الحاسوب (مع عدّ تنازلي)']]))}
      ${row('عند فتح البرنامج بعد إغلاق عادي', selx('onOpen', [['fresh', 'يفتح فارغاً'], ['session', 'استعادة آخر جلسة']]), 'بعد التحديث أو توقف البرنامج المفاجئ تُستعاد الجلسة دائماً: القائمة والفيديو واللحظة')}
      ${row('بدء التشغيل بملء الشاشة', sw('startFull'))}
      ${row('الحفاظ على طبقة الصوت عند تغيير السرعة', sw('keepPitch'), 'عند الإيقاف: الصوت يصبح أحدّ أو أغلظ مع السرعة')}
      ${row('خطوة الصوت العام', selx('volStep', [[1, '1%'], [2, '2%'], [5, '5%'], [10, '10%']]))}
      ${row('الحد الأقصى للصوت العام', selx('maxVol', [[100, '100%'], [150, '150%'], [200, '200%'], [300, '300%']]))}

      ${row('السرعة الحالية', `<span dir="ltr">${S.speed}×</span>`, 'غيّرها بـ [ و ] أو من زر السرعة')}`;
    case 'audio': return `<h3>الصوت</h3>
      ${row('مستوى البداية لكل مسار', `<input type="range" min="0" max="200" step="5" value="${cfg('defVol')}" data-rng="defVol"><span dir="ltr" style="width:40px">${cfg('defVol')}%</span>`)}
      ${row('تذكّر مستوى كل مسار بين المقاطع', sw('rememberVols'))}
      ${row('تثبيت لوحة الأصوات تحت الفيديو', sw('mixPinned'))}
      ${row('مسارات المقطع الحالي', `<span dir="ltr">${S.tracks.length}</span>`, 'البرنامج يتعرف وحده على عدد المسارات')}
      ${row('توحيد مستوى الصوت', sw('normalize'), 'يرفع الأصوات المنخفضة ويخفض العالية (مثل الانفجارات)')}
      ${row('القنوات', selx('channels', [['stereo', 'ستيريو عادي'], ['swap', 'تبديل اليسار واليمين'], ['mono', 'دمج في قناة واحدة (مونو)']]))}
      <h3 style="margin-top:8px">موازن الصوت</h3>
      ${row('الإعداد الجاهز', `<select class="sel" data-eqp>${Object.entries(EQ_PRESETS).map(([k, [t]]) => `<option value="${k}"${cfg('eqPreset') === k ? ' selected' : ''}>${t}</option>`).join('')}${cfg('eqPreset') === 'custom' ? '<option value="custom" selected>مخصّص</option>' : ''}</select>`)}
      <div class="eq">${EQ_FREQ.map((f, i) => `<div class="b"><span dir="ltr" class="eqv">${(cfg('eq')[i] > 0 ? '+' : '') + cfg('eq')[i]}</span><input type="range" min="-12" max="12" step="1" value="${cfg('eq')[i]}" data-eq="${i}"><span>${f >= 1000 ? f / 1000 + 'k' : f}</span></div>`).join('')}</div>
      ${row('تأخير الصوت عن الصورة', `<span class="delay"><button class="ib" data-ad="-50">−</button><span dir="ltr" style="min-width:64px;text-align:center">${(cfg('audioDelay') > 0 ? '+' : '') + cfg('audioDelay')} ms</span><button class="ib" data-ad="50">+</button><button class="pbtn" data-ad="0">صفر</button></span>`, 'موجب = الصوت يتأخر عن الصورة')}`;
    case 'video': return `<h3>الفيديو</h3>
      ${row('نسبة العرض', selx('aspect', [['contain', 'الأصلية'], ['16:9', '16:9'], ['4:3', '4:3'], ['21:9', '21:9'], ['1:1', '1:1'], ['cover', 'ملء مع قص الحواف'], ['fill', 'تمديد لملء الشاشة']]))}
      ${row('التدوير', selx('rotate', [[0, '0°'], [90, '90°'], [180, '180°'], [270, '270°']]))}
      ${row('قلب أفقي (مرآة)', sw('flipH'))}
      ${row('قلب عمودي', sw('flipV'))}
      ${row('التكبير', `<input type="range" min="25" max="400" step="5" value="${cfg('zoom')}" data-rng="zoom"><span dir="ltr" style="width:40px">${cfg('zoom')}%</span>`)}
      ${row('التشبّع', `<input type="range" min="0" max="200" step="5" value="${cfg('saturate')}" data-rng="saturate"><span dir="ltr" style="width:40px">${cfg('saturate')}%</span>`)}
      ${row('اللون', `<input type="range" min="-180" max="180" step="5" value="${cfg('hue')}" data-rng="hue"><span dir="ltr" style="width:40px">${cfg('hue')}°</span>`)}
      ${row('السطوع', `<input type="range" min="50" max="150" step="5" value="${cfg('bright')}" data-rng="bright"><span dir="ltr" style="width:40px">${cfg('bright')}%</span>`)}
      ${row('التباين', `<input type="range" min="50" max="150" step="5" value="${cfg('contrast')}" data-rng="contrast"><span dir="ltr" style="width:40px">${cfg('contrast')}%</span>`)}
      ${row('لون الخلفية حول الفيديو', ['#000000', '#101418', '#1E2433', '#2B2B2B'].map((c) => `<span class="swatch${cfg('bgColor') === c ? ' on' : ''}" data-bg="${c}" style="background:${c};border-color:${cfg('bgColor') === c ? '' : '#3A4766'}"></span>`).join(' '))}
      <div class="btns3"><button class="pbtn" data-act="vreset">إرجاع الصورة للأصل</button></div>`;
    case 'list': return `<h3>قائمة التشغيل</h3>
      ${row('الترتيب', selx('sort', [['new', 'الأحدث في الأعلى'], ['old', 'الأقدم في الأعلى'], ['name', 'حسب الاسم']]))}
      ${row('إظهار قائمة التشغيل', sw('showList'), 'F6')}`;
    case 'subs': return `<h3>الترجمة</h3>
      ${row('تحميل الترجمة الموجودة بجانب الفيديو أو داخله تلقائياً', sw('subAuto'))}
      ${row('اللغة المفضلة', selx('subLang', NET_LANGS))}
      ${row('حجم الخط', `<input type="range" min="16" max="56" step="1" value="${cfg('subSize')}" data-rng="subSize"><span dir="ltr" style="width:40px">${cfg('subSize')}</span>`)}
      ${row('لون النص', ['#ffffff', '#ffe14d', '#7fd3ff', '#9dff9d'].map((c) => `<span class="swatch${cfg('subColor') === c ? ' on' : ''}" data-col="${c}" style="background:${c}"></span>`).join(' '))}
      ${row('الموضع', selx('subPos', [['bottom', 'أسفل الشاشة'], ['top', 'أعلى الشاشة']]))}
      ${row('خلفية داكنة خلف النص', sw('subBg'))}
      ${row('نوع الخط', selx('subFont', [['Segoe UI', 'Segoe UI'], ['Tahoma', 'Tahoma'], ['Arial', 'Arial'], ['Traditional Arabic', 'Traditional Arabic'], ['Sakkal Majalla', 'Sakkal Majalla'], ['Calibri', 'Calibri']]))}
      ${row('خط عريض', sw('subBold'))}
      ${row('سماكة الحدّ حول الحروف', selx('subOutline', [[0, 'بدون'], [1, 'رفيع'], [2, 'متوسط'], [3, 'سميك']]))}
      ${row('البعد عن حافة الشاشة', `<input type="range" min="2" max="25" step="1" value="${cfg('subMargin')}" data-rng="subMargin"><span dir="ltr" style="width:40px">${cfg('subMargin')}%</span>`)}
      <h3 style="margin-top:8px">مواقع تحميل الترجمة</h3>
      <div class="dim" style="margin:-2px 2px 2px">${S.emb && (S.emb.os || S.emb.subdl) ? 'البرنامج فيه مفاتيح مدمجة ويعمل بدونها. إذا أضفت مفتاحك الخاص، يُستعمل أولاً، وإذا انتهى حده ينتقل البرنامج وحده إلى المفتاح المدمج، ثم إلى الموقع الآخر.' : 'أدخل مفتاحاً واحداً على الأقل لتفعيل البحث.'}</div>
      ${row('مفتاح OpenSubtitles', `<input class="field" dir="ltr" style="width:230px" data-txt="osKey" value="${esc(cfg('osKey'))}" placeholder="${S.emb && S.emb.os ? 'المفتاح المدمج مستعمل' : 'API key'}">`, 'اختياري · من opensubtitles.com ← API consumers')}
      ${row('اسم المستخدم في OpenSubtitles (اختياري)', `<input class="field" dir="ltr" style="width:230px" data-txt="osUser" value="${esc(cfg('osUser'))}">`, 'يرفع حد التحميل اليومي')}
      ${row('كلمة المرور (اختياري)', `<input class="field" dir="ltr" type="password" style="width:230px" data-txt="osPass" value="${esc(cfg('osPass'))}">`)}
      ${row('مفتاح SubDL', `<input class="field" dir="ltr" style="width:230px" data-txt="subdlKey" value="${esc(cfg('subdlKey'))}" placeholder="${S.emb && S.emb.subdl ? 'المفتاح المدمج مستعمل' : 'API key'}">`, 'اختياري · من subdl.com ← الحساب ← API')}`;
    case 'export': return `<h3>التصدير</h3>
      ${row('الصيغة الافتراضية', selx('expFormat', [['mp4', 'فيديو MP4'], ['mp3', 'صوت فقط MP3']]))}
      ${row('جودة الصوت', selx('bitrate', [['128k', '128 kbps'], ['192k', '192 kbps'], ['320k', '320 kbps']]))}
      ${folderRow('مجلد الحفظ', 'expFolder', 'نفس مجلد الفيديو')}`;
    case 'mouse': return `<h3>${ANDROID ? 'الشاشة' : 'الفأرة والشاشة'}</h3>
      ${row('عجلة الفأرة فوق الفيديو', selx('wheel', [['volume', 'الصوت'], ['seek', 'التقديم والرجوع']]))}
      ${row('النقر المزدوج على الفيديو', selx('dbl', [['full', 'ملء الشاشة'], ['play', 'تشغيل / إيقاف مؤقت']]))}
      ${row('الزر الأوسط للفأرة', selx('middle', [['mute', 'كتم كل الأصوات'], ['pause', 'تشغيل / إيقاف مؤقت'], ['full', 'ملء الشاشة'], ['none', 'لا شيء']]))}
      ${row('رسائل على الشاشة (الصوت، السرعة…)', sw('osdOn'))}
      ${row('الضغط على المدة يُظهر الوقت المتبقي', sw('showRemain'))}`;
    case 'shots': return `<h3>اللقطات</h3>
      ${row('الصيغة', selx('shotExt', [['png', 'PNG'], ['jpg', 'JPG']]))}
      ${row('عدد الصور المتتالية', selx('burstN', [[3, '3'], [5, '5'], [10, '10'], [20, '20']]))}
      ${row('المدة بين كل صورة', selx('burstGap', [[0.5, '0.5 ث'], [1, '1 ث'], [2, '2 ث'], [5, '5 ث']]))}
      ${folderRow('مجلد اللقطات', 'shotFolder', 'مجلد «لقطات» بجانب الفيديو')}`;
    case 'keys': return `<h3>الاختصارات</h3><div class="dim" style="margin-bottom:4px">اضغط «تغيير» ثم الزر الجديد. Esc للإلغاء. الأرقام 1 إلى 9 ثابتة لكتم المسارات.</div>
      ${ACTIONS.map(([id, label]) => `<div class="krow${capturing === id ? ' cap' : ''}"><span>${label}</span><span class="kbtn">${capturing === id ? '<span class="kchip wait">اضغط الزر الجديد…</span>' : keyOf(id).map((k) => `<span class="kchip">${esc(prettyKey(k))}</span>`).join('') || '<span class="kchip">—</span>'}<button class="pbtn" data-key="${id}">تغيير</button></span></div>`).join('')}
      <div class="btns3"><button class="pbtn" data-act="keysReset">إرجاع الاختصارات الافتراضية</button></div>
      ${btns3()}`;
    case 'upd': return `<h3>حول Andoria Player</h3>
      <div class="about-hero"><div class="about-ic"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" class="fill"/></svg></div><div><div class="about-nm" dir="ltr">Andoria Player</div><div class="dim">مشغّل كل مسارات الصوت معاً</div></div></div>
      ${row('الإصدار', `<span dir="ltr">${esc(S.appInfo.version)}</span>`)}
      ${row('رقم البناء', `<span dir="ltr">b${S.appInfo.build}</span>`)}
      ${row('المطوّر', '<span>موسى سماحة · Andoria</span>')}
      <div id="uBox"><button class="opt" id="uCheck"><span>تحقق من وجود تحديث</span><span class="sub">التحديث ينزّل الجزء المتغيّر فقط</span></button></div>
      ${ANDROID && canShareApp() ? '<button class="opt" id="uShare"><span>مشاركة التطبيق</span><span class="sub">إرسال ملف التطبيق عبر البلوتوث أو المشاركة السريعة أو أي تطبيق آخر</span></button>' : ''}
      ${!ANDROID && ap.shareApp ? '<button class="opt" id="uShare"><span>مشاركة البرنامج</span><span class="sub">يحفظ نسخة محمولة من البرنامج (ملف zip) لترسلها بالبلوتوث أو بأي طريقة، بدون إنترنت</span></button>' : ''}`;
  }
  return '';
}
async function sharePc() {
  closeSheet();
  updCard('مشاركة البرنامج', '<div class="u-ic"><span class="spin"></span></div>', 'جاري تجهيز نسخة البرنامج… قد يستغرق ذلك دقيقة أو دقيقتين', []);
  U.busy = true;
  const r = await ap.shareApp();
  U.busy = false;
  if (!r || r.canceled) { updHide(); return; }
  if (r.error) {
    updCard('تعذّرت مشاركة البرنامج', uIcon(UI.err, 'err'), esc(r.error), [['uX', UI.x, 'إغلاق']]);
    $('uX').addEventListener('click', updHide);
    return;
  }
  updCard('نسخة البرنامج جاهزة', uIcon(UI.ok, 'ok'), `<div dir="ltr">${esc(r.file.split(/[\\/]/).pop())} · ${kb(r.size || 0).replace(/[\u2066-\u2069]/g, '')}</div><div>يفكّ المستلم الملف ويشغّل AndoriaPlayer.exe</div>`,
    [['uB', UI.open, 'إرسال بالبلوتوث', 'accent'], ['uF', UI.open, 'فتح المجلد']]);
  $('uB').addEventListener('click', () => ap.btSend());
  $('uF').addEventListener('click', () => { ap.showItem(r.file); updHide(); });
}
// themes (the same six on the phone and on the PC): each one changes colours and shapes (themes.css)
const THEME_LIST = [['andoria', 'كلاسيكي'], ['amoled', 'سينما'], ['glass', 'زجاج'], ['esports', 'جيمنج HUD'], ['light', 'أبيض Material'], ['mint', 'بسيط']];
function setTheme(t) {
  if (!THEME_LIST.some(([k]) => k === t)) t = 'andoria';
  document.body.dataset.theme = t;
  try { localStorage.setItem('mTheme', t); } catch (e) {}
}
try { setTheme(localStorage.getItem('mTheme') || 'andoria'); } catch (e) { setTheme('andoria'); }
function canShareApp() { try { return String(Native.caps()).includes('share'); } catch (e) { return false; } }
function btns3() { return `<div class="btns3"><button class="pbtn" data-act="exp">تصدير الإعدادات</button><button class="pbtn" data-act="imp">استيراد الإعدادات</button><button class="pbtn danger" data-act="reset">إعادة الضبط</button></div>`; }
function prefRefresh() { const b = $('pBody'); if (!b) return; const top = b.scrollTop; b.innerHTML = prefPage(prefTab); wireBody(); b.scrollTop = top; }
function openPrefs(tab) {
  if (tab) prefTab = tab;
  if (ANDROID && prefTab === 'keys') prefTab = 'general';
  sheet(`${head('الإعدادات')}<div class="prefs"><nav class="pnav">${NAV.filter(([k]) => !(ANDROID && k === 'keys')).map(([k, t, ic]) => [k, ANDROID && k === 'mouse' ? 'الشاشة' : t, ic]).map(([k, t, ic]) => `<button data-tab="${k}" class="${k === prefTab ? 'on' : ''}"><svg viewBox="0 0 24 24">${ic}</svg>${t}</button>`).join('')}</nav>
    <div class="pbody" id="pBody">${prefPage(prefTab)}</div></div>`, true);
  wirePrefs();
}
function wirePrefs() {
  const sh = $('sheet');
  sh.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => {
    prefTab = b.dataset.tab;
    sh.querySelectorAll('[data-tab]').forEach((x) => x.classList.toggle('on', x === b));
    $('pBody').innerHTML = prefPage(prefTab); $('pBody').scrollTop = 0; wireBody();
  }));
  wireBody();
}
function afterPref(k) {
  if (k === 'theme') setTheme(cfg('theme'));
  if (k === 'showList') { document.body.classList.toggle('no-list', !cfg('showList')); $('bList').classList.toggle('on', cfg('showList')); }
  if (k === 'mixPinned') renderMixer();
  if (k === 'aspect' || k === 'bright' || k === 'contrast') applyVideoLook();
  if (/^sub/.test(k)) { SUB.last = ''; }
  if (['rotate', 'flipH', 'flipV', 'zoom', 'saturate', 'hue'].includes(k)) applyVideoLook();
  if (['repeat', 'shuffle'].includes(k)) paintModes();
  if (k === 'topMode') applyTop();
  if (k === 'autoStart') ap.autoStart(cfg('autoStart'));
  if (k === 'maxVol') { $('vol').max = cfg('maxVol'); if (cfg('master') > cfg('maxVol')) setVol(cfg('maxVol')); }
  if (k === 'bgColor') applyVideoLook();
  if (/^sub(Font|Bold|Outline|Margin)/.test(k)) SUB.last = '';
  if (k === 'normalize') wireComp();
  if (k === 'channels') wireChannels();
  if (k === 'keepPitch') S.tracks.forEach((t) => { t.el.preservesPitch = cfg('keepPitch'); });
  if (k === 'showRemain') paintDur();
  if (k === 'sort') { const cur = S.list[S.cur]; sortList(S.list); S.cur = cur ? S.list.indexOf(cur) : -1; renderList(true); $('plItems').scrollTop = 0; } // after sorting stay at the top, do not jump to the playing clip
}
function wireBody() {
  const b = $('pBody');
  b.querySelectorAll('[data-sw]').forEach((x) => x.addEventListener('click', () => { const k = x.dataset.sw; save({ [k]: !cfg(k) }); x.classList.toggle('on', cfg(k)); afterPref(k); }));
  b.querySelectorAll('[data-sel]').forEach((x) => x.addEventListener('change', () => { const k = x.dataset.sel; const v = ['seekStep', 'rotate', 'volStep', 'burstN', 'burstGap', 'subOutline', 'maxVol'].includes(k) ? +x.value : x.value; save({ [k]: v }); afterPref(k); }));
  b.querySelectorAll('[data-rng]').forEach((x) => {
    x.addEventListener('input', () => { const k = x.dataset.rng; S.set[k] = +x.value; x.nextElementSibling.textContent = x.value + (k === 'hue' ? '°' : k === 'subSize' ? '' : '%'); afterPref(k); });
    x.addEventListener('change', () => save({ [x.dataset.rng]: +x.value }));
  });
  b.querySelectorAll('[data-dir]').forEach((x) => x.addEventListener('click', async () => { const d = await ap.pickFolder(cfg(x.dataset.dir) || cfg('lastDir')); if (d) { save({ [x.dataset.dir]: d }); $('pBody').innerHTML = prefPage(prefTab); wireBody(); } }));
  b.querySelectorAll('[data-undir]').forEach((x) => x.addEventListener('click', () => { save({ [x.dataset.undir]: '' }); $('pBody').innerHTML = prefPage(prefTab); wireBody(); }));
  if ($('uCheck')) $('uCheck').addEventListener('click', manualCheck);
  if ($('uShare')) $('uShare').addEventListener('click', ANDROID ? async () => { osd('جاري تجهيز ملف التطبيق…'); const r = await ap.shareApp(); if (r && r.error) osd('تعذّرت مشاركة التطبيق', 4000); } : sharePc);
  const lg = b.querySelector('[data-lang]');
  if (lg) lg.addEventListener('change', () => { savePos(false); save({ lang: lg.value }); ap.setLang(lg.value); });
  b.querySelectorAll('[data-eq]').forEach((x) => x.addEventListener('input', () => {
    const v = cfg('eq').slice(); v[+x.dataset.eq] = +x.value; S.set.eq = v; S.set.eqPreset = 'custom'; applyEq();
    x.parentElement.querySelector('.eqv').textContent = (x.value > 0 ? '+' : '') + x.value;
  }));
  b.querySelectorAll('[data-eq]').forEach((x) => x.addEventListener('change', () => { save({ eq: cfg('eq'), eqPreset: 'custom' }); prefRefresh(); }));
  const eqp = b.querySelector('[data-eqp]');
  if (eqp) eqp.addEventListener('change', () => { if (EQ_PRESETS[eqp.value]) { save({ eqPreset: eqp.value, eq: EQ_PRESETS[eqp.value][1].slice() }); applyEq(); prefRefresh(); } });
  b.querySelectorAll('[data-ad]').forEach((x) => x.addEventListener('click', () => { const d = +x.dataset.ad; if (d === 0) { save({ audioDelay: 0 }); syncAll(true); } else audioDelay(d); prefRefresh(); }));
  b.querySelectorAll('[data-bg]').forEach((x) => x.addEventListener('click', () => { save({ bgColor: x.dataset.bg }); applyVideoLook(); prefRefresh(); }));
  b.querySelectorAll('[data-col]').forEach((x) => x.addEventListener('click', () => { save({ subColor: x.dataset.col }); SUB.last = ''; prefRefresh(); }));
  b.querySelectorAll('[data-txt]').forEach((x) => { x.addEventListener('keydown', (e) => e.stopPropagation()); x.addEventListener('change', () => save({ [x.dataset.txt]: x.value.trim() })); });
  b.querySelectorAll('[data-key]').forEach((x) => x.addEventListener('click', () => { capturing = x.dataset.key; prefRefresh(); }));
  b.querySelectorAll('[data-act]').forEach((x) => x.addEventListener('click', async () => {
    const a = x.dataset.act;
    if (a === 'vreset') { resetVideo(); prefRefresh(); }
    if (a === 'keysReset') { save({ keys: {} }); prefRefresh(); osd('تم إرجاع الاختصارات الافتراضية'); }
    if (a === 'exp') { const f = await ap.settingsExport(); if (f) osd('تم تصدير الإعدادات'); }
    if (a === 'imp') { const r = await ap.settingsImport(); if (r && r.error) osd(r.error); else if (r && r.ok) { savePos(false); ap.reload(); } }
    if (a === 'reset') {
      if (x.dataset.sure) { await ap.settingsReset(); ap.reload(); }
      else { x.dataset.sure = '1'; x.textContent = 'اضغط مرة أخرى للتأكيد'; }
    }
  }));
}

// ================= updates (never forced, small code package only) =================
const kb = (n) => (n >= 1048576 ? ltr((n / 1048576).toFixed(1) + ' MB') : ltr(Math.max(1, Math.round(n / 1024)) + ' KB'));
const UIC = (d) => `<svg viewBox="0 0 24 24">${d}</svg>`;
const UI = {
  dl: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>', ok: '<path d="M5 12.5l4.5 4.5L19 7.5"/>', err: '<circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.2v.3"/>',
  pause: '<rect x="6.5" y="5" width="3.6" height="14" rx="1" class="fill"/><rect x="13.9" y="5" width="3.6" height="14" rx="1" class="fill"/>',
  play: '<path d="M8 5v14l11-7z" class="fill"/>', x: '<path d="M6 6l12 12M18 6L6 18"/>', later: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  restart: '<path d="M20 12a8 8 0 1 1-2.3-5.6M20 4v5h-5"/>', open: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
};
const U = { busy: false, paused: false, kind: '', r: null, lastT: 0, lastG: 0, speed: 0 };
function updBar(html) { const b = $('updBar'); b.innerHTML = html; b.classList.remove('hidden'); }
function updHide() { $('updBar').classList.add('hidden'); S.updShown = false; U.busy = false; }
const bName = (r) => ltr('b' + r.build);
// one card for every step; the two buttons always have the same width, height and frame
function updCard(title, mid, sub, btns) {
  updBar(`<div class="u-card"><div class="u-title">${title}</div>${mid}<div class="u-sub" id="uSub">${sub || ''}</div>
    <div class="u-btns${btns.length === 1 ? ' one' : ''}">${btns.map(([id, ic, t, cls]) => `<button class="pbtn ${cls || ''}" id="${id}">${UIC(ic)}<span>${t}</span></button>`).join('')}</div></div>`);
}
const uIcon = (ic, cls = '') => `<div class="u-ic ${cls}">${UIC(ic)}</div>`;
const uRing = () => '<div class="u-ring" id="uRing" style="--p:0"><div class="u-in"><span dir="ltr" id="uPct">0%</span></div></div>';
function secs(n) { n = Math.max(1, Math.round(n)); return n < 60 ? `${ltr(String(n))} ${n === 1 ? 'ثانية' : n <= 10 ? 'ثوانٍ' : 'ثانية'}` : `${ltr(String(Math.ceil(n / 60)))} ${Math.ceil(n / 60) <= 10 ? 'دقائق' : 'دقيقة'}`; }
function paintPause() {
  const b = $('uP'); if (!b) return;
  b.innerHTML = UIC(U.paused ? UI.play : UI.pause) + `<span>${U.paused ? 'متابعة' : 'إيقاف مؤقت'}</span>`;
  const r = $('uRing'); if (r) r.classList.toggle('paused', U.paused);
}
function showProgress(r, kind) {
  U.busy = true; U.paused = false; U.kind = kind; U.r = r; U.lastT = 0; U.lastG = 0; U.speed = 0;
  updCard(`تحميل التحديث ${bName(r)}`, uRing(), 'جاري الاتصال…', [['uP', UI.pause, 'إيقاف مؤقت'], ['uC', UI.x, 'إلغاء', 'danger-o']]);
  $('uP').addEventListener('click', () => {
    U.paused = !U.paused; paintPause();
    if (U.kind === 'full' && !U.paused && U.stopped) { U.stopped = false; ap.apkStart(U.r.url); } // continue after an error / no connection
    else ap.updCtl(U.paused ? 'pause' : 'resume');
  });
  $('uC').addEventListener('click', () => { ap.updCtl('cancel'); updHide(); S.dismissed = r.build; osd('تم إلغاء التحديث'); });
}
function onUpdProgress(p) {
  if (!p || typeof p !== 'object') return;
  const st = p.state;
  if (st === 'run' || st === 'paused' || st === 'fetched') {
    if (!$('uRing')) return;
    const pct = p.total > 0 ? Math.min(100, Math.floor(p.got * 100 / p.total)) : 0;
    $('uRing').style.setProperty('--p', st === 'fetched' ? 100 : pct);
    $('uPct').textContent = (st === 'fetched' ? 100 : pct) + '%';
    const now = Date.now();
    if (st === 'run' && U.lastT && now > U.lastT) { const v = (p.got - U.lastG) / ((now - U.lastT) / 1000); if (v >= 0) U.speed = U.speed ? U.speed * 0.7 + v * 0.3 : v; }
    U.lastT = now; U.lastG = p.got;
    const sizes = `<span dir="ltr">${kb(p.got).replace(/[⁦-⁩]/g, '')} / ${p.total > 0 ? kb(p.total).replace(/[⁦-⁩]/g, '') : '…'}</span>`;
    if (st === 'paused') { U.paused = true; paintPause(); $('uSub').innerHTML = `<div>متوقف مؤقتاً</div><div>${sizes}</div>`; }
    else if (st === 'fetched') { $('uSub').innerHTML = `<div>${U.kind === 'full' ? 'جاري فتح التثبيت…' : 'جاري التثبيت…'}</div><div>${sizes}</div>`; ['uP', 'uC'].forEach((k) => { if ($(k)) $(k).disabled = true; }); }
    else {
      if (U.paused) { U.paused = false; paintPause(); }
      const left = U.speed > 0 && p.total > 0 ? `متبقي ${secs((p.total - p.got) / U.speed)}` : '';
      $('uSub').innerHTML = `<div>${sizes}${U.speed > 0 ? ` · <span dir="ltr">${kb(U.speed).replace(/[⁦-⁩]/g, '')}/s</span>` : ''}</div><div>${left}</div>`;
    }
    return;
  }
  if (U.kind !== 'full') return;
  const r = U.r;
  if (st === 'done') {
    U.busy = false;
    updCard('اكتمل تحميل التحديث', uIcon(UI.ok, 'ok'), 'اتبع خطوات التثبيت التي تظهر على الشاشة', [['uI', UI.open, 'فتح التثبيت', 'accent'], ['uX', UI.x, 'إغلاق']]);
    $('uI').addEventListener('click', () => ap.apkInstall()); $('uX').addEventListener('click', updHide);
  } else if (st === 'perm') {
    U.busy = false;
    updCard('السماح بتثبيت التحديث', uIcon(UI.dl), 'اسمح لـ Andoria Player بتثبيت التحديثات من الصفحة التي فُتحت، ثم ارجع واضغط «متابعة»', [['uG', UI.play, 'متابعة', 'accent'], ['uX', UI.x, 'إلغاء']]);
    $('uG').addEventListener('click', () => { showProgress(r, 'full'); ap.apkStart(r.url); }); $('uX').addEventListener('click', updHide);
  } else if (st === 'error') {
    if (!$('uRing')) return;
    U.stopped = true; U.paused = true; paintPause();
    $('uSub').innerHTML = '<div>توقف التحميل: تحقق من الاتصال</div><div>اضغط «متابعة» ليكمل من حيث توقف</div>';
  } else if (st === 'canceled') updHide();
}
if (ap.onUpdProgress) ap.onUpdProgress(onUpdProgress);
async function installSmall(r) {
  showProgress(r, 'small');
  const x = await ap.updateInstall(r.info);
  if (x && x.canceled) return;
  if (!x || !x.ok) {
    U.busy = false;
    updCard('فشل التحديث', uIcon(UI.err, 'err'), esc((x && x.error) || 'فشل التحديث'), [['uR', UI.restart, 'إعادة المحاولة', 'accent'], ['uX', UI.x, 'إغلاق']]);
    $('uR').addEventListener('click', () => installSmall(r)); $('uX').addEventListener('click', updHide);
    return;
  }
  U.busy = false;
  updCard(`تم تثبيت التحديث ${bName(r)}`, uIcon(UI.ok, 'ok'), 'أعد التشغيل لتطبيقه', [['uR', UI.restart, 'إعادة التشغيل الآن', 'accent'], ['uL', UI.later, 'لاحقاً']]);
  $('uR').addEventListener('click', () => { savePos(false); saveSession({ resume: true }); try { sessionStorage.setItem('apRestart', '1'); } catch (e) {} S.noSessionSave = true; ap.updateRestart(); });
  $('uL').addEventListener('click', updHide);
}
function offer(r) {
  const fullHere = r.full && ANDROID && (() => { try { return String(Native.caps()).includes('updctl'); } catch (e) { return false; } })();
  if (r.small) {
    if (!video.paused) video.pause();
    updCard(`يوجد تحديث جديد ${bName(r)}`, uIcon(UI.dl), `حجمه ${kb(r.size || 0)} فقط · ينزّل الجزء المتغيّر فقط`, [['uG', UI.dl, 'تحديث الآن', 'accent'], ['uN', UI.later, 'لاحقاً']]);
    $('uG').addEventListener('click', () => installSmall(r));
  } else if (r.full) {
    updCard(`يوجد إصدار كامل جديد ${bName(r)}`, uIcon(UI.dl), `حجمه ${kb(r.size || 0)} · مرة واحدة فقط لأن الجزء الأساسي من ${ANDROID ? 'التطبيق' : 'البرنامج'} تغيّر`,
      [['uG', UI.dl, ANDROID ? 'تحديث الآن' : 'تحميل المثبّت', 'accent'], ['uN', UI.later, 'لاحقاً']]);
    $('uG').addEventListener('click', () => {
      if (fullHere) { if (!video.paused) video.pause(); showProgress(r, 'full'); ap.apkStart(r.url); }
      else { ap.openUrl(r.url); updHide(); }
    });
  }
  $('uN').addEventListener('click', () => { S.dismissed = r.build; updHide(); });
}
// newest build straight from GitHub (the file server can keep an older copy for a few minutes after a build)
async function latestBuild() {
  try {
    const r = await fetch(`https://api.github.com/repos/andoria43/Androia-player-updates/contents/player-${ANDROID ? 'android' : 'pc'}-latest.json?ref=main`, { headers: { Accept: 'application/vnd.github.raw' }, cache: 'no-store' });
    if (!r.ok) return 0;
    return (await r.json()).build || 0;
  } catch (e) { return 0; }
}
let autoRetry = 0, retryT = null;
async function autoCheck() {
  if (!cfg('autoUpd') || S.updShown || S.exporting) return;
  S.lastCheck = Date.now();
  clearTimeout(retryT);
  const r = await ap.updateCheck();
  if (!r || r.error) { retryT = setTimeout(autoCheck, 60000); return; } // no connection yet: try again in a minute
  if (!(r.small || r.full)) {
    // the server copy may still be the old one: ask GitHub directly and look again in a minute
    if (!r.pendingRestart && autoRetry < 8) {
      const b = await latestBuild();
      if (b && b > (S.appInfo.build || 0) && S.dismissed !== b) { autoRetry++; retryT = setTimeout(autoCheck, 60000); }
    }
    return;
  }
  autoRetry = 0;
  if (S.dismissed === r.build) return;
  if (!$('modal').classList.contains('hidden')) { setTimeout(autoCheck, 30000); return; } // do not cover an open dialog
  S.updShown = true; offer(r);
}
async function manualCheck() {
  $('uBox').innerHTML = '<div class="prow"><span class="spin"></span><span class="l">جاري التحقق…</span></div>';
  const r = await ap.updateCheck();
  if (r.error) $('uBox').innerHTML = `<div class="note">${esc(r.error)}</div>`;
  else if (r.upToDate) {
    $('uBox').innerHTML = r.pendingRestart ? `${row('التحديث مثبّت، أعد التشغيل لتطبيقه', '<button class="pbtn accent" id="uRs">إعادة التشغيل</button>')}` : row('عندك آخر إصدار ✓', '');
    if ($('uRs')) $('uRs').addEventListener('click', () => { saveSession({ resume: true }); try { sessionStorage.setItem('apRestart', '1'); } catch (e) {} S.noSessionSave = true; ap.updateRestart(); });
  } else { closeSheet(); offer(r); }
}

// ================= wiring =================
async function pickFiles() { const f = await ap.pickFile(cfg('lastDir')); if (f && f.length) openFiles(f); }
async function pickFolder() { const d = await ap.pickFolder(cfg('lastDir')); if (d) openFolder(d); }
document.querySelectorAll('[data-w]').forEach((b) => b.addEventListener('click', () => ap.win(b.dataset.w)));
$('titlebar').addEventListener('dblclick', (e) => { if (!e.target.closest('.tb-win')) ap.win('max'); });
$('eOpen').addEventListener('click', pickFiles);
$('eFolder').addEventListener('click', pickFolder);
$('bOpen').addEventListener('click', pickFiles);
$('plAdd').addEventListener('click', async () => { const f = await ap.pickFile(cfg('lastDir')); if (f && f.length) addFiles(f); });
$('plFolder').addEventListener('click', pickFolder);
// playlist width: drag the inner edge towards the video, double-click to reset; button toggles wide/normal
function setListW(w, keep) { w = Math.max(200, Math.min(Math.round(window.innerWidth * 0.75), Math.round(w))); $('plist').style.width = w + 'px'; S.set.listW = w; if (!keep) save({ listW: w }); applyVideoLook(); }
let gripX = null, gripW = 0;
$('plGrip').addEventListener('mousedown', (e) => { e.preventDefault(); gripX = e.clientX; gripW = $('plist').offsetWidth; $('plGrip').classList.add('drag'); document.body.classList.add('resizing'); });
window.addEventListener('mousemove', (e) => { if (gripX == null) return; const d = RTL() ? e.clientX - gripX : gripX - e.clientX; setListW(gripW + d, true); });
window.addEventListener('mouseup', () => { if (gripX == null) return; gripX = null; $('plGrip').classList.remove('drag'); document.body.classList.remove('resizing'); save({ listW: S.set.listW }); });
$('plGrip').addEventListener('dblclick', () => setListW(260));
$('plWide').addEventListener('click', () => {
  const wide = Math.round(window.innerWidth * 0.5);
  if ($('plist').offsetWidth < wide - 20) { S.listPrev = $('plist').offsetWidth; setListW(wide); } else setListW(S.listPrev && S.listPrev < wide - 20 ? S.listPrev : 260);
});
const SORTS = [['new', 'الأحدث أولاً'], ['old', 'الأقدم أولاً'], ['name', 'حسب الاسم']];
$('plSort').addEventListener('click', (e) => showMenu(e, SORTS.map(([v, t]) => ({ t, chk: cfg('sort') === v, fn: () => { save({ sort: v }); afterPref('sort'); osd('الترتيب: ' + t); } }))));
const plClear = () => { S.list = []; S.cur = -1; stopAll(); renderList(); };
$('plMore').addEventListener('click', (e) => showMenu(e, [{ t: 'حفظ قائمة التشغيل…', fn: plSave }, { t: 'فتح قائمة تشغيل (m3u)…', fn: plLoad }, '-', { t: 'تفريغ القائمة', fn: plClear }]));
$('plClose').addEventListener('click', toggleList);
$('plSearch').addEventListener('input', () => renderList());
$('plSearch').addEventListener('keydown', (e) => e.stopPropagation());
$('bPlay').addEventListener('click', togglePlay);
$('bStop').addEventListener('click', () => { if (S.cur >= 0) { video.pause(); video.currentTime = 0; savePos(true); osd('إيقاف'); } });
$('bPrev').addEventListener('click', () => S.cur > 0 && playIndex(S.cur - 1));
$('bNext').addEventListener('click', () => S.cur < S.list.length - 1 && playIndex(S.cur + 1));
$('bSpeed').addEventListener('click', (e) => showMenu(e, SPEEDS.map((v) => ({ t: `${v}×`, chk: v === S.speed, fn: () => setSpeed(v) }))));
$('bAB').addEventListener('click', abPress);
$('bRepeat').addEventListener('click', cycleRepeat);
$('bShuffle').addEventListener('click', toggleShuffle);
$('bTop').addEventListener('click', toggleTop);
const plSave = async () => { if (!S.list.length) return; const f = await ap.m3uSave(S.list.map((x) => x.path)); if (f) osd('تم حفظ قائمة التشغيل'); };
const plLoad = async () => { const l = await ap.m3uOpen(); if (l && l.length) { S.list = []; const infos = (await Promise.all(l.map((p) => ap.fileInfo(p)))).filter(Boolean); S.list = infos; S.cur = -1; renderList(false); playIndex(0); } else if (l) osd('القائمة فارغة'); };
$('bShot').addEventListener('click', shot);
$('bExport').addEventListener('click', exportDialog);
$('bList').addEventListener('click', toggleList);
$('bSettings').addEventListener('click', () => openPrefs());
$('bFull').addEventListener('click', full);
$('bVol').addEventListener('click', muteAll);
$('vol').addEventListener('input', () => setVol(+$('vol').value));
$('vol').addEventListener('change', () => save({ master: +$('vol').value }));
video.addEventListener('click', () => { if (S.skipClick) { S.skipClick = false; return; } togglePlay(); });
video.addEventListener('dblclick', () => { if (cfg('dbl') === 'play') { S.skipClick = false; togglePlay(); } else full(); });
video.addEventListener('auxclick', (e) => { if (e.button === 1) { e.preventDefault(); if (cfg('middle') === 'mute') muteAll(); else if (cfg('middle') === 'pause') togglePlay(); else if (cfg('middle') === 'full') full(); } });
$('stage').addEventListener('wheel', (e) => { e.preventDefault(); if (cfg('wheel') === 'seek') { rel(e.deltaY < 0 ? cfg('seekStep') : -cfg('seekStep')); return; } setVol(cfg('master') + (e.deltaY < 0 ? cfg('volStep') : -cfg('volStep'))); osd('الصوت ' + ltr(cfg('master') + '%')); clearTimeout(S.volT); S.volT = setTimeout(() => save({ master: cfg('master') }), 600); }, { passive: false });

// ================= subtitles =================
const SUB = { tracks: [], cur: -1, cues: [], hidden: false, delay: 0 };
function tsec(t) { const m = t.trim().replace(',', '.').match(/(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)/); return m ? (+(m[1] || 0)) * 3600 + (+m[2]) * 60 + parseFloat(m[3]) : 0; }
function parseSrtVtt(text) {
  const cues = [];
  for (const block of text.replace(/\r/g, '').split(/\n\s*\n/)) {
    const lines = block.split('\n');
    const i = lines.findIndex((l) => l.includes('-->'));
    if (i < 0) continue;
    const [a, b] = lines[i].split('-->');
    const body = lines.slice(i + 1).join('\n').replace(/<\/?(?:i|b|u|font)[^>]*>/gi, '').replace(/\{\\[^}]*\}/g, '').trim();
    if (body) cues.push({ s: tsec(a), e: tsec(b.trim().split(/\s+/)[0]), t: body, top: false });
  }
  return cues;
}
function parseAss(text) {
  const cues = []; let fmt = null;
  for (const raw of text.replace(/\r/g, '').split('\n')) {
    const line = raw.trim();
    if (/^Format:/i.test(line) && fmt === null && /Text\s*$/i.test(line)) { fmt = line.slice(7).split(',').map((x) => x.trim().toLowerCase()); continue; }
    if (!/^Dialogue:/i.test(line)) continue;
    const f = fmt || ['layer', 'start', 'end', 'style', 'name', 'marginl', 'marginr', 'marginv', 'effect', 'text'];
    const parts = line.slice(9).split(',');
    const txt = parts.slice(f.length - 1).join(',');
    const get = (k) => (parts[f.indexOf(k)] || '').trim();
    const top = /\\an[789]/.test(txt) || /\\a[567]\b/.test(txt);
    if (/\\p[1-9]/.test(txt)) continue; // vector drawings
    const t = txt.replace(/\{[^}]*\}/g, '').replace(/\\N/gi, '\n').replace(/\\h/g, ' ').trim();
    if (t) cues.push({ s: tsec(get('start')), e: tsec(get('end')), t, top });
  }
  return cues.sort((x, y) => x.s - y.s);
}
const parseSub = (text, name) => (/\.(ass|ssa)$/i.test(name) || /^\s*\[Script Info\]/i.test(text) ? parseAss(text) : parseSrtVtt(text));
const LANGS = { ar: 'العربية', ara: 'العربية', en: 'English', eng: 'English', fr: 'Français', fre: 'Français', fra: 'Français', ja: '日本語', jpn: '日本語', es: 'Español', spa: 'Español', de: 'Deutsch', ger: 'Deutsch', tr: 'Türkçe', tur: 'Türkçe', ru: 'Русский', rus: 'Русский' };
function langOf(code) { return LANGS[(code || '').toLowerCase()] || code || ''; }
function clearSubs() { SUB.tracks = []; SUB.cur = -1; SUB.cues = []; $('subs').innerHTML = ''; $('subsTop').innerHTML = ''; SUB.last = ''; $('bSubs').classList.remove('on'); }
async function setupSubs(info, it) {
  const tr = [];
  (info.subs || []).forEach((t) => {
    const f = (info.subFiles || []).find((x) => x.order === t.order);
    tr.push({ label: (langOf(t.lang) || `ترجمة ${t.order + 1}`) + (t.title ? ` · ${t.title}` : ''), kind: f ? 'مدمجة' : 'مدمجة (صورة، غير مدعومة)', file: f ? f.file : null, lang: t.lang, def: t.def });
  });
  (info.external || []).forEach((x) => { const m = x.name.match(/\.([a-z]{2,3})\.(srt|ass|ssa|vtt)$/i); tr.push({ label: x.name, kind: 'ملف خارجي', file: x.file, lang: m ? m[1] : '' }); });
  SUB.tracks = tr;
  if (!cfg('subAuto') || !tr.length) return;
  const pl = cfg('subLang');
  const usable = tr.filter((t) => t.file);
  const pick = usable.find((t) => t.kind === 'ملف خارجي' && t.lang && t.lang.startsWith(pl)) || usable.find((t) => t.lang && t.lang.slice(0, 2) === pl) || usable.find((t) => t.kind === 'ملف خارجي') || usable.find((t) => t.def) || null;
  if (pick) selectSub(tr.indexOf(pick), true);
}
async function selectSub(i, quiet) {
  const t = SUB.tracks[i];
  if (!t || !t.file) { SUB.cur = -1; SUB.cues = []; $('subs').innerHTML = ''; $('subsTop').innerHTML = ''; SUB.last = ''; $('bSubs').classList.remove('on'); if (!quiet) osd('الترجمة متوقفة'); renderSubPop(); return; }
  const text = t.text || await ap.readSub(t.file);
  if (!text) { osd('تعذرت قراءة ملف الترجمة'); return; }
  SUB.cues = parseSub(text, t.file); SUB.cur = i; SUB.hidden = false; SUB.last = '';
  $('bSubs').classList.add('on');
  if (!quiet) osd('الترجمة: ' + t.label);
  renderSubPop();
}
async function addSubFile(file, text) {
  if (!file) return;
  const name = ap.basename(file);
  let i = SUB.tracks.findIndex((t) => t.file === file);
  if (i < 0) { SUB.tracks.push({ label: name, kind: 'ملف خارجي', file, lang: '', text }); i = SUB.tracks.length - 1; }
  else if (text) SUB.tracks[i].text = text;
  selectSub(i);
}
function subStyle() {
  const fs = Math.round(cfg('subSize') * Math.max(0.6, $('stage').clientHeight / 720)) + 'px';
  for (const id of ['subs', 'subsTop']) {
    const box = $(id);
    box.classList.toggle('bg', !!cfg('subBg'));
    box.style.fontSize = fs; box.style.color = cfg('subColor');
  }
  const o = cfg('subOutline'), sh = o ? `0 0 ${o + 1}px #000, ${o}px ${o}px ${o}px #000, -${o}px -${o}px ${o}px #000, ${o}px -${o}px ${o}px #000, -${o}px ${o}px ${o}px #000` : 'none';
  for (const id of ['subs', 'subsTop']) { const b = $(id); b.style.fontFamily = `"${cfg('subFont')}", "Segoe UI", Tahoma, sans-serif`; b.style.fontWeight = cfg('subBold') ? '700' : '400'; b.style.setProperty('--sh', sh); }
  $('subs').style.bottom = cfg('subPos') === 'top' ? '' : cfg('subMargin') + '%'; $('subs').style.top = cfg('subPos') === 'top' ? cfg('subMargin') + '%' : '';
  $('subsTop').style.top = cfg('subMargin') + '%';
  $('subs').classList.toggle('top', cfg('subPos') === 'top');
  $('subsTop').classList.toggle('hidden', cfg('subPos') === 'top');
}
function renderSubsAt(t) {
  if (SUB.cur < 0 || SUB.hidden) { if (SUB.last) { $('subs').innerHTML = ''; $('subsTop').innerHTML = ''; SUB.last = ''; } return; }
  const tt = t - SUB.delay;
  const act = SUB.cues.filter((c) => tt >= c.s && tt <= c.e);
  const key = act.map((c) => c.t + c.top).join('|');
  if (key === SUB.last) return;
  SUB.last = key;
  const main = $('subs'), top = $('subsTop'); main.innerHTML = ''; top.innerHTML = ''; subStyle();
  const allTop = cfg('subPos') === 'top';
  for (const c of act) { const d = document.createElement('div'); d.className = 'ln'; d.textContent = c.t; (c.top && !allTop ? top : main).appendChild(d); }
}
window.addEventListener('resize', () => { SUB.last = ''; });
function subDelay(d) { SUB.delay = Math.round((SUB.delay + d) * 10) / 10; SUB.last = ''; osd('تأخير الترجمة ' + ltr((SUB.delay > 0 ? '+' : '') + SUB.delay.toFixed(1) + ' ث')); renderSubPop(); }
function audioDelay(d) { const v = Math.round((cfg('audioDelay') || 0) + d); save({ audioDelay: v }); syncAll(true); osd('تأخير الصوت ' + ltr((v > 0 ? '+' : '') + v + ' ms')); }
let subOpen = false;
function renderSubPop() {
  const p = $('subPop');
  p.classList.toggle('hidden', !subOpen);
  if (!subOpen) return;
  const rows = SUB.tracks.map((t, i) => `<button class="sopt${i === SUB.cur ? ' on' : ''}" data-st="${i}" ${t.file ? '' : 'disabled'}><span${t.kind === 'ملف خارجي' ? ' data-notr' : ''}>${esc(t.label)}</span><span class="s2">${esc(t.kind)}</span></button>`).join('');
  p.innerHTML = `<div class="mixhead"><span>الترجمة</span><span class="r"><button class="ib" id="spClose" title="إغلاق">${IC.x}</button></span></div>
    ${rows || '<div class="mix-none">لا توجد ترجمة لهذا المقطع</div>'}
    <button class="sopt${SUB.cur < 0 ? ' on' : ''}" data-st="-1"><span>إيقاف الترجمة</span></button>
    <div class="sopt" style="cursor:default"><span>تأخير الترجمة</span><span class="delay"><button class="ib" id="sdM">−</button><span dir="ltr" style="min-width:52px;text-align:center">${(SUB.delay > 0 ? '+' : '') + SUB.delay.toFixed(1)} ث</span><button class="ib" id="sdP">+</button></span></div>
    <button class="sopt dash" id="spAdd"><span>+ إضافة ملف ترجمة…</span></button>
    <button class="sopt dash" id="spNet"><span>🔎 البحث عن ترجمة على الإنترنت…</span></button>`;
  p.querySelectorAll('[data-st]').forEach((b) => b.addEventListener('click', () => selectSub(+b.dataset.st)));
  $('spClose').addEventListener('click', () => { subOpen = false; renderSubPop(); });
  $('sdM').addEventListener('click', () => subDelay(-0.1));
  $('sdP').addEventListener('click', () => subDelay(0.1));
  $('spAdd').addEventListener('click', async () => { const f = await ap.pickSub(cfg('lastDir')); if (f) addSubFile(f); });
  $('spNet').addEventListener('click', () => { subOpen = false; renderSubPop(); subSearchDialog(); });
}
$('bSubs').addEventListener('click', (e) => { e.stopPropagation(); subOpen = !subOpen; if (subOpen && mixOpen) { mixOpen = false; renderMixer(); } renderSubPop(); });
$('subPop').addEventListener('mousedown', (e) => e.stopPropagation());
$('stage').addEventListener('mousedown', () => { if (subOpen) { subOpen = false; S.skipClick = true; renderSubPop(); } });

const NET_LANGS = [['ar', 'العربية'], ['en', 'English'], ['fr', 'Français'], ['es', 'Español'], ['tr', 'Türkçe'], ['de', 'Deutsch'], ['ja', '日本語']];
async function subSearchDialog() {
  const it = S.list[S.cur];
  if (!it) { osd('افتح فيديو أولاً'); return; }
  const g = await ap.subGuess(it.name);
  const hasOs = cfg('osKey') || (S.emb && S.emb.os), hasDl = cfg('subdlKey') || (S.emb && S.emb.subdl);
  let source = hasDl && !hasOs ? 'subdl' : 'os';
  sheet(`${head('البحث عن ترجمة على الإنترنت')}<div class="sh-body">
    <div class="srch"><button class="opt" data-src="os" style="flex:1"><span>OpenSubtitles</span></button><button class="opt" data-src="subdl" style="flex:1"><span>SubDL</span></button></div>
    <div class="srch"><input id="qName" class="field" placeholder="اسم الفيلم أو المسلسل أو الأنمي" value="${esc(g.query)}">
      <input id="qS" class="field" style="max-width:70px;min-width:60px" placeholder="الموسم" value="${g.season || ''}" dir="ltr">
      <input id="qE" class="field" style="max-width:70px;min-width:60px" placeholder="الحلقة" value="${g.episode || ''}" dir="ltr"></div>
    <div class="srch"><select id="qL" class="sel" style="flex:1">${NET_LANGS.map(([v, t]) => `<option value="${v}"${v === cfg('subLang') ? ' selected' : ''}>${t}</option>`).join('')}</select><button class="pbtn accent" id="qGo">بحث</button></div>
    <div id="qRes" class="res"></div></div>`);
  const paint = () => $('sheet').querySelectorAll('[data-src]').forEach((b) => b.classList.toggle('on', b.dataset.src === source));
  $('sheet').querySelectorAll('[data-src]').forEach((b) => b.addEventListener('click', () => { source = b.dataset.src; paint(); }));
  paint();
  $('sheet').querySelectorAll('.field').forEach((x) => x.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') $('qGo').click(); }));
  const keys = () => ({ osKey: cfg('osKey'), osUser: cfg('osUser'), osPass: cfg('osPass'), subdlKey: cfg('subdlKey') });
  $('qGo').addEventListener('click', async () => {
    const q = { source, query: $('qName').value.trim(), season: +$('qS').value || null, episode: +$('qE').value || null, lang: $('qL').value, ...keys() };
    if (!q.query) return;
    $('qRes').innerHTML = '<div class="prow"><span class="spin"></span><span class="l">جاري البحث…</span></div>';
    const r = await ap.subSearch(q);
    if (r.error) { $('qRes').innerHTML = `<div class="note">${esc(r.error)}</div>${/مفتاح/.test(r.error) ? '<button class="opt" id="qKeys"><span>فتح الإعدادات ← الترجمة</span></button>' : ''}`; if ($('qKeys')) $('qKeys').addEventListener('click', () => openPrefs('subs')); return; }
    if (!r.items.length) { $('qRes').innerHTML = '<div class="prow"><span class="l">لا توجد نتائج. جرّب اسماً آخر أو لغة أخرى.</span></div>'; return; }
    const src = r.source || q.source;
    $('qRes').innerHTML = (r.note ? `<div class="prow"><span class="l">${esc(r.note)}</span></div>` : '') + r.items.map((x, i) => `<button class="sopt" data-i="${i}"><span dir="auto" data-notr style="text-align:start;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:300px">${esc(x.title)}</span><span class="s2">${esc(x.extra || '')}</span></button>`).join('');
    $('qRes').querySelectorAll('[data-i]').forEach((b) => b.addEventListener('click', async () => {
      const x = r.items[+b.dataset.i];
      b.innerHTML = '<span class="spin"></span><span>جاري التحميل…</span>';
      const d = await ap.subDownload({ ...q, source: src, id: x.id, video: it.path });
      if (d.error) { b.innerHTML = `<span>${esc(d.error)}</span>`; return; }
      closeSheet(); await addSubFile(d.file, d.text); osd('تم تحميل الترجمة وتشغيلها');
    }));
  });
  if (g.query) $('qGo').click();
}

// ================= seek-bar thumbnails =================
const thumbVid = document.createElement('video');
thumbVid.muted = true; thumbVid.preload = 'auto';
if (window.AP_MEDIA_CROSS) thumbVid.crossOrigin = 'anonymous';
let thumbWant = null, thumbBusy = false;
function wantThumb(t) { thumbWant = t; if (!thumbBusy) nextThumb(); }
function nextThumb() {
  if (thumbWant == null || !thumbVid.getAttribute('src')) return;
  thumbBusy = true; const t = thumbWant; thumbWant = null;
  try { thumbVid.currentTime = t; } catch { thumbBusy = false; }
}
thumbVid.addEventListener('seeked', () => {
  const c = $('thumb'), x = c.getContext('2d');
  const vw = thumbVid.videoWidth || 16, vh = thumbVid.videoHeight || 9, r = Math.min(c.width / vw, c.height / vh);
  x.fillStyle = '#000'; x.fillRect(0, 0, c.width, c.height);
  x.drawImage(thumbVid, (c.width - vw * r) / 2, (c.height - vh * r) / 2, vw * r, vh * r);
  thumbBusy = false; if (thumbWant != null) nextThumb();
});
thumbVid.addEventListener('error', () => { thumbBusy = false; });

// ================= bookmarks =================
const marks = () => { const it = S.list[S.cur]; return it ? ((S.set.bookmarks || {})[it.path] || []) : []; };
function setMarks(arr) { const it = S.list[S.cur]; if (!it) return; const b = Object.assign({}, S.set.bookmarks || {}); if (arr.length) b[it.path] = arr; else delete b[it.path]; save({ bookmarks: b }); paintSeek(); }
function addMark() {
  if (!video.duration) return;
  const t = Math.round(video.currentTime * 10) / 10, arr = marks().slice();
  if (arr.some((m) => Math.abs(m.t - t) < 0.5)) { osd('توجد علامة هنا من قبل'); return; }
  arr.push({ t, at: Date.now() }); arr.sort((a, b) => a.t - b.t); setMarks(arr);
  osd('تمت إضافة علامة عند ' + ltr(fmt(t)));
}
let marksKey = '';
function paintMarks(d) {
  const arr = d ? marks() : [], key = d + ':' + arr.map((m) => m.t).join(',');
  if (key === marksKey) return; marksKey = key;
  const box = $('seekMarks'); box.innerHTML = '';
  for (const m of arr) {
    const el = document.createElement('div'); el.className = 'mark'; el.style[SIDE()] = (m.t / d * 100) + '%'; el.title = 'علامة ' + fmt(m.t);
    el.addEventListener('mousedown', (e) => { e.stopPropagation(); video.currentTime = m.t; });
    box.appendChild(el);
  }
}
function marksDialog() {
  const arr = marks();
  const two = (n) => String(n).padStart(2, '0');
  const when = (ms) => stamp(ms);
  sheet(`${head('العلامات في هذا المقطع')}<div class="sh-body">
    ${arr.length ? arr.map((m, i) => `<div class="bm" data-go="${i}"><span class="t">${fmt(m.t)}</span><span class="d">أُضيفت ${when(m.at)}</span><button class="ib" data-del="${i}" title="حذف">${IC.x}</button></div>`).join('') : '<div class="prow"><span class="l">لا توجد علامات. اضغط P أثناء التشغيل لإضافة علامة.</span></div>'}
    </div><div class="sh-foot"><button class="pbtn accent" id="bmAdd">إضافة علامة الآن</button>${arr.length ? '<button class="pbtn danger" id="bmClear">حذف الكل</button>' : ''}<button class="pbtn" data-close>إغلاق</button></div>`);
  $('sheet').querySelectorAll('[data-go]').forEach((el) => el.addEventListener('click', (e) => { if (e.target.closest('[data-del]')) return; video.currentTime = arr[+el.dataset.go].t; closeSheet(); }));
  $('sheet').querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', () => { const a = marks().slice(); a.splice(+b.dataset.del, 1); setMarks(a); marksDialog(); }));
  $('bmAdd').addEventListener('click', () => { addMark(); marksDialog(); });
  if ($('bmClear')) $('bmClear').addEventListener('click', () => { setMarks([]); marksDialog(); });
}
$('bMark').addEventListener('click', addMark);
$('bMark').addEventListener('contextmenu', (e) => { e.preventDefault(); marksDialog(); });

// ================= pause on minimize / focus lost =================
let pausedBy = null;
ap.onWinEvent((ev) => {
  if ((ev === 'minimize' && cfg('pauseMin')) || (ev === 'blur' && cfg('pauseBlur')) || (ev === 'lock' && cfg('pauseLock'))) { if (!video.paused) { video.pause(); pausedBy = ev; } }
  else if ((ev === 'restore' && pausedBy === 'minimize') || (ev === 'focus' && pausedBy === 'blur') || (ev === 'unlock' && pausedBy === 'lock')) { pausedBy = null; video.play().catch(() => {}); }
});

// ================= actions and customizable shortcuts =================
const ACTIONS = [
  ['play', 'تشغيل / إيقاف مؤقت', ['Space'], () => togglePlay()],
  ['fwd', 'تقديم', ['ArrowRight'], () => rel(cfg('seekStep'))],
  ['back', 'رجوع', ['ArrowLeft'], () => rel(-cfg('seekStep'))],
  ['fwd30', 'تقديم 30 ثانية', ['Shift+ArrowRight'], () => rel(30)],
  ['back30', 'رجوع 30 ثانية', ['Shift+ArrowLeft'], () => rel(-30)],
  ['volUp', 'رفع الصوت العام', ['ArrowUp'], () => { setVol(cfg('master') + cfg('volStep')); osd('الصوت ' + ltr(cfg('master') + '%')); }],
  ['volDown', 'خفض الصوت العام', ['ArrowDown'], () => { setVol(cfg('master') - cfg('volStep')); osd('الصوت ' + ltr(cfg('master') + '%')); }],
  ['mute', 'كتم كل الأصوات', ['M'], () => muteAll()],
  ['mixer', 'لوحة الأصوات', ['A'], () => { if (!cfg('mixPinned')) { mixOpen = !mixOpen; renderMixer(); } }],
  ['open', 'فتح ملف', ['F3', 'Ctrl+O'], () => pickFiles()],
  ['folder', 'فتح مجلد', ['F2'], () => pickFolder()],
  ['close', 'إغلاق الفيديو', ['F4'], () => stopAll()],
  ['prefs', 'الإعدادات', ['F5'], () => openPrefs()],
  ['list', 'قائمة التشغيل', ['F6'], () => toggleList()],
  ['full', 'ملء الشاشة', ['Enter'], () => full()],
  ['frameF', 'الإطار التالي', ['.'], () => frame(1)],
  ['frameB', 'الإطار السابق', [','], () => frame(-1)],
  ['faster', 'أسرع', ['C', ']'], () => stepSpeed(1)],
  ['slower', 'أبطأ', ['X', '['], () => stepSpeed(-1)],
  ['normal', 'السرعة العادية', ['Z', 'Backspace'], () => setSpeed(1)],
  ['ab', 'تكرار جزء A-B', ['\\', 'L'], () => abPress()],
  ['shot', 'لقطة', ['S'], () => shot()],
  ['mark', 'إضافة علامة', ['P'], () => addMark()],
  ['marks', 'قائمة العلامات', ['H'], () => marksDialog()],
  ['subs', 'إظهار / إخفاء الترجمة', ['Alt+H'], () => { if (SUB.cur < 0) { subOpen = true; renderSubPop(); return; } SUB.hidden = !SUB.hidden; SUB.last = ''; osd(SUB.hidden ? 'الترجمة مخفية' : 'الترجمة ظاهرة'); }],
  ['subMenu', 'قائمة الترجمة', ['Alt+S'], () => { subOpen = !subOpen; renderSubPop(); }],
  ['subLater', 'تأخير الترجمة', ['Alt+ArrowLeft'], () => subDelay(0.1)],
  ['subSooner', 'تقديم الترجمة', ['Alt+ArrowRight'], () => subDelay(-0.1)],
  ['audLater', 'تأخير الصوت', ['Shift+>'], () => audioDelay(50)],
  ['audSooner', 'تقديم الصوت', ['Shift+<'], () => audioDelay(-50)],
  ['next', 'المقطع التالي', ['PageDown'], () => S.cur < S.list.length - 1 && playIndex(S.cur + 1)],
  ['prev', 'المقطع السابق', ['PageUp'], () => S.cur > 0 && playIndex(S.cur - 1)],
  ['export', 'تصدير', ['Ctrl+E'], () => exportDialog()],
  ['repeat', 'التكرار (بدون / المقطع / الكل)', ['R'], () => cycleRepeat()],
  ['shuffle', 'تشغيل عشوائي', ['Shift+R'], () => toggleShuffle()],
  ['onTop', 'دائماً في المقدمة', ['Ctrl+T'], () => toggleTop()],
  ['jump', 'الذهاب إلى وقت', ['Ctrl+G'], () => jumpDialog()],
  ['info', 'معلومات الملف', ['Ctrl+F1'], () => infoDialog()],
  ['remain', 'المدة / الوقت المتبقي', ['T'], () => { save({ showRemain: !cfg('showRemain') }); paintDur(); }],
  ['rotate', 'تدوير الصورة ' + ltr('90°'), ['Ctrl+K'], () => rotateBy(90)],
  ['flipH', 'قلب الصورة أفقياً', ['Ctrl+Z'], () => vset({ flipH: !cfg('flipH') }, 'قلب أفقي')],
  ['flipV', 'قلب الصورة عمودياً', ['Ctrl+V'], () => vset({ flipV: !cfg('flipV') }, 'قلب عمودي')],
  ['zoomIn', 'تكبير الصورة', ['Ctrl+='], () => zoomBy(10)],
  ['zoomOut', 'تصغير الصورة', ['Ctrl+-'], () => zoomBy(-10)],
  ['zoom0', 'حجم الصورة الأصلي', ['Ctrl+0'], () => zoomBy(0)],
  ['vreset', 'إرجاع الصورة للأصل', ['Ctrl+Backspace'], () => resetVideo()],
  ['normalize', 'توحيد مستوى الصوت', ['Ctrl+N'], () => { save({ normalize: !cfg('normalize') }); wireComp(); osd(cfg('normalize') ? 'توحيد مستوى الصوت: يعمل' : 'توحيد مستوى الصوت: متوقف'); }],
  ['burst', 'صور متتالية', ['Shift+S'], () => burst()],
  ['escape', 'الخروج من ملء الشاشة', ['Escape'], () => document.body.classList.contains('full') && ap.exitFullscreen()],
];
const keyOf = (id) => (S.set.keys && S.set.keys[id]) || ACTIONS.find((a) => a[0] === id)[2];
// shortcuts follow the physical key (e.code), so they work the same with the Arabic or French keyboard layout
const CODE_KEY = { Period: '.', Comma: ',', BracketLeft: '[', BracketRight: ']', Backslash: '\\', IntlBackslash: '\\', Semicolon: ';', Quote: "'", Slash: '/', Minus: '-', Equal: '=', Backquote: '`' };
function keyName(e) {
  if (['Control', 'Shift', 'Alt', 'Meta', 'AltGraph'].includes(e.key)) return null;
  let k, c = e.code || '';
  if (/^Key[A-Z]$/.test(c)) k = c.slice(3);
  else if (/^Digit\d$/.test(c)) k = c.slice(5);
  else if (/^Numpad\d$/.test(c)) k = c.slice(6);
  else if (CODE_KEY[c]) k = e.shiftKey && c === 'Comma' ? '<' : e.shiftKey && c === 'Period' ? '>' : CODE_KEY[c];
  else if (e.key === ' ' || c === 'Space') k = 'Space';
  else if (c === 'NumpadEnter') k = 'Enter';
  else k = e.key.length === 1 ? e.key.toUpperCase() : e.key;
  const mods = [];
  if (e.ctrlKey) mods.push('Ctrl');
  if (e.altKey) mods.push('Alt');
  if (e.shiftKey) mods.push('Shift');
  return [...mods, k].join('+');
}
const KEY_LABEL = { ArrowRight: '→', ArrowLeft: '←', ArrowUp: '↑', ArrowDown: '↓', PageDown: 'PgDn', PageUp: 'PgUp', Escape: 'Esc', Backspace: '⌫' };
const prettyKey = (k) => k.split('+').map((p) => KEY_LABEL[p] || p).join(' + ');
let capturing = null;
document.addEventListener('keydown', (e) => {
  if (capturing) {
    e.preventDefault(); e.stopPropagation();
    if (e.key === 'Escape') { capturing = null; prefRefresh(); return; }
    const k = keyName(e); if (!k) return;
    const keys = Object.assign({}, S.set.keys || {});
    for (const [id] of ACTIONS) { const cur = keyOf(id).filter((x) => x !== k); if (cur.length !== keyOf(id).length) keys[id] = cur; }
    keys[capturing] = [k];
    save({ keys }); capturing = null; prefRefresh(); return;
  }
  if (e.target.tagName === 'INPUT' && e.target.type !== 'range') return;
  if (e.target.tagName === 'SELECT') return;
  if (!$('modal').classList.contains('hidden')) { if (e.key === 'Escape' && !S.exporting) closeSheet(); return; }
  if (!$('menu').classList.contains('hidden') && e.key === 'Escape') { hideMenu(); return; }
  if (!e.ctrlKey && !e.altKey && !e.shiftKey && /^(Digit|Numpad)[1-9]$/.test(e.code || '')) return toggleTrack(+e.code.slice(-1) - 1);
  const k = keyName(e); if (!k) return;
  const act = ACTIONS.find(([id]) => keyOf(id).includes(k));
  if (act) { e.preventDefault(); act[3](); }
});

document.addEventListener('dragover', (e) => { e.preventDefault(); document.body.classList.add('drop-over'); });
document.addEventListener('dragleave', (e) => { if (!e.relatedTarget) document.body.classList.remove('drop-over'); });
document.addEventListener('drop', async (e) => {
  e.preventDefault(); document.body.classList.remove('drop-over');
  const paths = [...e.dataTransfer.files].map((f) => ap.pathForFile(f)).filter(Boolean);
  if (!paths.length) return;
  const sub = paths.find((p) => /\.(srt|ass|ssa|vtt)$/i.test(p));
  if (sub && S.cur >= 0) { addSubFile(sub); return; }
  if (paths.length === 1) return openPath(paths[0]);
  openFiles(paths);
});
ap.onOpenPath((p) => openPath(p));
if (ANDROID) {
  $('bMenu').addEventListener('click', (e) => $('stage').dispatchEvent(new MouseEvent('contextmenu', { clientX: e.clientX, clientY: e.clientY, bubbles: true })));
  if (ap.onApkProgress) ap.onApkProgress((p) => { if (typeof p === 'number' || /^-?\d+$/.test(String(p))) osd(+p < 0 ? 'فشل تحميل التحديث' : 'تحميل التحديث ' + ltr(p + '%')); });
  // phone: double-tap the right or left third of the video to skip 10 s, a tap shows the controls in fullscreen
  let lastTap = 0, tapT = null;
  video.addEventListener('touchend', (e) => {
    const t = e.changedTouches[0], r = $('stage').getBoundingClientRect(), x = (t.clientX - r.left) / r.width, now = Date.now();
    document.body.classList.add('ui'); clearTimeout(uiT); uiT = setTimeout(() => document.body.classList.remove('ui'), 3000);
    if (now - lastTap < 300) {
      clearTimeout(tapT); lastTap = 0; e.preventDefault();
      const fwd = RTL() ? x < 0.35 : x > 0.65, back = RTL() ? x > 0.65 : x < 0.35;
      if (fwd) rel(10); else if (back) rel(-10); else full();
      S.skipClick = true;
    } else lastTap = now;
  }, { passive: false });
}
// phone back button: close the topmost thing first; true = handled
window.appBack = () => {
  if (!$('menu').classList.contains('hidden')) { hideMenu(); return true; }
  if (!$('modal').classList.contains('hidden')) { if (!S.exporting) closeSheet(); return true; }
  if (subOpen) { subOpen = false; renderSubPop(); return true; }
  if (mixOpen) { mixOpen = false; renderMixer(); return true; }
  if (!$('updBar').classList.contains('hidden')) { if (!U.busy) updHide(); return true; } // a running download is not stopped by the back button
  if (document.body.classList.contains('full')) { ap.exitFullscreen(); return true; }
  if (ANDROID && window.innerWidth < 760 && cfg('showList')) { toggleList(); return true; }
  return false;
};
window.addEventListener('beforeunload', () => { savePos(false); if (!S.noSessionSave) saveSession(); });

async function restoreSession() {
  const ss = S.set.session;
  // still marked running: the program did not close normally. Not on the phone: closing it from the recent apps
  // looks the same as a crash there, so the phone only follows the setting.
  const crashed = !ANDROID && S.set.running === true;
  save({ running: true });
  if (!ss || !ss.paths || !ss.paths.length) return;
  const mode = ss.resume ? 'update' : crashed ? 'crash' : cfg('onOpen') === 'session' ? 'session' : 'fresh';
  if (ss.resume) save({ session: Object.assign({}, ss, { resume: false }) });
  if (mode === 'fresh') { save({ session: null }); return; }
  if (ANDROID && ss.lib) return; // the phone was on the library: it comes back to the library, not to a video
  const infos = (await Promise.all(ss.paths.map((p) => ap.fileInfo(p)))).filter(Boolean); // missing files are skipped
  if (!infos.length) return;
  S.list = infos; S.cur = -1; renderList(false);
  let i = infos.findIndex((x) => x.path === ss.cur);
  const at = i >= 0 ? ss.t : 0; if (i < 0) i = 0;
  const play = mode === 'update' || mode === 'crash';
  await playIndex(i, { at, paused: !play });
  // the playlist opens at the clip that is playing: that clip sits at the top of the list
  const toCur = () => { const box = $('plItems'), on = box.querySelector('.pl-it.on'); if (!on || !box.clientHeight) return;
    box.scrollTop += on.getBoundingClientRect().top - box.getBoundingClientRect().top; };
  requestAnimationFrame(toCur); setTimeout(toCur, 300); S.plToCur = toCur;
  if (mode === 'crash') osd('تمت استعادة الجلسة بعد توقف البرنامج');
  else if (at > 1) osd('متابعة من ' + ltr(fmt(at)));
}
(async function init() {
  S.set = await ap.settingsGet();
  S.set.theme = document.body.dataset.theme || 'andoria'; // the General row shows the theme in use
  S.appInfo = await ap.appReady();
  // the phone checks that a downloaded page really started; it starts counting when the whole page has
  // finished loading (pictures included), so say "ready" again after that moment too
  if (ANDROID) {
    const again = () => { setTimeout(() => ap.appReady(), 600); setTimeout(() => ap.appReady(), 4000); };
    if (document.readyState === 'complete') again(); else window.addEventListener('load', again);
    setTimeout(() => ap.appReady(), 12000);
  }
  S.emb = await ap.embKeys();
  $('vol').value = cfg('master'); $('volV').textContent = cfg('master') + '%';
  if (ANDROID && window.innerWidth < 760 && S.set.showList === undefined) S.set.showList = false;
  document.body.classList.toggle('no-list', !cfg('showList'));
  $('bList').classList.toggle('on', cfg('showList'));
  if (!(ANDROID && window.innerWidth < 760)) setListW(cfg('listW'), true);
  applyVideoLook(); paintModes();
  applyTop(); $('vol').max = cfg('maxVol');
  renderList(); renderMixer();
  const f = await ap.startupFile();
  if (f) openPath(f);
  else await restoreSession();
  S.ready = true;
  // check right away, then every 10 minutes while open, and when the window gets focus again (at most every 2 minutes)
  if (cfg('autoUpd')) {
    autoCheck();
    setInterval(autoCheck, 10 * 60 * 1000);
    window.addEventListener('focus', () => { if (Date.now() - (S.lastCheck || 0) > 60 * 1000) autoCheck(); });
    document.addEventListener('visibilitychange', () => { if (!document.hidden && Date.now() - (S.lastCheck || 0) > 60 * 1000) autoCheck(); }); // the phone app coming back
  }
})();

// sliders show their filled part in the theme's colour: --p is how far the value is, --d which side it starts from
(function fillSliders() {
  const paint = (el) => {
    if (el.type !== 'range' || el.dataset.eq !== undefined) return;
    const lo = +el.min || 0, hi = el.max === '' ? 100 : +el.max, v = +el.value;
    const p = hi > lo ? Math.max(0, Math.min(100, ((v - lo) / (hi - lo)) * 100)) : 0;
    el.style.setProperty('--p', p.toFixed(1) + '%');
    el.style.setProperty('--d', getComputedStyle(el).direction === 'rtl' ? 'to left' : 'to right');
  };
  const all = () => document.querySelectorAll('input[type=range]').forEach(paint);
  document.addEventListener('input', (e) => paint(e.target), true);
  new MutationObserver(() => requestAnimationFrame(all)).observe(document.body, { childList: true, subtree: true });
  setInterval(all, 700); // values changed from code (volume keys, wheel, restore)
  all();
})();
