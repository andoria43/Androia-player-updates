'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, Menu, protocol, net, powerMonitor } = require('electron');
const zlib = require('zlib');
const { Readable } = require('stream');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');
const media = require('./lib/media');
const subsLib = require('./lib/subs');

const VIDEO_EXT = new Set(['.mp4', '.mkv', '.mov', '.avi', '.webm', '.m4v', '.ts', '.flv', '.wmv']);
const TMP = path.join(os.tmpdir(), 'andoria-player');
let win = null;
let exportProc = null;

// one origin (app://) for the page and the media, so Web Audio can read every track
protocol.registerSchemesAsPrivileged([{ scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true } }]);
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.mov': 'video/quicktime', '.mkv': 'video/x-matroska', '.webm': 'video/webm', '.m4a': 'audio/mp4', '.mp3': 'audio/mpeg', '.avi': 'video/x-msvideo', '.ts': 'video/mp2t' };
function serveFile(file, req) {
  let st;
  try { st = fs.statSync(file); } catch { return new Response('not found', { status: 404 }); }
  const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
  const range = /bytes=(\d*)-(\d*)/.exec(req.headers.get('range') || '');
  if (range && st.size > 0) {
    let start = range[1] ? +range[1] : st.size - (+range[2]);
    let end = range[1] && range[2] ? +range[2] : st.size - 1;
    start = Math.max(0, start); end = Math.min(end, st.size - 1);
    if (start > end) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${st.size}` } });
    return new Response(Readable.toWeb(fs.createReadStream(file, { start, end })), { status: 206, headers: {
      'Content-Type': type, 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': '*', 'Content-Length': String(end - start + 1), 'Content-Range': `bytes ${start}-${end}/${st.size}` } });
  }
  return new Response(Readable.toWeb(fs.createReadStream(file)), { status: 200, headers: { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': '*', 'Content-Length': String(st.size) } });
}

function ffmpegPath() {
  const exe = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg';
  const cands = [
    path.join(process.resourcesPath || '', 'bin', exe),
    path.join(__dirname, 'bin', exe),
  ];
  for (const c of cands) if (fs.existsSync(c)) return c;
  return exe;
}

const SETTINGS = () => path.join(app.getPath('userData'), 'settings.json');
function readSettings() { try { return JSON.parse(fs.readFileSync(SETTINGS(), 'utf8')); } catch { return {}; } }
function writeSettings(s) { try { fs.writeFileSync(SETTINGS(), JSON.stringify(s, null, 1)); } catch {} }

const uiUrl = () => 'app://ui/index.html?lang=' + (readSettings().lang === 'en' ? 'en' : 'ar');
const EN_T = { 'حفظ قائمة التشغيل': 'Save playlist', 'فتح قائمة تشغيل': 'Open playlist', 'فتح فيديو': 'Open video', 'فيديو': 'Video', 'كل الملفات': 'All files', 'اختر مجلد المقاطع': 'Choose the clips folder', 'حفظ باسم': 'Save as',
  'إضافة ملف ترجمة': 'Add subtitle file', 'ترجمة': 'Subtitles', 'تصدير الإعدادات': 'Export settings', 'استيراد الإعدادات': 'Import settings' };
const T = (s) => (readSettings().lang === 'en' && EN_T[s]) || s;
function createWindow() {
  Menu.setApplicationMenu(null);
  const s = readSettings();
  win = new BrowserWindow({
    width: s.w || 1280, height: s.h || 820, minWidth: 900, minHeight: 600,
    backgroundColor: '#0B0D12', title: 'أندوريا بلاير', icon: path.join(__dirname, 'icon.png'), frame: false,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false },
  });
  if (s.max) win.maximize();
  win.loadURL(uiUrl());
  win.on('maximize', () => win.webContents.send('win-state', true));
  win.on('unmaximize', () => win.webContents.send('win-state', false));
  win.on('minimize', () => win.webContents.send('win-event', 'minimize'));
  try { powerMonitor.on('lock-screen', () => win && win.webContents.send('win-event', 'lock')); powerMonitor.on('unlock-screen', () => win && win.webContents.send('win-event', 'unlock')); } catch {}
  win.on('restore', () => win.webContents.send('win-event', 'restore'));
  win.on('blur', () => win.webContents.send('win-event', 'blur'));
  win.on('focus', () => win.webContents.send('win-event', 'focus'));
  win.on('enter-full-screen', () => win.webContents.send('full-state', true));
  win.on('leave-full-screen', () => win.webContents.send('full-state', false));
  win.on('close', () => {
    const st = readSettings();
    st.max = win.isMaximized();
    if (!st.max) { const b = win.getBounds(); st.w = b.width; st.h = b.height; }
    writeSettings(st);
  });
}

function argFile(argv) {
  return argv.slice(1).find((x) => x && !x.startsWith('-') && x !== '.' && fs.existsSync(x) && !/electron(\.exe)?$/i.test(x) && path.resolve(x) !== path.resolve(__dirname));
}
if (readSettings().singleInstance !== false && !app.requestSingleInstanceLock()) { app.quit(); }
app.on('second-instance', (_e, argv) => {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.focus();
  const f = argFile(argv);
  if (f) win.webContents.send('open-path', path.resolve(f));
});

app.whenReady().then(() => {
  protocol.handle('app', (req) => {
    const u = new URL(req.url);
    // media lives on the same origin as the page (CSP 'self' + Web Audio need one origin)
    if (u.pathname.startsWith('/media/')) return serveFile(decodeURIComponent(u.pathname.slice(7)), req);
    const f = path.normalize(path.join(__dirname, 'www', decodeURIComponent(u.pathname)));
    if (!f.startsWith(path.join(__dirname, 'www'))) return new Response('no', { status: 403 });
    return serveFile(f, req);
  });
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
  fs.mkdirSync(TMP, { recursive: true });
  createWindow();
});
app.on('window-all-closed', () => {
  if (exportProc) try { exportProc.kill(); } catch {}
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch {}
  app.quit();
});

// files passed on the command line ("open with")
ipcMain.handle('startup-file', () => {
  const a = argFile(process.argv);
  return a ? path.resolve(a) : null;
});

ipcMain.handle('settings-get', () => readSettings());
ipcMain.handle('settings-set', (_e, patch) => { const s = Object.assign(readSettings(), patch); writeSettings(s); return s; });

ipcMain.handle('pick-file', async (_e, start) => {
  const r = await dialog.showOpenDialog(win, {
    title: T('فتح فيديو'), defaultPath: start || undefined, properties: ['openFile', 'multiSelections'],
    filters: [{ name: T('فيديو'), extensions: [...VIDEO_EXT].map((e) => e.slice(1)) }, { name: T('كل الملفات'), extensions: ['*'] }],
  });
  return r.canceled ? null : r.filePaths;
});

ipcMain.handle('pick-folder', async (_e, start) => {
  const r = await dialog.showOpenDialog(win, { title: T('اختر مجلد المقاطع'), defaultPath: start || undefined, properties: ['openDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('list-folder', (_e, folder, deep) => {
  const out = [];
  const walk = (dir, depth) => {
    let ents = [];
    try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) { if (deep && depth < 4 && !e.name.startsWith('.') && e.name !== 'لقطات') walk(p, depth + 1); continue; }
      if (!VIDEO_EXT.has(path.extname(e.name).toLowerCase())) continue;
      try { const st = fs.statSync(p); out.push({ path: p, name: path.parse(e.name).name, mtime: st.mtimeMs, size: st.size, sub: path.relative(folder, dir) }); } catch {}
      if (out.length > 5000) return;
    }
  };
  walk(folder, 0);
  return out.sort((a, b) => b.mtime - a.mtime); // newest on top
});

ipcMain.handle('is-dir', (_e, p) => { try { return fs.statSync(p).isDirectory(); } catch { return false; } });
ipcMain.handle('file-info', (_e, p) => { try { const st = fs.statSync(p); return { path: p, name: path.parse(p).name, mtime: st.mtimeMs, size: st.size }; } catch { return null; } });
ipcMain.handle('win', (_e, cmd) => {
  if (cmd === 'min') win.minimize();
  else if (cmd === 'max') { if (win.isMaximized()) win.unmaximize(); else win.maximize(); }
  else if (cmd === 'close') win.close();
  return win.isMaximized();
});

// probe the clip and split each audio track into its own small file (copied, no quality loss)
ipcMain.handle('prepare', async (_e, file) => {
  const ff = ffmpegPath();
  const pr = spawnSync(ff, ['-hide_banner', '-i', file], { encoding: 'utf8', windowsHide: true });
  if (pr.error) return { error: 'لم يتم العثور على ffmpeg بجانب البرنامج' };
  const info = media.parseProbe(pr.stderr || '');
  const id = crypto.createHash('md5').update(file + fs.statSync(file).mtimeMs).digest('hex').slice(0, 12);
  const dir = path.join(TMP, id);
  fs.mkdirSync(dir, { recursive: true });
  info.external = findExternalSubs(file);
  info.subFiles = [];
  if (info.subs.length) {
    const sx = media.subExtractCommand(file, info.subs, path.join(dir, 's'));
    if (sx.outs.length) {
      if (!sx.outs.every((o) => fs.existsSync(o.file))) await runFF(ff, sx.args);
      info.subFiles = sx.outs.filter((o) => fs.existsSync(o.file));
    }
  }
  if (!info.audio.length) return { ...info, files: [] };
  const { args, outs } = media.splitCommand(file, info.audio, path.join(dir, 'a'));
  if (!outs.every((o) => fs.existsSync(o))) {
    const code = await new Promise((res) => {
      const p = spawn(ff, args, { windowsHide: true });
      let err = '';
      p.stderr.on('data', (d) => (err += d));
      p.on('close', (c) => res(c === 0 ? 0 : err || String(c)));
      p.on('error', (e) => res(String(e)));
    });
    if (code !== 0) return { ...info, files: [], error: 'تعذر فصل مسارات الصوت: ' + String(code).slice(-300) };
  }
  return { ...info, files: outs };
});

function runFF(ff, args) {
  return new Promise((res) => {
    const p = spawn(ff, args, { windowsHide: true });
    p.on('close', (c) => res(c)); p.on('error', () => res(-1));
  });
}

function findExternalSubs(video) {
  const dir = path.dirname(video), base = path.parse(video).name.toLowerCase();
  try {
    return fs.readdirSync(dir).filter((f) => subsLib.SUB_EXT.test(f) && f.toLowerCase().startsWith(base))
      .map((f) => ({ file: path.join(dir, f), name: f }));
  } catch { return []; }
}

ipcMain.handle('read-sub', (_e, file) => { try { return subsLib.decodeText(fs.readFileSync(file)); } catch { return null; } });
ipcMain.handle('pick-sub', async (_e, start) => {
  const r = await dialog.showOpenDialog(win, { title: T('إضافة ملف ترجمة'), defaultPath: start || undefined, properties: ['openFile'], filters: [{ name: T('ترجمة'), extensions: ['srt', 'ass', 'ssa', 'vtt'] }] });
  return r.canceled ? null : r.filePaths[0];
});

// video-only remux into mp4, for containers the built-in player refuses (sound is played separately anyway)
ipcMain.handle('remux', async (_e, file) => {
  const out = path.join(TMP, crypto.createHash('md5').update(file).digest('hex').slice(0, 12) + '-v.mp4');
  if (fs.existsSync(out)) return out;
  const c = await runFF(ffmpegPath(), ['-hide_banner', '-y', '-loglevel', 'error', '-i', file, '-map', '0:v:0', '-c', 'copy', '-an', '-sn', '-movflags', '+faststart', out]);
  return c === 0 && fs.existsSync(out) ? out : null;
});

// ---------- online subtitles (OpenSubtitles.com, SubDL) ----------
const UA = 'AndoriaPlayer v1.0';
// keys embedded at build time (GitHub secrets). The user's own key (F5) is tried first, then the embedded one,
// so when one key hits its daily limit or fails, the next one is used automatically.
const EMB = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'keys.json'), 'utf8')); } catch { return {}; } })();
const keyList = (own, emb) => [...new Set([own, emb].map((k) => (k || '').trim()).filter(Boolean))];
ipcMain.handle('emb-keys', () => ({ os: !!EMB.os, subdl: !!EMB.subdl }));
ipcMain.handle('sub-guess', (_e, name) => subsLib.guessQuery(name));

async function searchSubdl(q, key) {
  const u = new URL('https://api.subdl.com/api/v1/subtitles');
  u.searchParams.set('api_key', key); u.searchParams.set('film_name', q.query);
  u.searchParams.set('languages', (q.lang || 'ar').toUpperCase()); u.searchParams.set('subs_per_page', '30');
  if (q.season) { u.searchParams.set('season_number', q.season); u.searchParams.set('type', 'tv'); }
  if (q.episode) u.searchParams.set('episode_number', q.episode);
  const r = await net.fetch(u.toString(), { headers: { Accept: 'application/json' } });
  if (r.status === 401 || r.status === 403 || r.status === 429) return { retry: true };
  const j = await r.json();
  if (!j.status) return /key|limit|quota/i.test(j.error || '') ? { retry: true } : { items: [] };
  return { items: (j.subtitles || []).map((x) => ({ id: x.url, title: x.release_name || x.name, lang: x.lang || q.lang, extra: x.author || '' })) };
}
async function searchOs(q, key) {
  const u = new URL('https://api.opensubtitles.com/api/v1/subtitles');
  u.searchParams.set('query', q.query); u.searchParams.set('languages', q.lang || 'ar');
  if (q.season) u.searchParams.set('season_number', q.season);
  if (q.episode) u.searchParams.set('episode_number', q.episode);
  const r = await net.fetch(u.toString(), { headers: { 'Api-Key': key, 'User-Agent': UA, Accept: 'application/json' } });
  if (r.status === 401 || r.status === 403 || r.status === 429) return { retry: true };
  const j = await r.json();
  return { items: (j.data || []).filter((x) => x.attributes.files && x.attributes.files.length).map((x) => ({
    id: x.attributes.files[0].file_id, title: x.attributes.release || x.attributes.feature_details?.title || '', lang: x.attributes.language, extra: `${x.attributes.download_count || 0} تحميل` })) };
}
async function searchOne(source, q) {
  const keys = source === 'subdl' ? keyList(q.subdlKey, EMB.subdl) : keyList(q.osKey, EMB.os);
  if (!keys.length) return { nokey: true };
  for (const k of keys) {
    try { const r = source === 'subdl' ? await searchSubdl(q, k) : await searchOs(q, k); if (!r.retry) return r; } catch {}
  }
  return { failed: true };
}
const SRC_NAME = { os: 'OpenSubtitles', subdl: 'SubDL' };
ipcMain.handle('sub-search', async (_e, q) => {
  const first = q.source === 'subdl' ? 'subdl' : 'os', other = first === 'os' ? 'subdl' : 'os';
  const r1 = await searchOne(first, q);
  if (r1.items && r1.items.length) return { items: r1.items, source: first };
  // nothing (or no key / limit reached) on the chosen site: try the other site automatically
  const r2 = await searchOne(other, q);
  if (r2.items && r2.items.length) return { items: r2.items, source: other, note: `لم توجد نتائج في ${SRC_NAME[first]}، هذه نتائج ${SRC_NAME[other]}` };
  if (r1.nokey && r2.nokey) return { error: 'لا يوجد مفتاح لمواقع الترجمة. أدخل مفتاحاً في الإعدادات ← الترجمة' };
  if ((r1.failed || r1.nokey) && (r2.failed || r2.nokey)) return { error: 'تعذر الاتصال بمواقع الترجمة أو انتهى حد التحميل اليومي. حاول لاحقاً.' };
  return { items: [], source: first };
});

const osTokens = {};
async function osLogin(q, key) {
  if (!q.osUser || !q.osPass) return null;
  if (osTokens[key]) return osTokens[key];
  try {
    const r = await net.fetch('https://api.opensubtitles.com/api/v1/login', { method: 'POST', headers: { 'Api-Key': key, 'User-Agent': UA, 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ username: q.osUser, password: q.osPass }) });
    const j = await r.json(); osTokens[key] = j.token || null;
  } catch {}
  return osTokens[key] || null;
}

ipcMain.handle('sub-download', async (_e, q) => {
  try {
    let text, ext = 'srt';
    if (q.source === 'subdl') {
      const r = await net.fetch('https://dl.subdl.com' + q.id);
      if (!r.ok) return { error: 'فشل تحميل الترجمة' };
      const f = subsLib.pickSubFromZip(Buffer.from(await r.arrayBuffer()));
      ext = path.extname(f.name).slice(1).toLowerCase(); text = subsLib.decodeText(f.data);
    } else {
      let link = null, fname = '', lastMsg = '';
      for (const key of keyList(q.osKey, EMB.os)) {
        try {
          const h = { 'Api-Key': key, 'User-Agent': UA, 'Content-Type': 'application/json', Accept: 'application/json' };
          const tok = await osLogin(q, key);
          if (tok) h.Authorization = 'Bearer ' + tok;
          const r = await net.fetch('https://api.opensubtitles.com/api/v1/download', { method: 'POST', headers: h, body: JSON.stringify({ file_id: q.id }) });
          const j = await r.json();
          if (j.link) { link = j.link; fname = j.file_name || ''; break; }
          lastMsg = j.message || '';
        } catch {}
      }
      if (!link) return { error: lastMsg ? 'انتهى حد التحميل اليومي لكل المفاتيح. جرّب SubDL أو حاول غداً.' : 'فشل تحميل الترجمة' };
      const r2 = await net.fetch(link);
      text = subsLib.decodeText(Buffer.from(await r2.arrayBuffer()));
      ext = (fname && path.extname(fname).slice(1).toLowerCase()) || 'srt';
    }
    const p = path.parse(q.video);
    let out = path.join(p.dir, `${p.name}.${q.lang || 'sub'}.${ext}`);
    try { fs.writeFileSync(out, text, 'utf8'); } catch {
      const d = path.join(app.getPath('userData'), 'subs'); fs.mkdirSync(d, { recursive: true });
      out = path.join(d, path.basename(out)); fs.writeFileSync(out, text, 'utf8');
    }
    return { ok: true, file: out, name: path.basename(out), text };
  } catch (e) { return { error: 'فشل تحميل الترجمة: ' + String(e.message || e) }; }
});

// ---------- settings export / import ----------
ipcMain.handle('settings-export', async () => {
  const r = await dialog.showSaveDialog(win, { title: T('تصدير الإعدادات'), defaultPath: path.join(app.getPath('documents'), 'AndoriaPlayer-settings.json'), filters: [{ name: 'JSON', extensions: ['json'] }] });
  if (r.canceled || !r.filePath) return null;
  const s = readSettings(); delete s.w; delete s.h; delete s.max;
  fs.writeFileSync(r.filePath, JSON.stringify({ app: 'AndoriaPlayer', version: 1, settings: s }, null, 1));
  return r.filePath;
});
ipcMain.handle('settings-import', async () => {
  const r = await dialog.showOpenDialog(win, { title: T('استيراد الإعدادات'), properties: ['openFile'], filters: [{ name: 'JSON', extensions: ['json'] }] });
  if (r.canceled) return null;
  try {
    const j = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8'));
    if (j.app !== 'AndoriaPlayer' || typeof j.settings !== 'object') return { error: 'هذا الملف ليس ملف إعدادات أندوريا بلاير' };
    writeSettings(Object.assign(readSettings(), j.settings));
    return { ok: true };
  } catch { return { error: 'تعذرت قراءة الملف' }; }
});
ipcMain.handle('settings-reset', () => { const s = readSettings(); writeSettings({ w: s.w, h: s.h, max: s.max }); return true; });
ipcMain.handle('on-top', (_e, on) => { win.setAlwaysOnTop(!!on); return win.isAlwaysOnTop(); });
ipcMain.handle('quit', () => app.quit());
ipcMain.handle('auto-start', (_e, on) => { try { app.setLoginItemSettings({ openAtLogin: !!on }); return app.getLoginItemSettings().openAtLogin; } catch { return false; } });
ipcMain.handle('shutdown-pc', () => { if (process.platform === 'win32') spawn('shutdown', ['/s', '/t', '5'], { windowsHide: true, detached: true }); app.quit(); });
ipcMain.handle('file-size', (_e, p) => { try { return fs.statSync(p).size; } catch { return 0; } });
ipcMain.handle('m3u-save', async (_e, paths) => {
  const r = await dialog.showSaveDialog(win, { title: T('حفظ قائمة التشغيل'), defaultPath: path.join(app.getPath('videos'), 'playlist.m3u8'), filters: [{ name: 'M3U', extensions: ['m3u8', 'm3u'] }] });
  if (r.canceled || !r.filePath) return null;
  fs.writeFileSync(r.filePath, '#EXTM3U\n' + paths.join('\n') + '\n', 'utf8');
  return r.filePath;
});
ipcMain.handle('m3u-open', async () => {
  const r = await dialog.showOpenDialog(win, { title: T('فتح قائمة تشغيل'), properties: ['openFile'], filters: [{ name: 'M3U', extensions: ['m3u8', 'm3u'] }] });
  if (r.canceled) return null;
  const base = path.dirname(r.filePaths[0]);
  return subsLib.decodeText(fs.readFileSync(r.filePaths[0])).split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith('#'))
    .map((l) => (path.isAbsolute(l) ? l : path.join(base, l))).filter((p) => fs.existsSync(p));
});
ipcMain.handle('reload', () => win.loadURL(uiUrl()));
ipcMain.handle('set-lang', (_e, l) => { const st = readSettings(); st.lang = l === 'en' ? 'en' : 'ar'; writeSettings(st); win.loadURL(uiUrl()); });

ipcMain.handle('export-save-path', async (_e, { src, audioOnly, folder }) => {
  const p = path.parse(src);
  if (folder && fs.existsSync(folder)) p.dir = folder;
  const ext = audioOnly ? 'mp3' : 'mp4';
  const r = await dialog.showSaveDialog(win, {
    title: T('حفظ باسم'), defaultPath: path.join(p.dir, `${p.name}_مدمج.${ext}`),
    filters: [{ name: audioOnly ? 'MP3' : 'MP4', extensions: [ext] }],
  });
  if (r.canceled || !r.filePath) return null;
  let out = r.filePath;
  if (!out.toLowerCase().endsWith('.' + ext)) out += '.' + ext;
  if (path.resolve(out).toLowerCase() === path.resolve(src).toLowerCase()) return { error: 'same' };
  return { path: out };
});

ipcMain.handle('export-run', (_e, { src, dst, tracks, start, end, audioOnly, bitrate }) => new Promise((resolve) => {
  let args;
  try { args = media.exportArgs(src, dst, tracks, { start, end, audioOnly, bitrate }); } catch (e) { return resolve({ ok: false, error: String(e.message || e) }); }
  let err = '';
  let buf = '';
  exportProc = spawn(ffmpegPath(), args, { windowsHide: true });
  exportProc.stdout.on('data', (d) => {
    buf += d;
    const lines = buf.split(/\r?\n/); buf = lines.pop();
    for (const l of lines) {
      const m = l.match(/^out_time_(?:us|ms)=(\d+)/);
      if (m && win) win.webContents.send('export-progress', +m[1] / 1e6);
    }
  });
  exportProc.stderr.on('data', (d) => { err = (err + d).slice(-2000); });
  exportProc.on('error', (e) => { exportProc = null; resolve({ ok: false, error: String(e) }); });
  exportProc.on('close', (code, signal) => {
    const cancelled = exportProc && exportProc.cancelled;
    exportProc = null;
    if (cancelled) { try { fs.unlinkSync(dst); } catch {} return resolve({ ok: false, cancelled: true }); }
    resolve(code === 0 ? { ok: true, path: dst } : { ok: false, error: err.slice(-600) || String(signal || code) });
  });
}));

ipcMain.handle('export-cancel', () => { if (exportProc) { exportProc.cancelled = true; exportProc.kill(); } });

ipcMain.handle('show-in-folder', (_e, p) => shell.showItemInFolder(p));

ipcMain.handle('save-shot', (_e, { video, time, dataUrl, folder, ext }) => {
  const dir = folder && fs.existsSync(folder) ? folder : path.join(path.dirname(video), 'لقطات');
  fs.mkdirSync(dir, { recursive: true });
  const out = path.join(dir, `${path.parse(video).name}_${Math.round(time * 1000)}.${ext === 'jpg' ? 'jpg' : 'png'}`);
  fs.writeFileSync(out, Buffer.from(dataUrl.split(',')[1], 'base64'));
  return out;
});

ipcMain.handle('toggle-fullscreen', () => { win.setFullScreen(!win.isFullScreen()); return win.isFullScreen(); });
ipcMain.handle('exit-fullscreen', () => { win.setFullScreen(false); return false; });

// ---------- small in-app updates (code package only, ~1 MB) ----------
const UPDATE_JSON = 'https://raw.githubusercontent.com/andoria43/Androia-player-updates/main/player-pc-latest.json';
const RUN = global.AP_RUNNING || { build: 0, shell: 1 };
const CODE_ROOT = () => path.join(app.getPath('userData'), 'code');

ipcMain.handle('app-ready', () => {
  try { fs.unlinkSync(path.join(CODE_ROOT(), 'starting-' + RUN.build)); } catch {}
  return { build: RUN.build, version: app.getVersion() };
});

ipcMain.handle('update-check', async () => {
  try {
    const r = await net.fetch(UPDATE_JSON + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) return { error: 'تعذر الاتصال بخادم التحديثات' };
    const j = await r.json();
    const installed = readInstalled();
    const have = Math.max(RUN.build, installed || 0);
    if (!j.build || j.build <= have) return { upToDate: true, build: RUN.build, pendingRestart: installed > RUN.build };
    if ((j.shell || 1) > RUN.shell) return { full: true, build: j.build, url: j.installerUrl, size: j.installerSize, notes: j.notes || '' };
    return { small: true, build: j.build, size: j.codeSize, notes: j.notes || '', info: j };
  } catch (e) { return { error: 'لا يوجد اتصال بالإنترنت' }; }
});

function readInstalled() {
  try { return JSON.parse(fs.readFileSync(path.join(CODE_ROOT(), 'current.json'), 'utf8')).build; } catch { return 0; }
}

// minimal tar reader (ustar) for the gzip'ed code package
function untar(buf, dest) {
  let off = 0;
  while (off + 512 <= buf.length) {
    const h = buf.subarray(off, off + 512);
    if (h.every((b) => b === 0)) break;
    const str = (a, b) => h.subarray(a, b).toString('utf8').replace(/\0.*$/s, '');
    let name = str(0, 100);
    const prefix = str(345, 500);
    if (prefix) name = prefix + '/' + name;
    const size = parseInt(str(124, 136).trim() || '0', 8);
    const type = String.fromCharCode(h[156] || 48);
    off += 512;
    const target = path.normalize(path.join(dest, name));
    if (!target.startsWith(path.normalize(dest + path.sep)) && target !== path.normalize(dest)) throw new Error('bad path');
    if (type === '5') fs.mkdirSync(target, { recursive: true });
    else if (type === '0') { fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, buf.subarray(off, off + size)); }
    off += Math.ceil(size / 512) * 512;
  }
}

ipcMain.handle('update-install', async (_e, info) => {
  try {
    // try the direct (raw) link first, then the release link; keep the last error for the message
    let gz = null, why = '';
    for (const u of [info.codeUrl, info.codeUrlRelease].filter(Boolean)) {
      try { const r = await net.fetch(u + (u.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store' }); if (r.ok) { gz = Buffer.from(await r.arrayBuffer()); break; } why = 'HTTP ' + r.status; }
      catch (e) { why = String(e.message || e).slice(0, 80); }
    }
    if (!gz) return { error: 'فشل تحميل التحديث' + (why ? ` (${why})` : '') };
    if (info.codeSha256 && crypto.createHash('sha256').update(gz).digest('hex') !== info.codeSha256) return { error: 'ملف التحديث تالف، أعد المحاولة' };
    const root = CODE_ROOT();
    const tmp = path.join(root, 'tmp-' + info.build);
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.mkdirSync(tmp, { recursive: true });
    untar(zlib.gunzipSync(gz), tmp);
    if (!fs.existsSync(path.join(tmp, 'main.js'))) return { error: 'ملف التحديث ناقص' };
    const dir = path.join(root, String(info.build));
    fs.rmSync(dir, { recursive: true, force: true });
    fs.renameSync(tmp, dir);
    fs.writeFileSync(path.join(root, 'current.json'), JSON.stringify({ build: info.build, shell: info.shell || 1 }));
    // keep only the two newest code folders
    for (const d of fs.readdirSync(root)) if (/^\d+$/.test(d) && +d < info.build && +d !== RUN.build) fs.rmSync(path.join(root, d), { recursive: true, force: true });
    return { ok: true };
  } catch (e) { return { error: 'فشل تثبيت التحديث: ' + String(e.message || e) }; }
});

ipcMain.handle('update-restart', () => { app.relaunch(); app.exit(0); });
ipcMain.handle('open-url', (_e, u) => { if (/^https:\/\//.test(u)) shell.openExternal(u); });
