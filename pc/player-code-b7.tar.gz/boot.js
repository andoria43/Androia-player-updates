'use strict';
// Starts the newest installed code: an in-app update (small code package kept in the user folder)
// if it is newer than the code shipped in the installer, otherwise the shipped code.
const { app } = require('electron');
const path = require('path');
const fs = require('fs');

const BUILT = (() => { try { return require('./build.json'); } catch { return { build: 0, shell: 1 }; } })();
global.AP_BUILT = BUILT;

function pick() {
  const root = path.join(app.getPath('userData'), 'code');
  try {
    const cur = JSON.parse(fs.readFileSync(path.join(root, 'current.json'), 'utf8'));
    const dir = path.join(root, String(cur.build));
    const bad = fs.existsSync(path.join(root, 'bad-' + cur.build));
    if (!bad && cur.build > BUILT.build && (cur.shell || 1) <= BUILT.shell && fs.existsSync(path.join(dir, 'main.js'))) {
      return { dir, build: cur.build, root };
    }
  } catch {}
  return null;
}

const upd = pick();
if (upd) {
  global.AP_RUNNING = { build: upd.build, shell: BUILT.shell, fromUpdate: true };
  // if the updated code fails to start, mark it bad and fall back to the shipped code next launch
  const mark = path.join(upd.root, 'starting-' + upd.build);
  try {
    if (fs.existsSync(mark)) { fs.writeFileSync(path.join(upd.root, 'bad-' + upd.build), '1'); fs.unlinkSync(mark); throw new Error('previous start failed'); }
    fs.writeFileSync(mark, '1');
    require(path.join(upd.dir, 'main.js'));
  } catch (e) {
    global.AP_RUNNING = { build: BUILT.build, shell: BUILT.shell, fromUpdate: false };
    require('./main.js');
  }
} else {
  global.AP_RUNNING = { build: BUILT.build, shell: BUILT.shell, fromUpdate: false };
  require('./main.js');
}
